; sawc2 link manifest
; target aarch64-unknown-linux-gnu
; speed -O2
; runtime none

target triple = "aarch64-unknown-linux-gnu"

@"static proc.NULL_ENVP" = internal global i64 0
@.bytes.0 = private unnamed_addr constant [8 x i8] c"proc.saw"
@.bytes.1 = private unnamed_addr constant [28 x i8] c"cast to Int32 out of range: "
@"static proc.WNOHANG" = internal global i32 1
@"static proc.NO_FD" = internal global i32 -1
@"static proc.STDOUT_FILENO" = internal global i32 1
@"static proc.STDERR_FILENO" = internal global i32 2
@"static proc.EXEC_FAILED_STATUS" = internal global i32 127
@.bytes.2 = private unnamed_addr constant [27 x i8] c"cast to Int8 out of range: "
@"static std.string.LENGTH_SLOT" = internal global i64 -1
@"static proc.EQUALS_BYTE" = internal global i8 61

declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare void @free(ptr)
declare i64 @read(i32, ptr, i64)
declare i64 @__saw_rt_last_syserror()
declare i64 @__saw_rt_proc_exit_fd(i64)
declare i32 @waitpid(i32, ptr, i32)
declare void @__saw_rt_panic(ptr, i64)
declare i32 @fork()
declare i32 @pipe(ptr)
declare i32 @close(i32)
declare i32 @dup2(i32, i32)
declare i32 @execvp(ptr, ptr)
declare void @__saw_environ_set(ptr)
declare void @_exit(i32)
declare ptr @malloc(i64)
declare ptr @__saw_environ_get()
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define i64 @"__saw_rt_proc_spawn"(ptr %p1, ptr %p2, i64 %p3) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca i64, align 8
  store ptr %p1, ptr %l1
  store ptr %p2, ptr %l2
  store i64 %p3, ptr %l3
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = load ptr, ptr %l2
  %t2 = load i64, ptr @"static proc.NULL_ENVP"
  %t3 = load i64, ptr %l3
  %t4 = call i64 @"saw proc.proc_spawn_impl(path: UnsafePointer<Int8>, argv: UnsafePointer<Int8>, envp: Int, flags: Int)"(ptr %t0, ptr %t1, i64 %t2, i64 %t3)
  store i64 %t4, ptr %l4
  br label %bb1
bb1:
  %t5 = load i64, ptr %l4
  store i64 %t5, ptr %l0
  %t6 = load i64, ptr %l0
  ret i64 %t6
}

define i64 @"__saw_rt_proc_spawn_env"(ptr %p1, ptr %p2, ptr %p3, i64 %p4) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca i64, align 8
  %l5 = alloca i64, align 8
  %l6 = alloca ptr, align 8
  %l7 = alloca i64, align 8
  %l8 = alloca i8, align 1
  %l9 = alloca i8, align 1
  %l10 = alloca i8, align 1
  %l11 = alloca i64, align 8
  %l12 = alloca i64, align 8
  %l13 = alloca i64, align 8
  %l14 = alloca i64, align 8
  %l15 = alloca ptr, align 8
  store ptr %p1, ptr %l1
  store ptr %p2, ptr %l2
  store ptr %p3, ptr %l3
  store i64 %p4, ptr %l4
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l3
  store ptr %t0, ptr %l6
  %t1 = load ptr, ptr %l6
  %t2 = call i64 @"saw proc.merge_environ(overrides: UnsafePointer<UnsafePointer<Int8>>)"(ptr %t1)
  store i64 %t2, ptr %l7
  br label %bb1
bb1:
  %t3 = load i64, ptr %l7
  store i64 %t3, ptr %l5
  %t4 = load i64, ptr %l5
  %t5 = load i64, ptr @"static proc.NULL_ENVP"
  %t6 = icmp eq i64 %t4, %t5
  %t7 = zext i1 %t6 to i8
  store i8 %t7, ptr %l8
  %t8 = load i8, ptr %l8
  %t9 = icmp ne i8 %t8, 0
  br i1 %t9, label %bb3, label %bb4
bb2:
  %t10 = load ptr, ptr %l1
  %t11 = load ptr, ptr %l2
  %t12 = load i64, ptr %l5
  %t13 = load i64, ptr %l4
  %t14 = call i64 @"saw proc.proc_spawn_impl(path: UnsafePointer<Int8>, argv: UnsafePointer<Int8>, envp: Int, flags: Int)"(ptr %t10, ptr %t11, i64 %t12, i64 %t13)
  store i64 %t14, ptr %l14
  br label %bb5
bb3:
  store i8 15, ptr %l9
  %t15 = load i8, ptr %l9
  %t16 = icmp eq i8 %t15, %t15
  store i8 %t15, ptr %l10
  %t17 = load i8, ptr %l10
  %t18 = zext i8 %t17 to i64
  %t19 = trunc i64 %t18 to i8
  %t20 = icmp eq i8 %t19, %t17
  %t21 = icmp sge i64 %t18, 0
  %t22 = and i1 %t20, %t21
  %t23 = zext i8 %t17 to i64
  store i64 %t23, ptr %l11
  %t24 = load i64, ptr %l11
  %t25 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t24)
  %t26 = extractvalue { i64, i1 } %t25, 0
  %t27 = extractvalue { i64, i1 } %t25, 1
  br i1 %t27, label %check.0, label %checked.1
check.0:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 8, i64 305)
  unreachable
checked.1:
  store i64 %t26, ptr %l12
  %t28 = load i64, ptr %l12
  store i64 %t28, ptr %l0
  %t29 = load i64, ptr %l0
  ret i64 %t29
bb4:
  br label %bb2
bb5:
  %t30 = load i64, ptr %l14
  store i64 %t30, ptr %l13
  %t31 = load i64, ptr %l5
  %t32 = inttoptr i64 %t31 to ptr
  store ptr %t32, ptr %l15
  %t33 = load ptr, ptr %l15
  call void @free(ptr %t33)
  br label %bb6
bb6:
  %t34 = load i64, ptr %l13
  store i64 %t34, ptr %l0
  %t35 = load i64, ptr %l0
  ret i64 %t35
}

define i64 @"__saw_rt_proc_read_stdout"(i64 %p1, ptr %p2, i64 %p3) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i64, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca ptr, align 8
  %l5 = alloca ptr, align 8
  %l6 = alloca i32, align 4
  %l7 = alloca i64, align 8
  %l8 = alloca i32, align 4
  %l9 = alloca i32, align 4
  %l10 = alloca i8, align 1
  %l11 = alloca i64, align 8
  %l12 = alloca i64, align 8
  %l13 = alloca i8, align 1
  %l14 = alloca i64, align 8
  %l15 = alloca i64, align 8
  store i64 %p1, ptr %l1
  store ptr %p2, ptr %l2
  store i64 %p3, ptr %l3
  br label %bb0
bb0:
  %t0 = load i64, ptr %l1
  %t1 = inttoptr i64 %t0 to ptr
  store ptr %t1, ptr %l5
  %t2 = load ptr, ptr %l5
  store ptr %t2, ptr %l4
  store i64 0, ptr %l7
  %t3 = load ptr, ptr %l4
  %t4 = load i64, ptr %l7
  %t5 = mul i64 %t4, 12
  %t6 = getelementptr i8, ptr %t3, i64 %t5
  %t7 = getelementptr i8, ptr %t6, i64 4
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l6
  %t9 = load i32, ptr %l6
  store i32 %t9, ptr %l8
  %t10 = trunc i64 0 to i32
  %t11 = sext i32 %t10 to i64
  %t12 = icmp eq i64 %t11, 0
  %t13 = trunc i64 0 to i32
  %t14 = xor i1 %t12, 1
  br i1 %t14, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 8, i64 324, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.1:
  store i32 %t13, ptr %l9
  %t15 = load i32, ptr %l8
  %t16 = load i32, ptr %l9
  %t17 = icmp slt i32 %t15, %t16
  %t18 = zext i1 %t17 to i8
  store i8 %t18, ptr %l10
  %t19 = load i8, ptr %l10
  %t20 = icmp ne i8 %t19, 0
  br i1 %t20, label %bb2, label %bb3
bb1:
  %t21 = load i32, ptr %l6
  %t22 = load ptr, ptr %l2
  %t23 = load i64, ptr %l3
  %t24 = call i64 @read(i32 %t21, ptr %t22, i64 %t23)
  store i64 %t24, ptr %l12
  br label %bb4
bb2:
  store i64 0, ptr %l0
  %t25 = load i64, ptr %l0
  ret i64 %t25
bb3:
  br label %bb1
bb4:
  %t26 = load i64, ptr %l12
  store i64 %t26, ptr %l11
  %t27 = load i64, ptr %l11
  %t28 = icmp sge i64 %t27, 0
  %t29 = zext i1 %t28 to i8
  store i8 %t29, ptr %l13
  %t30 = load i8, ptr %l13
  %t31 = icmp ne i8 %t30, 0
  br i1 %t31, label %bb6, label %bb7
bb5:
  %t32 = call i64 @__saw_rt_last_syserror()
  store i64 %t32, ptr %l14
  br label %bb8
bb6:
  %t33 = load i64, ptr %l11
  store i64 %t33, ptr %l0
  %t34 = load i64, ptr %l0
  ret i64 %t34
bb7:
  br label %bb5
bb8:
  %t35 = load i64, ptr %l14
  %t36 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t35)
  %t37 = extractvalue { i64, i1 } %t36, 0
  %t38 = extractvalue { i64, i1 } %t36, 1
  br i1 %t38, label %check.2, label %checked.3
check.2:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 8, i64 331)
  unreachable
checked.3:
  store i64 %t37, ptr %l15
  %t39 = load i64, ptr %l15
  store i64 %t39, ptr %l0
  %t40 = load i64, ptr %l0
  ret i64 %t40
}

define i64 @"__saw_rt_proc_wait_fd"(i64 %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i64, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca i32, align 4
  %l5 = alloca i64, align 8
  %l6 = alloca i32, align 4
  %l7 = alloca i32, align 4
  %l8 = alloca i8, align 1
  %l9 = alloca i64, align 8
  %l10 = alloca i64, align 8
  %l11 = alloca i64, align 8
  %l12 = alloca i64, align 8
  %l13 = alloca i64, align 8
  %l14 = alloca i8, align 1
  %l15 = alloca i64, align 8
  %l16 = alloca i32, align 4
  store i64 %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load i64, ptr %l1
  %t1 = inttoptr i64 %t0 to ptr
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  store ptr %t2, ptr %l2
  store i64 0, ptr %l5
  %t3 = load ptr, ptr %l2
  %t4 = load i64, ptr %l5
  %t5 = mul i64 %t4, 12
  %t6 = getelementptr i8, ptr %t3, i64 %t5
  %t7 = getelementptr i8, ptr %t6, i64 8
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l4
  %t9 = load i32, ptr %l4
  store i32 %t9, ptr %l6
  %t10 = trunc i64 0 to i32
  %t11 = sext i32 %t10 to i64
  %t12 = icmp eq i64 %t11, 0
  %t13 = trunc i64 0 to i32
  %t14 = xor i1 %t12, 1
  br i1 %t14, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 8, i64 343, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.1:
  store i32 %t13, ptr %l7
  %t15 = load i32, ptr %l6
  %t16 = load i32, ptr %l7
  %t17 = icmp sge i32 %t15, %t16
  %t18 = zext i1 %t17 to i8
  store i8 %t18, ptr %l8
  %t19 = load i8, ptr %l8
  %t20 = icmp ne i8 %t19, 0
  br i1 %t20, label %bb2, label %bb3
bb1:
  store i64 0, ptr %l11
  %t21 = load ptr, ptr %l2
  %t22 = load i64, ptr %l11
  %t23 = mul i64 %t22, 12
  %t24 = getelementptr i8, ptr %t21, i64 %t23
  %t25 = load i32, ptr %t24
  %t26 = sext i32 %t25 to i64
  %t27 = trunc i64 %t26 to i32
  %t28 = icmp eq i32 %t27, %t25
  %t29 = sext i32 %t25 to i64
  store i64 %t29, ptr %l12
  %t30 = load i64, ptr %l12
  %t31 = call i64 @__saw_rt_proc_exit_fd(i64 %t30)
  store i64 %t31, ptr %l13
  br label %bb4
bb2:
  %t32 = load i32, ptr %l4
  %t33 = sext i32 %t32 to i64
  %t34 = trunc i64 %t33 to i32
  %t35 = icmp eq i32 %t34, %t32
  %t36 = sext i32 %t32 to i64
  store i64 %t36, ptr %l9
  %t37 = load i64, ptr %l9
  store i64 %t37, ptr %l0
  %t38 = load i64, ptr %l0
  ret i64 %t38
bb3:
  br label %bb1
bb4:
  %t39 = load i64, ptr %l13
  store i64 %t39, ptr %l10
  %t40 = load i64, ptr %l10
  %t41 = icmp slt i64 %t40, 0
  %t42 = zext i1 %t41 to i8
  store i8 %t42, ptr %l14
  %t43 = load i8, ptr %l14
  %t44 = icmp ne i8 %t43, 0
  br i1 %t44, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l15
  %t45 = load i64, ptr %l10
  %t46 = trunc i64 %t45 to i32
  %t47 = sext i32 %t46 to i64
  %t48 = icmp eq i64 %t47, %t45
  %t49 = trunc i64 %t45 to i32
  %t50 = xor i1 %t48, 1
  br i1 %t50, label %cast.2, label %casted.3
cast.2:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 8, i64 350, ptr @.bytes.1, i64 28, i64 %t45)
  unreachable
casted.3:
  store i32 %t49, ptr %l16
  %t51 = load ptr, ptr %l2
  %t52 = load i64, ptr %l15
  %t53 = mul i64 %t52, 12
  %t54 = getelementptr i8, ptr %t51, i64 %t53
  %t55 = getelementptr i8, ptr %t54, i64 8
  %t56 = load i32, ptr %l16
  store i32 %t56, ptr %t55
  %t57 = load i64, ptr %l10
  store i64 %t57, ptr %l0
  %t58 = load i64, ptr %l0
  ret i64 %t58
bb6:
  %t59 = load i64, ptr %l10
  store i64 %t59, ptr %l0
  %t60 = load i64, ptr %l0
  ret i64 %t60
bb7:
  br label %bb5
}

define i64 @"__saw_rt_proc_try_wait"(i64 %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i64, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca i32, align 4
  %l5 = alloca ptr, align 8
  %l6 = alloca ptr, align 8
  %l7 = alloca ptr, align 8
  %l8 = alloca i64, align 8
  %l9 = alloca i8, align 1
  %l10 = alloca i8, align 1
  %l11 = alloca i32, align 4
  %l12 = alloca i64, align 8
  %l13 = alloca i32, align 4
  %l14 = alloca i32, align 4
  %l15 = alloca i32, align 4
  %l16 = alloca i8, align 1
  %l17 = alloca i32, align 4
  %l18 = alloca i32, align 4
  %l19 = alloca i8, align 1
  %l20 = alloca i64, align 8
  %l21 = alloca i64, align 8
  %l22 = alloca i8, align 1
  %l23 = alloca i8, align 1
  %l24 = alloca i64, align 8
  %l25 = alloca i8, align 1
  %l26 = alloca i8, align 1
  %l27 = alloca i8, align 1
  %l28 = alloca i64, align 8
  %l29 = alloca i64, align 8
  %l30 = alloca ptr, align 8
  %l31 = alloca i8, align 1
  %l32 = alloca i64, align 8
  %l33 = alloca i64, align 8
  store i64 %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load i64, ptr %l1
  %t1 = inttoptr i64 %t0 to ptr
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  store ptr %t2, ptr %l2
  store i32 0, ptr %l4
  store ptr %l4, ptr %l6
  %t3 = load ptr, ptr %l6
  store ptr %t3, ptr %l7
  %t4 = load ptr, ptr %l7
  store ptr %t4, ptr %l5
  store i64 0, ptr %l8
  store i8 0, ptr %l9
  store i8 1, ptr %l10
  br label %bb1
bb1:
  %t5 = load i8, ptr %l10
  %t6 = icmp ne i8 %t5, 0
  br i1 %t6, label %bb3, label %bb2
bb2:
  %t7 = load i8, ptr %l9
  %t8 = icmp ne i8 %t7, 0
  br i1 %t8, label %bb16, label %bb17
bb3:
  br label %bb4
bb4:
  store i64 0, ptr %l12
  %t9 = load ptr, ptr %l2
  %t10 = load i64, ptr %l12
  %t11 = mul i64 %t10, 12
  %t12 = getelementptr i8, ptr %t9, i64 %t11
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l5
  %t15 = load i32, ptr @"static proc.WNOHANG"
  %t16 = call i32 @waitpid(i32 %t13, ptr %t14, i32 %t15)
  store i32 %t16, ptr %l13
  br label %bb5
bb5:
  %t17 = load i32, ptr %l13
  store i32 %t17, ptr %l11
  %t18 = load i32, ptr %l11
  store i32 %t18, ptr %l14
  %t19 = trunc i64 0 to i32
  %t20 = sext i32 %t19 to i64
  %t21 = icmp eq i64 %t20, 0
  %t22 = trunc i64 0 to i32
  %t23 = xor i1 %t21, 1
  br i1 %t23, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 8, i64 370, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.1:
  store i32 %t22, ptr %l15
  %t24 = load i32, ptr %l14
  %t25 = load i32, ptr %l15
  %t26 = icmp sgt i32 %t24, %t25
  %t27 = zext i1 %t26 to i8
  store i8 %t27, ptr %l16
  %t28 = load i8, ptr %l16
  %t29 = icmp ne i8 %t28, 0
  br i1 %t29, label %bb7, label %bb8
bb6:
  br label %bb1
bb7:
  store i8 0, ptr %l10
  br label %bb6
bb8:
  %t30 = load i32, ptr %l11
  store i32 %t30, ptr %l17
  %t31 = trunc i64 0 to i32
  %t32 = sext i32 %t31 to i64
  %t33 = icmp eq i64 %t32, 0
  %t34 = trunc i64 0 to i32
  %t35 = xor i1 %t33, 1
  br i1 %t35, label %cast.2, label %casted.3
cast.2:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 8, i64 372, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.3:
  store i32 %t34, ptr %l18
  %t36 = load i32, ptr %l17
  %t37 = load i32, ptr %l18
  %t38 = icmp eq i32 %t36, %t37
  %t39 = zext i1 %t38 to i8
  store i8 %t39, ptr %l19
  %t40 = load i8, ptr %l19
  %t41 = icmp ne i8 %t40, 0
  br i1 %t41, label %bb9, label %bb10
bb9:
  store i8 1, ptr %l9
  store i8 0, ptr %l10
  br label %bb6
bb10:
  %t42 = call i64 @__saw_rt_last_syserror()
  store i64 %t42, ptr %l20
  br label %bb11
bb11:
  %t43 = load i64, ptr %l20
  store i64 %t43, ptr %l8
  %t44 = load i64, ptr %l8
  store i64 %t44, ptr %l21
  store i8 4, ptr %l22
  %t45 = load i8, ptr %l22
  %t46 = icmp eq i8 %t45, %t45
  store i8 %t45, ptr %l23
  %t47 = load i8, ptr %l23
  %t48 = zext i8 %t47 to i64
  %t49 = trunc i64 %t48 to i8
  %t50 = icmp eq i8 %t49, %t47
  %t51 = icmp sge i64 %t48, 0
  %t52 = and i1 %t50, %t51
  %t53 = zext i8 %t47 to i64
  store i64 %t53, ptr %l24
  %t54 = load i64, ptr %l21
  %t55 = load i64, ptr %l24
  %t56 = icmp ne i64 %t54, %t55
  %t57 = zext i1 %t56 to i8
  store i8 %t57, ptr %l25
  %t58 = load i8, ptr %l25
  %t59 = icmp ne i8 %t58, 0
  br i1 %t59, label %bb13, label %bb14
bb12:
  br label %bb6
bb13:
  store i8 0, ptr %l10
  br label %bb12
bb14:
  store i64 0, ptr %l8
  br label %bb12
bb15:
  %t60 = load ptr, ptr %l2
  call void @"saw proc.proc_job_close(p: UnsafePointer<proc.ProcJob>)"(ptr %t60)
  br label %bb18
bb16:
  store i8 1, ptr %l26
  %t61 = load i8, ptr %l26
  %t62 = icmp eq i8 %t61, %t61
  store i8 %t61, ptr %l27
  %t63 = load i8, ptr %l27
  %t64 = zext i8 %t63 to i64
  %t65 = trunc i64 %t64 to i8
  %t66 = icmp eq i8 %t65, %t63
  %t67 = icmp sge i64 %t64, 0
  %t68 = and i1 %t66, %t67
  %t69 = zext i8 %t63 to i64
  store i64 %t69, ptr %l28
  %t70 = load i64, ptr %l28
  %t71 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t70)
  %t72 = extractvalue { i64, i1 } %t71, 0
  %t73 = extractvalue { i64, i1 } %t71, 1
  br i1 %t73, label %check.4, label %checked.5
check.4:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 8, i64 386)
  unreachable
checked.5:
  store i64 %t72, ptr %l29
  %t74 = load i64, ptr %l29
  store i64 %t74, ptr %l0
  %t75 = load i64, ptr %l0
  ret i64 %t75
bb17:
  br label %bb15
bb18:
  %t76 = load i64, ptr %l1
  %t77 = inttoptr i64 %t76 to ptr
  store ptr %t77, ptr %l30
  %t78 = load ptr, ptr %l30
  call void @free(ptr %t78)
  br label %bb19
bb19:
  %t79 = load i64, ptr %l8
  %t80 = icmp ne i64 %t79, 0
  %t81 = zext i1 %t80 to i8
  store i8 %t81, ptr %l31
  %t82 = load i8, ptr %l31
  %t83 = icmp ne i8 %t82, 0
  br i1 %t83, label %bb21, label %bb22
bb20:
  %t84 = load i32, ptr %l4
  %t85 = sext i32 %t84 to i64
  %t86 = trunc i64 %t85 to i32
  %t87 = icmp eq i32 %t86, %t84
  %t88 = sext i32 %t84 to i64
  store i64 %t88, ptr %l33
  %t89 = load i64, ptr %l33
  store i64 %t89, ptr %l0
  %t90 = load i64, ptr %l0
  ret i64 %t90
bb21:
  %t91 = load i64, ptr %l8
  %t92 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t91)
  %t93 = extractvalue { i64, i1 } %t92, 0
  %t94 = extractvalue { i64, i1 } %t92, 1
  br i1 %t94, label %check.6, label %checked.7
check.6:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 8, i64 391)
  unreachable
checked.7:
  store i64 %t93, ptr %l32
  %t95 = load i64, ptr %l32
  store i64 %t95, ptr %l0
  %t96 = load i64, ptr %l0
  ret i64 %t96
bb22:
  br label %bb20
}

define void @"__saw_rt_proc_release"(i64 %p1) #0 {
entry:
  %l0 = alloca [0 x i8], align 1
  %l1 = alloca i64, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca i32, align 4
  %l5 = alloca i64, align 8
  %l6 = alloca i32, align 4
  %l7 = alloca ptr, align 8
  %l8 = alloca ptr, align 8
  %l9 = alloca i32, align 4
  %l10 = alloca ptr, align 8
  store i64 %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load i64, ptr %l1
  %t1 = inttoptr i64 %t0 to ptr
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  store ptr %t2, ptr %l2
  store i32 0, ptr %l4
  store i64 0, ptr %l5
  %t3 = load ptr, ptr %l2
  %t4 = load i64, ptr %l5
  %t5 = mul i64 %t4, 12
  %t6 = getelementptr i8, ptr %t3, i64 %t5
  %t7 = load i32, ptr %t6
  store i32 %t7, ptr %l6
  store ptr %l4, ptr %l7
  %t8 = load ptr, ptr %l7
  store ptr %t8, ptr %l8
  %t9 = load i32, ptr %l6
  %t10 = load ptr, ptr %l8
  %t11 = load i32, ptr @"static proc.WNOHANG"
  %t12 = call i32 @waitpid(i32 %t9, ptr %t10, i32 %t11)
  store i32 %t12, ptr %l9
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l2
  call void @"saw proc.proc_job_close(p: UnsafePointer<proc.ProcJob>)"(ptr %t13)
  br label %bb2
bb2:
  %t14 = load i64, ptr %l1
  %t15 = inttoptr i64 %t14 to ptr
  store ptr %t15, ptr %l10
  %t16 = load ptr, ptr %l10
  call void @free(ptr %t16)
  br label %bb3
bb3:
  ret void
}

define internal void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %p1, i64 %p2) #0 {
entry:
  %l0 = alloca [0 x i8], align 1
  %l1 = alloca ptr, align 8
  %l2 = alloca i64, align 8
  store ptr %p1, ptr %l1
  store i64 %p2, ptr %l2
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = load i64, ptr %l2
  call void @__saw_rt_panic(ptr %t0, i64 %t1)
  unreachable
}

define internal void @"saw std.string.string_literal(bytes: UnsafePointer<Int8>)"(ptr %ret, ptr %p1) #0 {
entry:
  %l0 = alloca [8 x i8], align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca [8 x i8], align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l2
  call void @llvm.memcpy.p0.p0.i64(ptr %l0, ptr %l2, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %ret, ptr %l0, i64 8, i1 false)
  ret void
}

define internal ptr @"saw std.string.string_bytes(text: &String)"(ptr noalias %p1) #0 {
entry:
  %l0 = alloca ptr, align 8
  %l1 = alloca ptr, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = load ptr, ptr %t0
  store ptr %t1, ptr %l0
  %t2 = load ptr, ptr %l0
  ret ptr %t2
}

define internal i64 @"saw std.string.string_length(text: &String)"(ptr noalias %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l2
  %t1 = load ptr, ptr %l2
  %t2 = call i64 @"saw std.string.String.len()"(ptr %t1)
  store i64 %t2, ptr %l3
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3
  store i64 %t3, ptr %l0
  %t4 = load i64, ptr %l0
  ret i64 %t4
}

define internal i64 @"saw proc.proc_spawn_impl(path: UnsafePointer<Int8>, argv: UnsafePointer<Int8>, envp: Int, flags: Int)"(ptr %p1, ptr %p2, i64 %p3, i64 %p4) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca i64, align 8
  %l5 = alloca i64, align 8
  %l6 = alloca i64, align 8
  %l7 = alloca i8, align 1
  %l8 = alloca i8, align 1
  %l9 = alloca i64, align 8
  %l10 = alloca i64, align 8
  %l11 = alloca i64, align 8
  %l12 = alloca i64, align 8
  %l13 = alloca i8, align 1
  %l14 = alloca i8, align 1
  %l15 = alloca i64, align 8
  %l16 = alloca i64, align 8
  %l17 = alloca [8 x i8], align 4
  %l18 = alloca [8 x i8], align 4
  %l19 = alloca i8, align 1
  %l20 = alloca ptr, align 8
  %l21 = alloca ptr, align 8
  %l22 = alloca i32, align 4
  %l23 = alloca i32, align 4
  %l24 = alloca i8, align 1
  %l25 = alloca i64, align 8
  %l26 = alloca i64, align 8
  %l27 = alloca i32, align 4
  %l28 = alloca i32, align 4
  %l29 = alloca i32, align 4
  %l30 = alloca i32, align 4
  %l31 = alloca i8, align 1
  %l32 = alloca i64, align 8
  %l33 = alloca i64, align 8
  %l34 = alloca i8, align 1
  %l35 = alloca i32, align 4
  %l36 = alloca i32, align 4
  %l37 = alloca i64, align 8
  %l38 = alloca i32, align 4
  %l39 = alloca i32, align 4
  %l40 = alloca i8, align 1
  %l41 = alloca i8, align 1
  %l42 = alloca i32, align 4
  %l43 = alloca i32, align 4
  %l44 = alloca i8, align 1
  %l45 = alloca i32, align 4
  %l46 = alloca i32, align 4
  %l47 = alloca i8, align 1
  %l48 = alloca i32, align 4
  %l49 = alloca i8, align 1
  %l50 = alloca ptr, align 8
  %l51 = alloca i32, align 4
  %l52 = alloca i8, align 1
  %l53 = alloca i32, align 4
  %l54 = alloca ptr, align 8
  %l55 = alloca i64, align 8
  %l56 = alloca ptr, align 8
  %l57 = alloca ptr, align 8
  %l58 = alloca ptr, align 8
  %l59 = alloca i64, align 8
  %l60 = alloca i64, align 8
  %l61 = alloca i64, align 8
  %l62 = alloca i64, align 8
  store ptr %p1, ptr %l1
  store ptr %p2, ptr %l2
  store i64 %p3, ptr %l3
  store i64 %p4, ptr %l4
  br label %bb0
bb0:
  %t0 = load i64, ptr %l4
  store i64 %t0, ptr %l6
  store i8 1, ptr %l7
  %t1 = load i8, ptr %l7
  %t2 = icmp eq i8 %t1, %t1
  store i8 %t1, ptr %l8
  %t3 = load i8, ptr %l8
  %t4 = zext i8 %t3 to i64
  %t5 = trunc i64 %t4 to i8
  %t6 = icmp eq i8 %t5, %t3
  %t7 = icmp sge i64 %t4, 0
  %t8 = and i1 %t6, %t7
  %t9 = zext i8 %t3 to i64
  store i64 %t9, ptr %l9
  %t10 = load i64, ptr %l6
  %t11 = load i64, ptr %l9
  %t12 = and i64 %t10, %t11
  store i64 %t12, ptr %l10
  %t13 = load i64, ptr %l10
  store i64 %t13, ptr %l5
  %t14 = load i64, ptr %l4
  store i64 %t14, ptr %l12
  store i8 2, ptr %l13
  %t15 = load i8, ptr %l13
  %t16 = icmp eq i8 %t15, %t15
  store i8 %t15, ptr %l14
  %t17 = load i8, ptr %l14
  %t18 = zext i8 %t17 to i64
  %t19 = trunc i64 %t18 to i8
  %t20 = icmp eq i8 %t19, %t17
  %t21 = icmp sge i64 %t18, 0
  %t22 = and i1 %t20, %t21
  %t23 = zext i8 %t17 to i64
  store i64 %t23, ptr %l15
  %t24 = load i64, ptr %l12
  %t25 = load i64, ptr %l15
  %t26 = and i64 %t24, %t25
  store i64 %t26, ptr %l16
  %t27 = load i64, ptr %l16
  store i64 %t27, ptr %l11
  %t28 = load i32, ptr @"static proc.NO_FD"
  store i32 %t28, ptr %l18
  %t29 = getelementptr i8, ptr %l18, i64 4
  %t30 = load i32, ptr @"static proc.NO_FD"
  store i32 %t30, ptr %t29
  call void @llvm.memcpy.p0.p0.i64(ptr %l17, ptr %l18, i64 8, i1 false)
  %t31 = load i64, ptr %l5
  %t32 = icmp ne i64 %t31, 0
  %t33 = zext i1 %t32 to i8
  store i8 %t33, ptr %l19
  %t34 = load i8, ptr %l19
  %t35 = icmp ne i8 %t34, 0
  br i1 %t35, label %bb2, label %bb3
bb1:
  %t36 = call i32 @fork()
  store i32 %t36, ptr %l28
  br label %bb9
bb2:
  store ptr %l17, ptr %l20
  %t37 = load ptr, ptr %l20
  store ptr %t37, ptr %l21
  %t38 = load ptr, ptr %l21
  %t39 = call i32 @pipe(ptr %t38)
  store i32 %t39, ptr %l22
  br label %bb5
bb3:
  br label %bb1
bb4:
  br label %bb1
bb5:
  %t40 = trunc i64 0 to i32
  %t41 = sext i32 %t40 to i64
  %t42 = icmp eq i64 %t41, 0
  %t43 = trunc i64 0 to i32
  %t44 = xor i1 %t42, 1
  br i1 %t44, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 8, i64 235, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.1:
  store i32 %t43, ptr %l23
  %t45 = load i32, ptr %l22
  %t46 = load i32, ptr %l23
  %t47 = icmp ne i32 %t45, %t46
  %t48 = zext i1 %t47 to i8
  store i8 %t48, ptr %l24
  %t49 = load i8, ptr %l24
  %t50 = icmp ne i8 %t49, 0
  br i1 %t50, label %bb6, label %bb7
bb6:
  %t51 = call i64 @__saw_rt_last_syserror()
  store i64 %t51, ptr %l25
  br label %bb8
bb7:
  br label %bb4
bb8:
  %t52 = load i64, ptr %l25
  %t53 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t52)
  %t54 = extractvalue { i64, i1 } %t53, 0
  %t55 = extractvalue { i64, i1 } %t53, 1
  br i1 %t55, label %check.2, label %checked.3
check.2:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 8, i64 236)
  unreachable
checked.3:
  store i64 %t54, ptr %l26
  %t56 = load i64, ptr %l26
  store i64 %t56, ptr %l0
  %t57 = load i64, ptr %l0
  ret i64 %t57
bb9:
  %t58 = load i32, ptr %l28
  store i32 %t58, ptr %l27
  %t59 = load i32, ptr %l27
  store i32 %t59, ptr %l29
  %t60 = trunc i64 0 to i32
  %t61 = sext i32 %t60 to i64
  %t62 = icmp eq i64 %t61, 0
  %t63 = trunc i64 0 to i32
  %t64 = xor i1 %t62, 1
  br i1 %t64, label %cast.4, label %casted.5
cast.4:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 8, i64 241, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.5:
  store i32 %t63, ptr %l30
  %t65 = load i32, ptr %l29
  %t66 = load i32, ptr %l30
  %t67 = icmp slt i32 %t65, %t66
  %t68 = zext i1 %t67 to i8
  store i8 %t68, ptr %l31
  %t69 = load i8, ptr %l31
  %t70 = icmp ne i8 %t69, 0
  br i1 %t70, label %bb11, label %bb12
bb10:
  %t71 = load i32, ptr %l27
  store i32 %t71, ptr %l38
  %t72 = trunc i64 0 to i32
  %t73 = sext i32 %t72 to i64
  %t74 = icmp eq i64 %t73, 0
  %t75 = trunc i64 0 to i32
  %t76 = xor i1 %t74, 1
  br i1 %t76, label %cast.6, label %casted.7
cast.6:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 8, i64 250, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.7:
  store i32 %t75, ptr %l39
  %t77 = load i32, ptr %l38
  %t78 = load i32, ptr %l39
  %t79 = icmp eq i32 %t77, %t78
  %t80 = zext i1 %t79 to i8
  store i8 %t80, ptr %l40
  %t81 = load i8, ptr %l40
  %t82 = icmp ne i8 %t81, 0
  br i1 %t82, label %bb20, label %bb21
bb11:
  %t83 = call i64 @__saw_rt_last_syserror()
  store i64 %t83, ptr %l33
  br label %bb13
bb12:
  br label %bb10
bb13:
  %t84 = load i64, ptr %l33
  store i64 %t84, ptr %l32
  %t85 = load i64, ptr %l5
  %t86 = icmp ne i64 %t85, 0
  %t87 = zext i1 %t86 to i8
  store i8 %t87, ptr %l34
  %t88 = load i8, ptr %l34
  %t89 = icmp ne i8 %t88, 0
  br i1 %t89, label %bb15, label %bb16
bb14:
  %t90 = load i64, ptr %l32
  %t91 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t90)
  %t92 = extractvalue { i64, i1 } %t91, 0
  %t93 = extractvalue { i64, i1 } %t91, 1
  br i1 %t93, label %check.8, label %checked.9
check.8:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 8, i64 247)
  unreachable
checked.9:
  store i64 %t92, ptr %l37
  %t94 = load i64, ptr %l37
  store i64 %t94, ptr %l0
  %t95 = load i64, ptr %l0
  ret i64 %t95
bb15:
  %t96 = load i32, ptr %l17
  %t97 = call i32 @close(i32 %t96)
  store i32 %t97, ptr %l35
  br label %bb17
bb16:
  br label %bb14
bb17:
  %t98 = getelementptr i8, ptr %l17, i64 4
  %t99 = load i32, ptr %t98
  %t100 = call i32 @close(i32 %t99)
  store i32 %t100, ptr %l36
  br label %bb18
bb18:
  br label %bb14
bb19:
  %t101 = load i64, ptr %l5
  %t102 = icmp ne i64 %t101, 0
  %t103 = zext i1 %t102 to i8
  store i8 %t103, ptr %l52
  %t104 = load i8, ptr %l52
  %t105 = icmp ne i8 %t104, 0
  br i1 %t105, label %bb42, label %bb43
bb20:
  %t106 = load i64, ptr %l5
  %t107 = icmp ne i64 %t106, 0
  %t108 = zext i1 %t107 to i8
  store i8 %t108, ptr %l41
  %t109 = load i8, ptr %l41
  %t110 = icmp ne i8 %t109, 0
  br i1 %t110, label %bb23, label %bb24
bb21:
  br label %bb19
bb22:
  %t111 = load i64, ptr %l3
  %t112 = load i64, ptr @"static proc.NULL_ENVP"
  %t113 = icmp ne i64 %t111, %t112
  %t114 = zext i1 %t113 to i8
  store i8 %t114, ptr %l49
  %t115 = load i8, ptr %l49
  %t116 = icmp ne i8 %t115, 0
  br i1 %t116, label %bb36, label %bb37
bb23:
  %t117 = load i32, ptr %l17
  %t118 = call i32 @close(i32 %t117)
  store i32 %t118, ptr %l42
  br label %bb25
bb24:
  %t119 = load i64, ptr %l11
  %t120 = icmp ne i64 %t119, 0
  %t121 = zext i1 %t120 to i8
  store i8 %t121, ptr %l47
  %t122 = load i8, ptr %l47
  %t123 = icmp ne i8 %t122, 0
  br i1 %t123, label %bb32, label %bb33
bb25:
  %t124 = getelementptr i8, ptr %l17, i64 4
  %t125 = load i32, ptr %t124
  %t126 = load i32, ptr @"static proc.STDOUT_FILENO"
  %t127 = call i32 @dup2(i32 %t125, i32 %t126)
  store i32 %t127, ptr %l43
  br label %bb26
bb26:
  %t128 = load i64, ptr %l11
  %t129 = icmp ne i64 %t128, 0
  %t130 = zext i1 %t129 to i8
  store i8 %t130, ptr %l44
  %t131 = load i8, ptr %l44
  %t132 = icmp ne i8 %t131, 0
  br i1 %t132, label %bb28, label %bb29
bb27:
  %t133 = getelementptr i8, ptr %l17, i64 4
  %t134 = load i32, ptr %t133
  %t135 = call i32 @close(i32 %t134)
  store i32 %t135, ptr %l46
  br label %bb31
bb28:
  %t136 = getelementptr i8, ptr %l17, i64 4
  %t137 = load i32, ptr %t136
  %t138 = load i32, ptr @"static proc.STDERR_FILENO"
  %t139 = call i32 @dup2(i32 %t137, i32 %t138)
  store i32 %t139, ptr %l45
  br label %bb30
bb29:
  br label %bb27
bb30:
  br label %bb27
bb31:
  br label %bb22
bb32:
  %t140 = load i32, ptr @"static proc.STDOUT_FILENO"
  %t141 = load i32, ptr @"static proc.STDERR_FILENO"
  %t142 = call i32 @dup2(i32 %t140, i32 %t141)
  store i32 %t142, ptr %l48
  br label %bb34
bb33:
  br label %bb22
bb34:
  br label %bb22
bb35:
  %t143 = load ptr, ptr %l1
  %t144 = load ptr, ptr %l2
  %t145 = call i32 @execvp(ptr %t143, ptr %t144)
  store i32 %t145, ptr %l51
  br label %bb39
bb36:
  %t146 = load i64, ptr %l3
  %t147 = inttoptr i64 %t146 to ptr
  store ptr %t147, ptr %l50
  %t148 = load ptr, ptr %l50
  call void @__saw_environ_set(ptr %t148)
  br label %bb38
bb37:
  br label %bb35
bb38:
  br label %bb35
bb39:
  %t149 = load i32, ptr @"static proc.EXEC_FAILED_STATUS"
  call void @_exit(i32 %t149)
  br label %bb40
bb40:
  store i64 0, ptr %l0
  %t150 = load i64, ptr %l0
  ret i64 %t150
bb41:
  store i64 12, ptr %l55
  br label %bb45
bb42:
  %t151 = getelementptr i8, ptr %l17, i64 4
  %t152 = load i32, ptr %t151
  %t153 = call i32 @close(i32 %t152)
  store i32 %t153, ptr %l53
  br label %bb44
bb43:
  br label %bb41
bb44:
  br label %bb41
bb45:
  %t154 = load i64, ptr %l55
  %t155 = call ptr @malloc(i64 %t154)
  store ptr %t155, ptr %l56
  br label %bb46
bb46:
  %t156 = load ptr, ptr %l56
  store ptr %t156, ptr %l54
  %t157 = load ptr, ptr %l54
  store ptr %t157, ptr %l58
  %t158 = load ptr, ptr %l58
  store ptr %t158, ptr %l57
  store i64 0, ptr %l59
  %t159 = load ptr, ptr %l57
  %t160 = load i64, ptr %l59
  %t161 = mul i64 %t160, 12
  %t162 = getelementptr i8, ptr %t159, i64 %t161
  %t163 = load i32, ptr %l27
  store i32 %t163, ptr %t162
  store i64 0, ptr %l60
  %t164 = load ptr, ptr %l57
  %t165 = load i64, ptr %l60
  %t166 = mul i64 %t165, 12
  %t167 = getelementptr i8, ptr %t164, i64 %t166
  %t168 = getelementptr i8, ptr %t167, i64 4
  %t169 = load i32, ptr %l17
  store i32 %t169, ptr %t168
  store i64 0, ptr %l61
  %t170 = load ptr, ptr %l57
  %t171 = load i64, ptr %l61
  %t172 = mul i64 %t171, 12
  %t173 = getelementptr i8, ptr %t170, i64 %t172
  %t174 = getelementptr i8, ptr %t173, i64 8
  %t175 = load i32, ptr @"static proc.NO_FD"
  store i32 %t175, ptr %t174
  %t176 = load ptr, ptr %l54
  %t177 = ptrtoint ptr %t176 to i64
  store i64 %t177, ptr %l62
  %t178 = load i64, ptr %l62
  store i64 %t178, ptr %l0
  %t179 = load i64, ptr %l0
  ret i64 %t179
}

define internal i64 @"saw proc.merge_environ(overrides: UnsafePointer<UnsafePointer<Int8>>)"(ptr %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca i64, align 8
  %l5 = alloca i64, align 8
  %l6 = alloca i64, align 8
  %l7 = alloca i8, align 1
  %l8 = alloca i64, align 8
  %l9 = alloca i64, align 8
  %l10 = alloca i64, align 8
  %l11 = alloca i64, align 8
  %l12 = alloca i8, align 1
  %l13 = alloca i64, align 8
  %l14 = alloca i64, align 8
  %l15 = alloca i64, align 8
  %l16 = alloca ptr, align 8
  %l17 = alloca i64, align 8
  %l18 = alloca i64, align 8
  %l19 = alloca i64, align 8
  %l20 = alloca ptr, align 8
  %l21 = alloca i64, align 8
  %l22 = alloca i8, align 1
  %l23 = alloca ptr, align 8
  %l24 = alloca ptr, align 8
  %l25 = alloca i64, align 8
  %l26 = alloca i64, align 8
  %l27 = alloca i8, align 1
  %l28 = alloca ptr, align 8
  %l29 = alloca i64, align 8
  %l30 = alloca i8, align 1
  %l31 = alloca i64, align 8
  %l32 = alloca i8, align 1
  %l33 = alloca ptr, align 8
  %l34 = alloca i64, align 8
  %l35 = alloca i8, align 1
  %l36 = alloca i64, align 8
  %l37 = alloca i8, align 1
  %l38 = alloca i64, align 8
  %l39 = alloca i64, align 8
  %l40 = alloca i64, align 8
  %l41 = alloca i64, align 8
  %l42 = alloca i8, align 1
  %l43 = alloca i64, align 8
  %l44 = alloca i64, align 8
  %l45 = alloca i64, align 8
  %l46 = alloca i64, align 8
  %l47 = alloca ptr, align 8
  %l48 = alloca ptr, align 8
  %l49 = alloca i64, align 8
  %l50 = alloca i64, align 8
  %l51 = alloca i64, align 8
  %l52 = alloca i8, align 1
  %l53 = alloca i64, align 8
  %l54 = alloca i8, align 1
  %l55 = alloca i64, align 8
  %l56 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = call ptr @__saw_environ_get()
  store ptr %t0, ptr %l3
  br label %bb1
bb1:
  %t1 = load ptr, ptr %l3
  store ptr %t1, ptr %l2
  store i64 0, ptr %l4
  br label %bb2
bb2:
  %t2 = load i64, ptr %l4
  store i64 %t2, ptr %l5
  %t3 = load ptr, ptr %l1
  %t4 = load i64, ptr %l5
  %t5 = mul i64 %t4, 8
  %t6 = getelementptr i8, ptr %t3, i64 %t5
  %t7 = load ptr, ptr %t6
  %t8 = ptrtoint ptr %t7 to i64
  store i64 %t8, ptr %l6
  %t9 = load i64, ptr %l6
  %t10 = icmp ne i64 %t9, 0
  %t11 = zext i1 %t10 to i8
  store i8 %t11, ptr %l7
  %t12 = load i8, ptr %l7
  %t13 = icmp ne i8 %t12, 0
  br i1 %t13, label %bb4, label %bb3
bb3:
  store i64 0, ptr %l9
  br label %bb6
bb4:
  br label %bb5
bb5:
  %t14 = load i64, ptr %l4
  %t15 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %t14, i64 1)
  %t16 = extractvalue { i64, i1 } %t15, 0
  %t17 = extractvalue { i64, i1 } %t15, 1
  br i1 %t17, label %check.0, label %checked.1
check.0:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 8, i64 174)
  unreachable
checked.1:
  store i64 %t16, ptr %l8
  %t18 = load i64, ptr %l8
  store i64 %t18, ptr %l4
  br label %bb2
bb6:
  %t19 = load i64, ptr %l9
  store i64 %t19, ptr %l10
  %t20 = load ptr, ptr %l2
  %t21 = load i64, ptr %l10
  %t22 = mul i64 %t21, 8
  %t23 = getelementptr i8, ptr %t20, i64 %t22
  %t24 = load ptr, ptr %t23
  %t25 = ptrtoint ptr %t24 to i64
  store i64 %t25, ptr %l11
  %t26 = load i64, ptr %l11
  %t27 = icmp ne i64 %t26, 0
  %t28 = zext i1 %t27 to i8
  store i8 %t28, ptr %l12
  %t29 = load i8, ptr %l12
  %t30 = icmp ne i8 %t29, 0
  br i1 %t30, label %bb8, label %bb7
bb7:
  store i64 8, ptr %l15
  br label %bb10
bb8:
  br label %bb9
bb9:
  %t31 = load i64, ptr %l9
  %t32 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %t31, i64 1)
  %t33 = extractvalue { i64, i1 } %t32, 0
  %t34 = extractvalue { i64, i1 } %t32, 1
  br i1 %t34, label %check.2, label %checked.3
check.2:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 8, i64 178)
  unreachable
checked.3:
  store i64 %t33, ptr %l13
  %t35 = load i64, ptr %l13
  store i64 %t35, ptr %l9
  br label %bb6
bb10:
  %t36 = load i64, ptr %l15
  store i64 %t36, ptr %l14
  %t37 = load i64, ptr %l9
  %t38 = load i64, ptr %l4
  %t39 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %t37, i64 %t38)
  %t40 = extractvalue { i64, i1 } %t39, 0
  %t41 = extractvalue { i64, i1 } %t39, 1
  br i1 %t41, label %check.4, label %checked.5
check.4:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 8, i64 182)
  unreachable
checked.5:
  store i64 %t40, ptr %l17
  %t42 = load i64, ptr %l17
  %t43 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %t42, i64 1)
  %t44 = extractvalue { i64, i1 } %t43, 0
  %t45 = extractvalue { i64, i1 } %t43, 1
  br i1 %t45, label %check.6, label %checked.7
check.6:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 8, i64 182)
  unreachable
checked.7:
  store i64 %t44, ptr %l18
  %t46 = load i64, ptr %l18
  %t47 = load i64, ptr %l14
  %t48 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %t46, i64 %t47)
  %t49 = extractvalue { i64, i1 } %t48, 0
  %t50 = extractvalue { i64, i1 } %t48, 1
  br i1 %t50, label %check.8, label %checked.9
check.8:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 8, i64 182)
  unreachable
checked.9:
  store i64 %t49, ptr %l19
  %t51 = load i64, ptr %l19
  %t52 = call ptr @malloc(i64 %t51)
  store ptr %t52, ptr %l20
  br label %bb11
bb11:
  %t53 = load ptr, ptr %l20
  store ptr %t53, ptr %l16
  %t54 = load ptr, ptr %l16
  %t55 = ptrtoint ptr %t54 to i64
  store i64 %t55, ptr %l21
  %t56 = load i64, ptr %l21
  %t57 = load i64, ptr @"static proc.NULL_ENVP"
  %t58 = icmp eq i64 %t56, %t57
  %t59 = zext i1 %t58 to i8
  store i8 %t59, ptr %l22
  %t60 = load i8, ptr %l22
  %t61 = icmp ne i8 %t60, 0
  br i1 %t61, label %bb13, label %bb14
bb12:
  %t62 = load ptr, ptr %l16
  store ptr %t62, ptr %l24
  %t63 = load ptr, ptr %l24
  store ptr %t63, ptr %l23
  store i64 0, ptr %l25
  store i64 0, ptr %l26
  br label %bb15
bb13:
  %t64 = load i64, ptr @"static proc.NULL_ENVP"
  store i64 %t64, ptr %l0
  %t65 = load i64, ptr %l0
  ret i64 %t65
bb14:
  br label %bb12
bb15:
  %t66 = load i64, ptr %l26
  %t67 = load i64, ptr %l9
  %t68 = icmp slt i64 %t66, %t67
  %t69 = zext i1 %t68 to i8
  store i8 %t69, ptr %l27
  %t70 = load i8, ptr %l27
  %t71 = icmp ne i8 %t70, 0
  br i1 %t71, label %bb17, label %bb16
bb16:
  store i64 0, ptr %l41
  br label %bb30
bb17:
  br label %bb18
bb18:
  %t72 = load i64, ptr %l26
  store i64 %t72, ptr %l29
  %t73 = load ptr, ptr %l2
  %t74 = load i64, ptr %l29
  %t75 = mul i64 %t74, 8
  %t76 = getelementptr i8, ptr %t73, i64 %t75
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l28
  store i8 0, ptr %l30
  store i64 0, ptr %l31
  br label %bb19
bb19:
  %t78 = load i64, ptr %l31
  %t79 = load i64, ptr %l4
  %t80 = icmp slt i64 %t78, %t79
  %t81 = zext i1 %t80 to i8
  store i8 %t81, ptr %l32
  %t82 = load i8, ptr %l32
  %t83 = icmp ne i8 %t82, 0
  br i1 %t83, label %bb21, label %bb20
bb20:
  %t84 = load i8, ptr %l30
  %t85 = xor i8 %t84, 1
  store i8 %t85, ptr %l37
  %t86 = load i8, ptr %l37
  %t87 = icmp ne i8 %t86, 0
  br i1 %t87, label %bb28, label %bb29
bb21:
  br label %bb22
bb22:
  %t88 = load ptr, ptr %l28
  store ptr %t88, ptr %l33
  %t89 = load i64, ptr %l31
  store i64 %t89, ptr %l34
  %t90 = load ptr, ptr %l33
  %t91 = load ptr, ptr %l1
  %t92 = load i64, ptr %l34
  %t93 = mul i64 %t92, 8
  %t94 = getelementptr i8, ptr %t91, i64 %t93
  %t95 = load ptr, ptr %t94
  %t96 = call i8 @"saw proc.same_env_name(entry: UnsafePointer<Int8>, spec: UnsafePointer<Int8>)"(ptr %t90, ptr %t95)
  store i8 %t96, ptr %l35
  br label %bb24
bb23:
  %t97 = load i64, ptr %l31
  %t98 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %t97, i64 1)
  %t99 = extractvalue { i64, i1 } %t98, 0
  %t100 = extractvalue { i64, i1 } %t98, 1
  br i1 %t100, label %check.10, label %checked.11
check.10:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 8, i64 198)
  unreachable
checked.11:
  store i64 %t99, ptr %l36
  %t101 = load i64, ptr %l36
  store i64 %t101, ptr %l31
  br label %bb19
bb24:
  %t102 = load i8, ptr %l35
  %t103 = icmp ne i8 %t102, 0
  br i1 %t103, label %bb25, label %bb26
bb25:
  store i8 1, ptr %l30
  br label %bb23
bb26:
  br label %bb23
bb27:
  %t104 = load i64, ptr %l26
  %t105 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %t104, i64 1)
  %t106 = extractvalue { i64, i1 } %t105, 0
  %t107 = extractvalue { i64, i1 } %t105, 1
  br i1 %t107, label %check.12, label %checked.13
check.12:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 8, i64 204)
  unreachable
checked.13:
  store i64 %t106, ptr %l40
  %t108 = load i64, ptr %l40
  store i64 %t108, ptr %l26
  br label %bb15
bb28:
  %t109 = load i64, ptr %l25
  store i64 %t109, ptr %l38
  %t110 = load ptr, ptr %l23
  %t111 = load i64, ptr %l38
  %t112 = mul i64 %t111, 8
  %t113 = getelementptr i8, ptr %t110, i64 %t112
  %t114 = load ptr, ptr %l28
  store ptr %t114, ptr %t113
  %t115 = load i64, ptr %l25
  %t116 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %t115, i64 1)
  %t117 = extractvalue { i64, i1 } %t116, 0
  %t118 = extractvalue { i64, i1 } %t116, 1
  br i1 %t118, label %check.14, label %checked.15
check.14:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 8, i64 202)
  unreachable
checked.15:
  store i64 %t117, ptr %l39
  %t119 = load i64, ptr %l39
  store i64 %t119, ptr %l25
  br label %bb27
bb29:
  br label %bb27
bb30:
  %t120 = load i64, ptr %l41
  %t121 = load i64, ptr %l4
  %t122 = icmp slt i64 %t120, %t121
  %t123 = zext i1 %t122 to i8
  store i8 %t123, ptr %l42
  %t124 = load i8, ptr %l42
  %t125 = icmp ne i8 %t124, 0
  br i1 %t125, label %bb32, label %bb31
bb31:
  %t126 = load ptr, ptr %l16
  store ptr %t126, ptr %l48
  %t127 = load ptr, ptr %l48
  store ptr %t127, ptr %l47
  %t128 = load i64, ptr %l25
  %t129 = load i64, ptr %l14
  %t130 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %t128, i64 %t129)
  %t131 = extractvalue { i64, i1 } %t130, 0
  %t132 = extractvalue { i64, i1 } %t130, 1
  br i1 %t132, label %check.16, label %checked.17
check.16:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 8, i64 216)
  unreachable
checked.17:
  store i64 %t131, ptr %l50
  %t133 = load i64, ptr %l50
  store i64 %t133, ptr %l49
  store i64 0, ptr %l51
  br label %bb34
bb32:
  br label %bb33
bb33:
  %t134 = load i64, ptr %l25
  store i64 %t134, ptr %l43
  %t135 = load i64, ptr %l41
  store i64 %t135, ptr %l44
  %t136 = load ptr, ptr %l23
  %t137 = load i64, ptr %l43
  %t138 = mul i64 %t137, 8
  %t139 = getelementptr i8, ptr %t136, i64 %t138
  %t140 = load ptr, ptr %l1
  %t141 = load i64, ptr %l44
  %t142 = mul i64 %t141, 8
  %t143 = getelementptr i8, ptr %t140, i64 %t142
  %t144 = load ptr, ptr %t143
  store ptr %t144, ptr %t139
  %t145 = load i64, ptr %l25
  %t146 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %t145, i64 1)
  %t147 = extractvalue { i64, i1 } %t146, 0
  %t148 = extractvalue { i64, i1 } %t146, 1
  br i1 %t148, label %check.18, label %checked.19
check.18:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 8, i64 209)
  unreachable
checked.19:
  store i64 %t147, ptr %l45
  %t149 = load i64, ptr %l45
  store i64 %t149, ptr %l25
  %t150 = load i64, ptr %l41
  %t151 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %t150, i64 1)
  %t152 = extractvalue { i64, i1 } %t151, 0
  %t153 = extractvalue { i64, i1 } %t151, 1
  br i1 %t153, label %check.20, label %checked.21
check.20:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 8, i64 210)
  unreachable
checked.21:
  store i64 %t152, ptr %l46
  %t154 = load i64, ptr %l46
  store i64 %t154, ptr %l41
  br label %bb30
bb34:
  %t155 = load i64, ptr %l51
  %t156 = load i64, ptr %l14
  %t157 = icmp slt i64 %t155, %t156
  %t158 = zext i1 %t157 to i8
  store i8 %t158, ptr %l52
  %t159 = load i8, ptr %l52
  %t160 = icmp ne i8 %t159, 0
  br i1 %t160, label %bb36, label %bb35
bb35:
  %t161 = load ptr, ptr %l16
  %t162 = ptrtoint ptr %t161 to i64
  store i64 %t162, ptr %l56
  %t163 = load i64, ptr %l56
  store i64 %t163, ptr %l0
  %t164 = load i64, ptr %l0
  ret i64 %t164
bb36:
  br label %bb37
bb37:
  %t165 = load i64, ptr %l49
  %t166 = load i64, ptr %l51
  %t167 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %t165, i64 %t166)
  %t168 = extractvalue { i64, i1 } %t167, 0
  %t169 = extractvalue { i64, i1 } %t167, 1
  br i1 %t169, label %check.22, label %checked.23
check.22:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 8, i64 219)
  unreachable
checked.23:
  store i64 %t168, ptr %l53
  %t170 = trunc i64 0 to i8
  %t171 = sext i8 %t170 to i64
  %t172 = icmp eq i64 %t171, 0
  %t173 = trunc i64 0 to i8
  %t174 = xor i1 %t172, 1
  br i1 %t174, label %cast.24, label %casted.25
cast.24:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 8, i64 219, ptr @.bytes.2, i64 27, i64 0)
  unreachable
casted.25:
  store i8 %t173, ptr %l54
  %t175 = load ptr, ptr %l47
  %t176 = load i64, ptr %l53
  %t177 = mul i64 %t176, 1
  %t178 = getelementptr i8, ptr %t175, i64 %t177
  %t179 = load i8, ptr %l54
  store i8 %t179, ptr %t178
  %t180 = load i64, ptr %l51
  %t181 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %t180, i64 1)
  %t182 = extractvalue { i64, i1 } %t181, 0
  %t183 = extractvalue { i64, i1 } %t181, 1
  br i1 %t183, label %check.26, label %checked.27
check.26:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 8, i64 220)
  unreachable
checked.27:
  store i64 %t182, ptr %l55
  %t184 = load i64, ptr %l55
  store i64 %t184, ptr %l51
  br label %bb34
}

define internal void @"saw proc.proc_job_close(p: UnsafePointer<proc.ProcJob>)"(ptr %p1) #0 {
entry:
  %l0 = alloca [0 x i8], align 1
  %l1 = alloca ptr, align 8
  %l2 = alloca i32, align 4
  %l3 = alloca i64, align 8
  %l4 = alloca i32, align 4
  %l5 = alloca i32, align 4
  %l6 = alloca i8, align 1
  %l7 = alloca i32, align 4
  %l8 = alloca i64, align 8
  %l9 = alloca i32, align 4
  %l10 = alloca i64, align 8
  %l11 = alloca i32, align 4
  %l12 = alloca i32, align 4
  %l13 = alloca i8, align 1
  %l14 = alloca i32, align 4
  %l15 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  store i64 0, ptr %l3
  %t0 = load ptr, ptr %l1
  %t1 = load i64, ptr %l3
  %t2 = mul i64 %t1, 12
  %t3 = getelementptr i8, ptr %t0, i64 %t2
  %t4 = getelementptr i8, ptr %t3, i64 4
  %t5 = load i32, ptr %t4
  store i32 %t5, ptr %l2
  %t6 = load i32, ptr %l2
  store i32 %t6, ptr %l4
  %t7 = trunc i64 0 to i32
  %t8 = sext i32 %t7 to i64
  %t9 = icmp eq i64 %t8, 0
  %t10 = trunc i64 0 to i32
  %t11 = xor i1 %t9, 1
  br i1 %t11, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 8, i64 123, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.1:
  store i32 %t10, ptr %l5
  %t12 = load i32, ptr %l4
  %t13 = load i32, ptr %l5
  %t14 = icmp sge i32 %t12, %t13
  %t15 = zext i1 %t14 to i8
  store i8 %t15, ptr %l6
  %t16 = load i8, ptr %l6
  %t17 = icmp ne i8 %t16, 0
  br i1 %t17, label %bb2, label %bb3
bb1:
  store i64 0, ptr %l10
  %t18 = load ptr, ptr %l1
  %t19 = load i64, ptr %l10
  %t20 = mul i64 %t19, 12
  %t21 = getelementptr i8, ptr %t18, i64 %t20
  %t22 = getelementptr i8, ptr %t21, i64 8
  %t23 = load i32, ptr %t22
  store i32 %t23, ptr %l9
  %t24 = load i32, ptr %l9
  store i32 %t24, ptr %l11
  %t25 = trunc i64 0 to i32
  %t26 = sext i32 %t25 to i64
  %t27 = icmp eq i64 %t26, 0
  %t28 = trunc i64 0 to i32
  %t29 = xor i1 %t27, 1
  br i1 %t29, label %cast.2, label %casted.3
cast.2:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 8, i64 128, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.3:
  store i32 %t28, ptr %l12
  %t30 = load i32, ptr %l11
  %t31 = load i32, ptr %l12
  %t32 = icmp sge i32 %t30, %t31
  %t33 = zext i1 %t32 to i8
  store i8 %t33, ptr %l13
  %t34 = load i8, ptr %l13
  %t35 = icmp ne i8 %t34, 0
  br i1 %t35, label %bb6, label %bb7
bb2:
  %t36 = load i32, ptr %l2
  %t37 = call i32 @close(i32 %t36)
  store i32 %t37, ptr %l7
  br label %bb4
bb3:
  br label %bb1
bb4:
  store i64 0, ptr %l8
  %t38 = load ptr, ptr %l1
  %t39 = load i64, ptr %l8
  %t40 = mul i64 %t39, 12
  %t41 = getelementptr i8, ptr %t38, i64 %t40
  %t42 = getelementptr i8, ptr %t41, i64 4
  %t43 = load i32, ptr @"static proc.NO_FD"
  store i32 %t43, ptr %t42
  br label %bb1
bb5:
  ret void
bb6:
  %t44 = load i32, ptr %l9
  %t45 = call i32 @close(i32 %t44)
  store i32 %t45, ptr %l14
  br label %bb8
bb7:
  br label %bb5
bb8:
  store i64 0, ptr %l15
  %t46 = load ptr, ptr %l1
  %t47 = load i64, ptr %l15
  %t48 = mul i64 %t47, 12
  %t49 = getelementptr i8, ptr %t46, i64 %t48
  %t50 = getelementptr i8, ptr %t49, i64 8
  %t51 = load i32, ptr @"static proc.NO_FD"
  store i32 %t51, ptr %t50
  br label %bb5
}

define internal i64 @"saw std.string.String.len()"(ptr noalias %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = load ptr, ptr %t0
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  store ptr %t2, ptr %l2
  %t3 = load i64, ptr @"static std.string.LENGTH_SLOT"
  store i64 %t3, ptr %l4
  %t4 = load ptr, ptr %l2
  %t5 = load i64, ptr %l4
  %t6 = mul i64 %t5, 8
  %t7 = getelementptr i8, ptr %t4, i64 %t6
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l0
  %t9 = load i64, ptr %l0
  ret i64 %t9
}

define internal i8 @"saw proc.same_env_name(entry: UnsafePointer<Int8>, spec: UnsafePointer<Int8>)"(ptr %p1, ptr %p2) #0 {
entry:
  %l0 = alloca i8, align 1
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca i8, align 1
  %l5 = alloca i8, align 1
  %l6 = alloca i8, align 1
  %l7 = alloca i64, align 8
  %l8 = alloca i8, align 1
  %l9 = alloca i64, align 8
  %l10 = alloca i8, align 1
  %l11 = alloca i8, align 1
  %l12 = alloca i8, align 1
  %l13 = alloca i8, align 1
  %l14 = alloca i8, align 1
  %l15 = alloca i8, align 1
  %l16 = alloca i8, align 1
  %l17 = alloca i64, align 8
  store ptr %p1, ptr %l1
  store ptr %p2, ptr %l2
  br label %bb0
bb0:
  store i64 0, ptr %l3
  store i8 0, ptr %l4
  store i8 1, ptr %l5
  br label %bb1
bb1:
  %t0 = load i8, ptr %l5
  %t1 = icmp ne i8 %t0, 0
  br i1 %t1, label %bb3, label %bb2
bb2:
  %t2 = load i8, ptr %l4
  store i8 %t2, ptr %l0
  %t3 = load i8, ptr %l0
  ret i8 %t3
bb3:
  br label %bb4
bb4:
  %t4 = load i64, ptr %l3
  store i64 %t4, ptr %l7
  %t5 = load ptr, ptr %l2
  %t6 = load i64, ptr %l7
  %t7 = mul i64 %t6, 1
  %t8 = getelementptr i8, ptr %t5, i64 %t7
  %t9 = load i8, ptr %t8
  store i8 %t9, ptr %l6
  %t10 = load i64, ptr %l3
  store i64 %t10, ptr %l9
  %t11 = load ptr, ptr %l1
  %t12 = load i64, ptr %l9
  %t13 = mul i64 %t12, 1
  %t14 = getelementptr i8, ptr %t11, i64 %t13
  %t15 = load i8, ptr %t14
  store i8 %t15, ptr %l8
  %t16 = load i8, ptr %l6
  %t17 = load i8, ptr @"static proc.EQUALS_BYTE"
  %t18 = icmp eq i8 %t16, %t17
  %t19 = zext i1 %t18 to i8
  store i8 %t19, ptr %l10
  %t20 = load i8, ptr %l10
  %t21 = icmp ne i8 %t20, 0
  br i1 %t21, label %bb6, label %bb7
bb5:
  br label %bb1
bb6:
  %t22 = load i8, ptr %l8
  %t23 = load i8, ptr @"static proc.EQUALS_BYTE"
  %t24 = icmp eq i8 %t22, %t23
  %t25 = zext i1 %t24 to i8
  store i8 %t25, ptr %l11
  %t26 = load i8, ptr %l11
  store i8 %t26, ptr %l4
  store i8 0, ptr %l5
  br label %bb5
bb7:
  %t27 = load i8, ptr %l6
  store i8 %t27, ptr %l13
  %t28 = trunc i64 0 to i8
  %t29 = sext i8 %t28 to i64
  %t30 = icmp eq i64 %t29, 0
  %t31 = trunc i64 0 to i8
  %t32 = xor i1 %t30, 1
  br i1 %t32, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 8, i64 148, ptr @.bytes.2, i64 27, i64 0)
  unreachable
casted.1:
  store i8 %t31, ptr %l14
  %t33 = load i8, ptr %l13
  %t34 = load i8, ptr %l14
  %t35 = icmp eq i8 %t33, %t34
  %t36 = zext i1 %t35 to i8
  store i8 %t36, ptr %l15
  %t37 = load i8, ptr %l15
  %t38 = icmp ne i8 %t37, 0
  br i1 %t38, label %bb10, label %bb9
bb8:
  %t39 = load i8, ptr %l12
  %t40 = icmp ne i8 %t39, 0
  br i1 %t40, label %bb11, label %bb12
bb9:
  %t41 = load i8, ptr %l8
  %t42 = load i8, ptr %l6
  %t43 = icmp ne i8 %t41, %t42
  %t44 = zext i1 %t43 to i8
  store i8 %t44, ptr %l16
  %t45 = load i8, ptr %l16
  store i8 %t45, ptr %l12
  br label %bb8
bb10:
  store i8 1, ptr %l12
  br label %bb8
bb11:
  store i8 0, ptr %l5
  br label %bb5
bb12:
  %t46 = load i64, ptr %l3
  %t47 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %t46, i64 1)
  %t48 = extractvalue { i64, i1 } %t47, 0
  %t49 = extractvalue { i64, i1 } %t47, 1
  br i1 %t49, label %check.2, label %checked.3
check.2:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 8, i64 153)
  unreachable
checked.3:
  store i64 %t48, ptr %l17
  %t50 = load i64, ptr %l17
  store i64 %t50, ptr %l3
  br label %bb5
}

define internal i64 @__saw_render_uint(ptr %out, i64 %v) #0 {
entry:
  %tmp = alloca [24 x i8], align 1
  br label %loop
loop:
  %n = phi i64 [ %v, %entry ], [ %q, %loop ]
  %i = phi i64 [ 24, %entry ], [ %i1, %loop ]
  %q = udiv i64 %n, 10
  %r = urem i64 %n, 10
  %d = trunc i64 %r to i8
  %c = add i8 %d, 48
  %i1 = sub i64 %i, 1
  %p = getelementptr i8, ptr %tmp, i64 %i1
  store i8 %c, ptr %p
  %more = icmp ne i64 %q, 0
  br i1 %more, label %loop, label %done
done:
  %len = sub i64 24, %i1
  %src = getelementptr i8, ptr %tmp, i64 %i1
  call void @llvm.memcpy.p0.p0.i64(ptr %out, ptr %src, i64 %len, i1 false)
  ret i64 %len
}

define internal i64 @__saw_render_int(ptr %out, i64 %v) #0 {
entry:
  %neg = icmp slt i64 %v, 0
  br i1 %neg, label %minus, label %plain
minus:
  store i8 45, ptr %out
  %mag = sub i64 0, %v
  %rest = getelementptr i8, ptr %out, i64 1
  %n = call i64 @__saw_render_uint(ptr %rest, i64 %mag)
  %len = add i64 %n, 1
  ret i64 %len
plain:
  %m = call i64 @__saw_render_uint(ptr %out, i64 %v)
  ret i64 %m
}

define internal i64 @__saw_append(ptr %buf, i64 %pos, ptr %src, i64 %len) #0 {
entry:
  %closed = icmp slt i64 %pos, 0
  br i1 %closed, label %keep, label %open
keep:
  ret i64 %pos
open:
  %room = sub i64 508, %pos
  %fits = icmp ule i64 %len, %room
  br i1 %fits, label %whole, label %back
whole:
  %at = getelementptr i8, ptr %buf, i64 %pos
  call void @llvm.memcpy.p0.p0.i64(ptr %at, ptr %src, i64 %len, i1 false)
  %end = add i64 %pos, %len
  ret i64 %end
back:
  %n = phi i64 [ %room, %open ], [ %n1, %step ]
  %none = icmp eq i64 %n, 0
  br i1 %none, label %cut, label %test
test:
  %p = getelementptr i8, ptr %src, i64 %n
  %b = load i8, ptr %p
  %hi = and i8 %b, -64
  %inside = icmp eq i8 %hi, -128
  br i1 %inside, label %step, label %cut
step:
  %n1 = sub i64 %n, 1
  br label %back
cut:
  %at2 = getelementptr i8, ptr %buf, i64 %pos
  call void @llvm.memcpy.p0.p0.i64(ptr %at2, ptr %src, i64 %n, i1 false)
  %stop = add i64 %pos, %n
  %shut = sub i64 -1, %stop
  ret i64 %shut
}

define internal i64 @__saw_finish(ptr %buf, i64 %pos) #0 {
entry:
  %cut = icmp slt i64 %pos, 0
  br i1 %cut, label %mark, label %line
mark:
  %stop = sub i64 -1, %pos
  %m0 = getelementptr i8, ptr %buf, i64 %stop
  store i8 -30, ptr %m0
  %m1 = getelementptr i8, ptr %m0, i64 1
  store i8 -128, ptr %m1
  %m2 = getelementptr i8, ptr %m0, i64 2
  store i8 -90, ptr %m2
  %marked = add i64 %stop, 3
  br label %line
line:
  %end = phi i64 [ %marked, %mark ], [ %pos, %entry ]
  %nl = getelementptr i8, ptr %buf, i64 %end
  store i8 10, ptr %nl
  %total = add i64 %end, 1
  ret i64 %total
}

define internal i64 @__saw_append_int(ptr %buf, i64 %pos, i64 %v) #0 {
entry:
  %tmp = alloca [24 x i8], align 1
  %n = call i64 @__saw_render_int(ptr %tmp, i64 %v)
  %end = call i64 @__saw_append(ptr %buf, i64 %pos, ptr %tmp, i64 %n)
  ret i64 %end
}

define internal i64 @__saw_append_uint(ptr %buf, i64 %pos, i64 %v) #0 {
entry:
  %tmp = alloca [24 x i8], align 1
  %n = call i64 @__saw_render_uint(ptr %tmp, i64 %v)
  %end = call i64 @__saw_append(ptr %buf, i64 %pos, ptr %tmp, i64 %n)
  ret i64 %end
}

@__saw_fail_at = private unnamed_addr constant [9 x i8] c"panic at "
@__saw_fail_colon = private unnamed_addr constant [2 x i8] c": "
@__saw_fail_true = private unnamed_addr constant [4 x i8] c"true"
@__saw_fail_false = private unnamed_addr constant [5 x i8] c"false"
@__saw_fail_overflow.reason = private unnamed_addr constant [16 x i8] c"integer overflow"
@__saw_fail_divide.reason = private unnamed_addr constant [16 x i8] c"division by zero"
@__saw_fail_shift.reason = private unnamed_addr constant [18 x i8] c"shift out of range"
@__saw_fail_unwrap.reason = private unnamed_addr constant [20 x i8] c"force unwrap of None"
@__saw_fail_try.reason = private unnamed_addr constant [11 x i8] c"try! failed"

define internal i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line) #0 {
entry:
  %at = call i64 @__saw_append(ptr %buf, i64 0, ptr @__saw_fail_at, i64 9)
  %named = call i64 @__saw_append(ptr %buf, i64 %at, ptr %file, i64 %file_len)
  %known = icmp sge i64 %line, 0
  br i1 %known, label %number, label %tail
number:
  %colon = call i64 @__saw_append(ptr %buf, i64 %named, ptr @__saw_fail_colon, i64 1)
  %lined = call i64 @__saw_append_uint(ptr %buf, i64 %colon, i64 %line)
  br label %tail
tail:
  %pos = phi i64 [ %named, %entry ], [ %lined, %number ]
  %end = call i64 @__saw_append(ptr %buf, i64 %pos, ptr @__saw_fail_colon, i64 2)
  ret i64 %end
}

define internal void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr %text, i64 %text_len) noinline noreturn #0 {
entry:
  %buf = alloca [512 x i8], align 1
  %head = call i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line)
  %done = call i64 @__saw_append(ptr %buf, i64 %head, ptr %text, i64 %text_len)
  %end = call i64 @__saw_finish(ptr %buf, i64 %done)
  call void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %buf, i64 %end)
  unreachable
}

define internal void @__saw_fail_signed(ptr %file, i64 %file_len, i64 %line, ptr %text, i64 %text_len, i64 %v) noinline noreturn #0 {
entry:
  %buf = alloca [512 x i8], align 1
  %head = call i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line)
  %pos = call i64 @__saw_append(ptr %buf, i64 %head, ptr %text, i64 %text_len)
  %done = call i64 @__saw_append_int(ptr %buf, i64 %pos, i64 %v)
  %end = call i64 @__saw_finish(ptr %buf, i64 %done)
  call void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %buf, i64 %end)
  unreachable
}

define internal void @__saw_fail_unsigned(ptr %file, i64 %file_len, i64 %line, ptr %text, i64 %text_len, i64 %v) noinline noreturn #0 {
entry:
  %buf = alloca [512 x i8], align 1
  %head = call i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line)
  %pos = call i64 @__saw_append(ptr %buf, i64 %head, ptr %text, i64 %text_len)
  %done = call i64 @__saw_append_uint(ptr %buf, i64 %pos, i64 %v)
  %end = call i64 @__saw_finish(ptr %buf, i64 %done)
  call void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %buf, i64 %end)
  unreachable
}

define internal void @__saw_fail_parts(ptr %file, i64 %file_len, i64 %line, ptr %text, i64 %text_len, ptr %parts, i64 %count) noinline noreturn #0 {
entry:
  %buf = alloca [512 x i8], align 1
  %head = call i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line)
  %pos = call i64 @__saw_append(ptr %buf, i64 %head, ptr %text, i64 %text_len)
  br label %loop
loop:
  %i = phi i64 [ 0, %entry ], [ %i1, %next ]
  %at = phi i64 [ %pos, %entry ], [ %after, %next ]
  %more = icmp slt i64 %i, %count
  br i1 %more, label %part, label %last
part:
  %offset = mul i64 %i, 24
  %p = getelementptr i8, ptr %parts, i64 %offset
  %kind = load i64, ptr %p
  %first = getelementptr i8, ptr %p, i64 8
  %second = getelementptr i8, ptr %p, i64 16
  switch i64 %kind, label %run [ i64 1, label %signed i64 2, label %unsigned i64 3, label %bool ]
run:
  %src = load ptr, ptr %first
  %len = load i64, ptr %second
  %ran = call i64 @__saw_append(ptr %buf, i64 %at, ptr %src, i64 %len)
  br label %next
signed:
  %sv = load i64, ptr %first
  %sd = call i64 @__saw_append_int(ptr %buf, i64 %at, i64 %sv)
  br label %next
unsigned:
  %uv = load i64, ptr %first
  %ud = call i64 @__saw_append_uint(ptr %buf, i64 %at, i64 %uv)
  br label %next
bool:
  %byte = load i8, ptr %first
  %yes = icmp ne i8 %byte, 0
  %word = select i1 %yes, ptr @__saw_fail_true, ptr @__saw_fail_false
  %size = select i1 %yes, i64 4, i64 5
  %bd = call i64 @__saw_append(ptr %buf, i64 %at, ptr %word, i64 %size)
  br label %next
next:
  %after = phi i64 [ %ran, %run ], [ %sd, %signed ], [ %ud, %unsigned ], [ %bd, %bool ]
  %i1 = add i64 %i, 1
  br label %loop
last:
  %done = phi i64 [ %at, %loop ]
  %end = call i64 @__saw_finish(ptr %buf, i64 %done)
  call void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %buf, i64 %end)
  unreachable
}

define internal void @__saw_fail_overflow(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_overflow.reason, i64 16)
  unreachable
}

define internal void @__saw_fail_divide(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_divide.reason, i64 16)
  unreachable
}

define internal void @__saw_fail_shift(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_shift.reason, i64 18)
  unreachable
}

define internal void @__saw_fail_unwrap(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_unwrap.reason, i64 20)
  unreachable
}

define internal void @__saw_fail_try(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_try.reason, i64 11)
  unreachable
}

attributes #0 = { "frame-pointer"="non-leaf" }
