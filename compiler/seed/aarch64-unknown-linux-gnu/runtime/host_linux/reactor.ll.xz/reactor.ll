; sawc2 link manifest
; target aarch64-unknown-linux-gnu
; speed -O2
; runtime none

target triple = "aarch64-unknown-linux-gnu"

@.bytes.0 = private unnamed_addr constant [11 x i8] c"reactor.saw"
@.bytes.1 = private unnamed_addr constant [28 x i8] c"cast to Int32 out of range: "
@.bytes.2 = private unnamed_addr constant [29 x i8] c"cast to UInt32 out of range: "
@"static reactor.EFD_NONBLOCK" = internal global i32 2048
@"static reactor.EV_IN_LEVEL" = internal global i32 1
@"static reactor.EPOLL_CTL_ADD" = internal global i32 1
@"static reactor.EV_OUT_ONESHOT" = internal global i32 1073741828
@"static reactor.EV_IN_ONESHOT" = internal global i32 1073741825
@"static reactor.EPOLL_CTL_MOD" = internal global i32 3
@"static reactor.EPOLL_CTL_DEL" = internal global i32 2
@"static reactor.POLL_EVENTS" = internal global i64 64
@"static std.string.LENGTH_SLOT" = internal global i64 -1

declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare i32 @epoll_create1(i32)
declare i32 @eventfd(i32, i32)
declare ptr @calloc(i64, i64)
declare i64 @__saw_epoll_data_offset()
declare i32 @epoll_ctl(i32, i32, i32, ptr)
declare i64 @__saw_epoll_event_size()
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare ptr @malloc(i64)
declare i32 @epoll_wait(i32, ptr, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @free(ptr)
declare i64 @read(i32, ptr, i64)
declare i32 @close(i32)
declare void @__saw_rt_panic(ptr, i64)
declare i64 @write(i32, ptr, i64)

define i64 @"__saw_rt_reactor_create"() #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i32, align 4
  %l2 = alloca i32, align 4
  %l3 = alloca i32, align 4
  %l4 = alloca i32, align 4
  %l5 = alloca i32, align 4
  %l6 = alloca i32, align 4
  %l7 = alloca ptr, align 8
  %l8 = alloca i64, align 8
  %l9 = alloca ptr, align 8
  %l10 = alloca ptr, align 8
  %l11 = alloca ptr, align 8
  %l12 = alloca i64, align 8
  %l13 = alloca i64, align 8
  %l14 = alloca i64, align 8
  %l15 = alloca i64, align 8
  %l16 = alloca [16 x i8], align 8
  %l17 = alloca [16 x i8], align 8
  %l18 = alloca ptr, align 8
  %l19 = alloca ptr, align 8
  %l20 = alloca ptr, align 8
  %l21 = alloca ptr, align 8
  %l22 = alloca i64, align 8
  %l23 = alloca ptr, align 8
  %l24 = alloca ptr, align 8
  %l25 = alloca i64, align 8
  %l26 = alloca ptr, align 8
  %l27 = alloca ptr, align 8
  %l28 = alloca i64, align 8
  %l29 = alloca i32, align 4
  %l30 = alloca i32, align 4
  %l31 = alloca i64, align 8
  br label %bb0
bb0:
  %t0 = trunc i64 0 to i32
  %t1 = sext i32 %t0 to i64
  %t2 = icmp eq i64 %t1, 0
  %t3 = trunc i64 0 to i32
  %t4 = xor i1 %t2, 1
  br i1 %t4, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 11, i64 93, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.1:
  store i32 %t3, ptr %l2
  %t5 = load i32, ptr %l2
  %t6 = call i32 @epoll_create1(i32 %t5)
  store i32 %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load i32, ptr %l3
  store i32 %t7, ptr %l1
  %t8 = trunc i64 0 to i32
  %t9 = zext i32 %t8 to i64
  %t10 = icmp eq i64 %t9, 0
  %t11 = icmp sge i64 0, 0
  %t12 = and i1 %t10, %t11
  %t13 = trunc i64 0 to i32
  %t14 = xor i1 %t12, 1
  br i1 %t14, label %cast.2, label %casted.3
cast.2:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 11, i64 94, ptr @.bytes.2, i64 29, i64 0)
  unreachable
casted.3:
  store i32 %t13, ptr %l5
  %t15 = load i32, ptr %l5
  %t16 = load i32, ptr @"static reactor.EFD_NONBLOCK"
  %t17 = call i32 @eventfd(i32 %t15, i32 %t16)
  store i32 %t17, ptr %l6
  br label %bb2
bb2:
  %t18 = load i32, ptr %l6
  store i32 %t18, ptr %l4
  store i64 24, ptr %l8
  br label %bb3
bb3:
  %t19 = load i64, ptr %l8
  %t20 = call ptr @calloc(i64 1, i64 %t19)
  store ptr %t20, ptr %l9
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l9
  store ptr %t21, ptr %l7
  %t22 = load ptr, ptr %l7
  store ptr %t22, ptr %l11
  %t23 = load ptr, ptr %l11
  store ptr %t23, ptr %l10
  store i64 0, ptr %l12
  %t24 = load i32, ptr %l1
  %t25 = sext i32 %t24 to i64
  %t26 = trunc i64 %t25 to i32
  %t27 = icmp eq i32 %t26, %t24
  %t28 = sext i32 %t24 to i64
  store i64 %t28, ptr %l13
  %t29 = load ptr, ptr %l10
  %t30 = load i64, ptr %l12
  %t31 = mul i64 %t30, 24
  %t32 = getelementptr i8, ptr %t29, i64 %t31
  %t33 = load i64, ptr %l13
  store i64 %t33, ptr %t32
  store i64 0, ptr %l14
  %t34 = load i32, ptr %l4
  %t35 = sext i32 %t34 to i64
  %t36 = trunc i64 %t35 to i32
  %t37 = icmp eq i32 %t36, %t34
  %t38 = sext i32 %t34 to i64
  store i64 %t38, ptr %l15
  %t39 = load ptr, ptr %l10
  %t40 = load i64, ptr %l14
  %t41 = mul i64 %t40, 24
  %t42 = getelementptr i8, ptr %t39, i64 %t41
  %t43 = getelementptr i8, ptr %t42, i64 8
  %t44 = load i64, ptr %l15
  store i64 %t44, ptr %t43
  store i64 0, ptr %l17
  %t45 = getelementptr i8, ptr %l17, i64 8
  store i64 0, ptr %t45
  call void @llvm.memcpy.p0.p0.i64(ptr %l16, ptr %l17, i64 16, i1 false)
  store ptr %l16, ptr %l19
  %t46 = load ptr, ptr %l19
  store ptr %t46, ptr %l20
  %t47 = load ptr, ptr %l20
  store ptr %t47, ptr %l18
  %t48 = load ptr, ptr %l18
  store ptr %t48, ptr %l21
  store i64 0, ptr %l22
  %t49 = load ptr, ptr %l21
  %t50 = load i64, ptr %l22
  %t51 = mul i64 %t50, 4
  %t52 = getelementptr i8, ptr %t49, i64 %t51
  %t53 = load i32, ptr @"static reactor.EV_IN_LEVEL"
  store i32 %t53, ptr %t52
  %t54 = load ptr, ptr %l18
  store ptr %t54, ptr %l24
  %t55 = call i64 @__saw_epoll_data_offset()
  store i64 %t55, ptr %l25
  br label %bb5
bb5:
  %t56 = load ptr, ptr %l24
  %t57 = load i64, ptr %l25
  %t58 = mul i64 %t57, 1
  %t59 = getelementptr i8, ptr %t56, i64 %t58
  store ptr %t59, ptr %l26
  %t60 = load ptr, ptr %l26
  store ptr %t60, ptr %l27
  %t61 = load ptr, ptr %l27
  store ptr %t61, ptr %l23
  store i64 0, ptr %l28
  %t62 = load ptr, ptr %l23
  %t63 = load i64, ptr %l28
  %t64 = mul i64 %t63, 8
  %t65 = getelementptr i8, ptr %t62, i64 %t64
  store i64 0, ptr %t65
  %t66 = load i32, ptr %l1
  %t67 = icmp eq i32 %t66, %t66
  store i32 %t66, ptr %l29
  %t68 = load i32, ptr %l29
  %t69 = load i32, ptr @"static reactor.EPOLL_CTL_ADD"
  %t70 = load i32, ptr %l4
  %t71 = load ptr, ptr %l18
  %t72 = call i32 @epoll_ctl(i32 %t68, i32 %t69, i32 %t70, ptr %t71)
  store i32 %t72, ptr %l30
  br label %bb6
bb6:
  %t73 = load ptr, ptr %l7
  %t74 = ptrtoint ptr %t73 to i64
  store i64 %t74, ptr %l31
  %t75 = load i64, ptr %l31
  store i64 %t75, ptr %l0
  %t76 = load i64, ptr %l0
  ret i64 %t76
}

define void @"__saw_rt_reactor_register"(i64 %p1, i64 %p2, i64 %p3, i64 %p4) #0 {
entry:
  %l0 = alloca [0 x i8], align 1
  %l1 = alloca i64, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca i64, align 8
  %l5 = alloca ptr, align 8
  %l6 = alloca ptr, align 8
  %l7 = alloca i64, align 8
  %l8 = alloca i64, align 8
  %l9 = alloca [16 x i8], align 8
  %l10 = alloca [16 x i8], align 8
  %l11 = alloca ptr, align 8
  %l12 = alloca ptr, align 8
  %l13 = alloca ptr, align 8
  %l14 = alloca i32, align 4
  %l15 = alloca i8, align 1
  %l16 = alloca ptr, align 8
  %l17 = alloca i64, align 8
  %l18 = alloca ptr, align 8
  %l19 = alloca ptr, align 8
  %l20 = alloca i64, align 8
  %l21 = alloca ptr, align 8
  %l22 = alloca ptr, align 8
  %l23 = alloca i64, align 8
  %l24 = alloca i32, align 4
  %l25 = alloca i32, align 4
  %l26 = alloca i32, align 4
  %l27 = alloca i32, align 4
  %l28 = alloca i32, align 4
  %l29 = alloca i32, align 4
  %l30 = alloca i32, align 4
  %l31 = alloca i8, align 1
  %l32 = alloca i32, align 4
  %l33 = alloca i32, align 4
  %l34 = alloca i32, align 4
  %l35 = alloca i32, align 4
  store i64 %p1, ptr %l1
  store i64 %p2, ptr %l2
  store i64 %p3, ptr %l3
  store i64 %p4, ptr %l4
  br label %bb0
bb0:
  %t0 = load i64, ptr %l1
  %t1 = inttoptr i64 %t0 to ptr
  store ptr %t1, ptr %l6
  %t2 = load ptr, ptr %l6
  store ptr %t2, ptr %l5
  store i64 0, ptr %l8
  %t3 = load ptr, ptr %l5
  %t4 = load i64, ptr %l8
  %t5 = mul i64 %t4, 24
  %t6 = getelementptr i8, ptr %t3, i64 %t5
  %t7 = load i64, ptr %t6
  store i64 %t7, ptr %l7
  store i64 0, ptr %l10
  %t8 = getelementptr i8, ptr %l10, i64 8
  store i64 0, ptr %t8
  call void @llvm.memcpy.p0.p0.i64(ptr %l9, ptr %l10, i64 16, i1 false)
  store ptr %l9, ptr %l12
  %t9 = load ptr, ptr %l12
  store ptr %t9, ptr %l13
  %t10 = load ptr, ptr %l13
  store ptr %t10, ptr %l11
  %t11 = load i64, ptr %l3
  %t12 = icmp ne i64 %t11, 0
  %t13 = zext i1 %t12 to i8
  store i8 %t13, ptr %l15
  %t14 = load i8, ptr %l15
  %t15 = icmp ne i8 %t14, 0
  br i1 %t15, label %bb2, label %bb3
bb1:
  %t16 = load ptr, ptr %l11
  store ptr %t16, ptr %l16
  store i64 0, ptr %l17
  %t17 = load ptr, ptr %l16
  %t18 = load i64, ptr %l17
  %t19 = mul i64 %t18, 4
  %t20 = getelementptr i8, ptr %t17, i64 %t19
  %t21 = load i32, ptr %l14
  store i32 %t21, ptr %t20
  %t22 = load ptr, ptr %l11
  store ptr %t22, ptr %l19
  %t23 = call i64 @__saw_epoll_data_offset()
  store i64 %t23, ptr %l20
  br label %bb4
bb2:
  %t24 = load i32, ptr @"static reactor.EV_OUT_ONESHOT"
  store i32 %t24, ptr %l14
  br label %bb1
bb3:
  %t25 = load i32, ptr @"static reactor.EV_IN_ONESHOT"
  store i32 %t25, ptr %l14
  br label %bb1
bb4:
  %t26 = load ptr, ptr %l19
  %t27 = load i64, ptr %l20
  %t28 = mul i64 %t27, 1
  %t29 = getelementptr i8, ptr %t26, i64 %t28
  store ptr %t29, ptr %l21
  %t30 = load ptr, ptr %l21
  store ptr %t30, ptr %l22
  %t31 = load ptr, ptr %l22
  store ptr %t31, ptr %l18
  store i64 0, ptr %l23
  %t32 = load ptr, ptr %l18
  %t33 = load i64, ptr %l23
  %t34 = mul i64 %t33, 8
  %t35 = getelementptr i8, ptr %t32, i64 %t34
  %t36 = load i64, ptr %l4
  store i64 %t36, ptr %t35
  %t37 = load i64, ptr %l7
  %t38 = trunc i64 %t37 to i32
  %t39 = sext i32 %t38 to i64
  %t40 = icmp eq i64 %t39, %t37
  %t41 = trunc i64 %t37 to i32
  %t42 = xor i1 %t40, 1
  br i1 %t42, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 11, i64 125, ptr @.bytes.1, i64 28, i64 %t37)
  unreachable
casted.1:
  store i32 %t41, ptr %l25
  %t43 = load i32, ptr @"static reactor.EPOLL_CTL_ADD"
  store i32 %t43, ptr %l26
  %t44 = load i64, ptr %l2
  %t45 = trunc i64 %t44 to i32
  %t46 = sext i32 %t45 to i64
  %t47 = icmp eq i64 %t46, %t44
  %t48 = trunc i64 %t44 to i32
  %t49 = xor i1 %t47, 1
  br i1 %t49, label %cast.2, label %casted.3
cast.2:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 11, i64 125, ptr @.bytes.1, i64 28, i64 %t44)
  unreachable
casted.3:
  store i32 %t48, ptr %l27
  %t50 = load i32, ptr %l25
  %t51 = load i32, ptr %l26
  %t52 = load i32, ptr %l27
  %t53 = load ptr, ptr %l11
  %t54 = call i32 @epoll_ctl(i32 %t50, i32 %t51, i32 %t52, ptr %t53)
  store i32 %t54, ptr %l28
  br label %bb5
bb5:
  %t55 = load i32, ptr %l28
  store i32 %t55, ptr %l24
  %t56 = load i32, ptr %l24
  store i32 %t56, ptr %l29
  %t57 = trunc i64 0 to i32
  %t58 = sext i32 %t57 to i64
  %t59 = icmp eq i64 %t58, 0
  %t60 = trunc i64 0 to i32
  %t61 = xor i1 %t59, 1
  br i1 %t61, label %cast.4, label %casted.5
cast.4:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 11, i64 126, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.5:
  store i32 %t60, ptr %l30
  %t62 = load i32, ptr %l29
  %t63 = load i32, ptr %l30
  %t64 = icmp ne i32 %t62, %t63
  %t65 = zext i1 %t64 to i8
  store i8 %t65, ptr %l31
  %t66 = load i8, ptr %l31
  %t67 = icmp ne i8 %t66, 0
  br i1 %t67, label %bb7, label %bb8
bb6:
  ret void
bb7:
  %t68 = load i64, ptr %l7
  %t69 = trunc i64 %t68 to i32
  %t70 = sext i32 %t69 to i64
  %t71 = icmp eq i64 %t70, %t68
  %t72 = trunc i64 %t68 to i32
  %t73 = xor i1 %t71, 1
  br i1 %t73, label %cast.6, label %casted.7
cast.6:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 11, i64 127, ptr @.bytes.1, i64 28, i64 %t68)
  unreachable
casted.7:
  store i32 %t72, ptr %l32
  %t74 = load i32, ptr @"static reactor.EPOLL_CTL_MOD"
  store i32 %t74, ptr %l33
  %t75 = load i64, ptr %l2
  %t76 = trunc i64 %t75 to i32
  %t77 = sext i32 %t76 to i64
  %t78 = icmp eq i64 %t77, %t75
  %t79 = trunc i64 %t75 to i32
  %t80 = xor i1 %t78, 1
  br i1 %t80, label %cast.8, label %casted.9
cast.8:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 11, i64 127, ptr @.bytes.1, i64 28, i64 %t75)
  unreachable
casted.9:
  store i32 %t79, ptr %l34
  %t81 = load i32, ptr %l32
  %t82 = load i32, ptr %l33
  %t83 = load i32, ptr %l34
  %t84 = load ptr, ptr %l11
  %t85 = call i32 @epoll_ctl(i32 %t81, i32 %t82, i32 %t83, ptr %t84)
  store i32 %t85, ptr %l35
  br label %bb9
bb8:
  br label %bb6
bb9:
  br label %bb6
}

define void @"__saw_rt_reactor_unregister"(i64 %p1, i64 %p2, i64 %p3) #0 {
entry:
  %l0 = alloca [0 x i8], align 1
  %l1 = alloca i64, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca ptr, align 8
  %l5 = alloca ptr, align 8
  %l6 = alloca i64, align 8
  %l7 = alloca i64, align 8
  %l8 = alloca [16 x i8], align 8
  %l9 = alloca [16 x i8], align 8
  %l10 = alloca ptr, align 8
  %l11 = alloca ptr, align 8
  %l12 = alloca ptr, align 8
  %l13 = alloca i32, align 4
  %l14 = alloca i32, align 4
  %l15 = alloca i32, align 4
  %l16 = alloca i32, align 4
  store i64 %p1, ptr %l1
  store i64 %p2, ptr %l2
  store i64 %p3, ptr %l3
  br label %bb0
bb0:
  %t0 = load i64, ptr %l1
  %t1 = inttoptr i64 %t0 to ptr
  store ptr %t1, ptr %l5
  %t2 = load ptr, ptr %l5
  store ptr %t2, ptr %l4
  store i64 0, ptr %l7
  %t3 = load ptr, ptr %l4
  %t4 = load i64, ptr %l7
  %t5 = mul i64 %t4, 24
  %t6 = getelementptr i8, ptr %t3, i64 %t5
  %t7 = load i64, ptr %t6
  store i64 %t7, ptr %l6
  store i64 0, ptr %l9
  %t8 = getelementptr i8, ptr %l9, i64 8
  store i64 0, ptr %t8
  call void @llvm.memcpy.p0.p0.i64(ptr %l8, ptr %l9, i64 16, i1 false)
  store ptr %l8, ptr %l11
  %t9 = load ptr, ptr %l11
  store ptr %t9, ptr %l12
  %t10 = load ptr, ptr %l12
  store ptr %t10, ptr %l10
  %t11 = load i64, ptr %l6
  %t12 = trunc i64 %t11 to i32
  %t13 = sext i32 %t12 to i64
  %t14 = icmp eq i64 %t13, %t11
  %t15 = trunc i64 %t11 to i32
  %t16 = xor i1 %t14, 1
  br i1 %t16, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 11, i64 146, ptr @.bytes.1, i64 28, i64 %t11)
  unreachable
casted.1:
  store i32 %t15, ptr %l13
  %t17 = load i32, ptr @"static reactor.EPOLL_CTL_DEL"
  store i32 %t17, ptr %l14
  %t18 = load i64, ptr %l2
  %t19 = trunc i64 %t18 to i32
  %t20 = sext i32 %t19 to i64
  %t21 = icmp eq i64 %t20, %t18
  %t22 = trunc i64 %t18 to i32
  %t23 = xor i1 %t21, 1
  br i1 %t23, label %cast.2, label %casted.3
cast.2:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 11, i64 146, ptr @.bytes.1, i64 28, i64 %t18)
  unreachable
casted.3:
  store i32 %t22, ptr %l15
  %t24 = load i32, ptr %l13
  %t25 = load i32, ptr %l14
  %t26 = load i32, ptr %l15
  %t27 = load ptr, ptr %l10
  %t28 = call i32 @epoll_ctl(i32 %t24, i32 %t25, i32 %t26, ptr %t27)
  store i32 %t28, ptr %l16
  br label %bb1
bb1:
  ret void
}

define i64 @"__saw_rt_reactor_poll"(i64 %p1, i64 %p2) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i64, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca ptr, align 8
  %l5 = alloca i64, align 8
  %l6 = alloca i64, align 8
  %l7 = alloca i64, align 8
  %l8 = alloca i64, align 8
  %l9 = alloca i64, align 8
  %l10 = alloca i64, align 8
  %l11 = alloca i64, align 8
  %l12 = alloca i64, align 8
  %l13 = alloca ptr, align 8
  %l14 = alloca i64, align 8
  %l15 = alloca ptr, align 8
  %l16 = alloca i32, align 4
  %l17 = alloca i8, align 1
  %l18 = alloca i32, align 4
  %l19 = alloca i32, align 4
  %l20 = alloca i64, align 8
  %l21 = alloca ptr, align 8
  %l22 = alloca i64, align 8
  %l23 = alloca i32, align 4
  %l24 = alloca i32, align 4
  %l25 = alloca ptr, align 8
  %l26 = alloca i32, align 4
  %l27 = alloca i32, align 4
  %l28 = alloca i64, align 8
  %l29 = alloca i64, align 8
  %l30 = alloca ptr, align 8
  %l31 = alloca i64, align 8
  %l32 = alloca i8, align 1
  %l33 = alloca i64, align 8
  %l34 = alloca i64, align 8
  %l35 = alloca i64, align 8
  %l36 = alloca i8, align 1
  %l37 = alloca ptr, align 8
  %l38 = alloca ptr, align 8
  %l39 = alloca i64, align 8
  %l40 = alloca i64, align 8
  %l41 = alloca ptr, align 8
  %l42 = alloca ptr, align 8
  %l43 = alloca i64, align 8
  %l44 = alloca i64, align 8
  %l45 = alloca i8, align 1
  %l46 = alloca ptr, align 8
  %l47 = alloca ptr, align 8
  %l48 = alloca i64, align 8
  %l49 = alloca i64, align 8
  %l50 = alloca i32, align 4
  %l51 = alloca i64, align 8
  %l52 = alloca i64, align 8
  %l53 = alloca ptr, align 8
  %l54 = alloca i64, align 8
  %l55 = alloca i8, align 1
  %l56 = alloca i64, align 8
  store i64 %p1, ptr %l1
  store i64 %p2, ptr %l2
  br label %bb0
bb0:
  %t0 = load i64, ptr %l1
  %t1 = inttoptr i64 %t0 to ptr
  store ptr %t1, ptr %l4
  %t2 = load ptr, ptr %l4
  store ptr %t2, ptr %l3
  store i64 0, ptr %l6
  %t3 = load ptr, ptr %l3
  %t4 = load i64, ptr %l6
  %t5 = mul i64 %t4, 24
  %t6 = getelementptr i8, ptr %t3, i64 %t5
  %t7 = load i64, ptr %t6
  store i64 %t7, ptr %l5
  store i64 0, ptr %l8
  %t8 = load ptr, ptr %l3
  %t9 = load i64, ptr %l8
  %t10 = mul i64 %t9, 24
  %t11 = getelementptr i8, ptr %t8, i64 %t10
  %t12 = getelementptr i8, ptr %t11, i64 8
  %t13 = load i64, ptr %t12
  store i64 %t13, ptr %l7
  %t14 = call i64 @__saw_epoll_event_size()
  store i64 %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load i64, ptr %l10
  store i64 %t15, ptr %l9
  %t16 = call i64 @__saw_epoll_data_offset()
  store i64 %t16, ptr %l12
  br label %bb2
bb2:
  %t17 = load i64, ptr %l12
  store i64 %t17, ptr %l11
  %t18 = load i64, ptr @"static reactor.POLL_EVENTS"
  %t19 = load i64, ptr %l9
  %t20 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %t18, i64 %t19)
  %t21 = extractvalue { i64, i1 } %t20, 0
  %t22 = extractvalue { i64, i1 } %t20, 1
  br i1 %t22, label %check.0, label %checked.1
check.0:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 11, i64 167)
  unreachable
checked.1:
  store i64 %t21, ptr %l14
  %t23 = load i64, ptr %l14
  %t24 = call ptr @malloc(i64 %t23)
  store ptr %t24, ptr %l15
  br label %bb3
bb3:
  %t25 = load ptr, ptr %l15
  store ptr %t25, ptr %l13
  %t26 = load i64, ptr %l2
  %t27 = icmp slt i64 %t26, 0
  %t28 = zext i1 %t27 to i8
  store i8 %t28, ptr %l17
  %t29 = load i8, ptr %l17
  %t30 = icmp ne i8 %t29, 0
  br i1 %t30, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l20
  %t31 = load ptr, ptr %l3
  %t32 = load i64, ptr %l20
  %t33 = mul i64 %t32, 24
  %t34 = getelementptr i8, ptr %t31, i64 %t33
  %t35 = getelementptr i8, ptr %t34, i64 16
  store ptr %t35, ptr %l21
  %t36 = load ptr, ptr %l21
  %t37 = call i64 @"saw Atomic.fetch_add(v: Int) args Int"(ptr %t36, i64 1)
  store i64 %t37, ptr %l22
  br label %bb7
bb5:
  store i32 -1, ptr %l18
  %t38 = load i32, ptr %l18
  store i32 %t38, ptr %l16
  br label %bb4
bb6:
  %t39 = load i64, ptr %l2
  %t40 = trunc i64 %t39 to i32
  %t41 = sext i32 %t40 to i64
  %t42 = icmp eq i64 %t41, %t39
  %t43 = trunc i64 %t39 to i32
  %t44 = xor i1 %t42, 1
  br i1 %t44, label %cast.2, label %casted.3
cast.2:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 11, i64 168, ptr @.bytes.1, i64 28, i64 %t39)
  unreachable
casted.3:
  store i32 %t43, ptr %l19
  %t45 = load i32, ptr %l19
  store i32 %t45, ptr %l16
  br label %bb4
bb7:
  %t46 = load i64, ptr %l5
  %t47 = trunc i64 %t46 to i32
  %t48 = sext i32 %t47 to i64
  %t49 = icmp eq i64 %t48, %t46
  %t50 = trunc i64 %t46 to i32
  %t51 = xor i1 %t49, 1
  br i1 %t51, label %cast.4, label %casted.5
cast.4:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 11, i64 173, ptr @.bytes.1, i64 28, i64 %t46)
  unreachable
casted.5:
  store i32 %t50, ptr %l24
  %t52 = load ptr, ptr %l13
  store ptr %t52, ptr %l25
  %t53 = load i64, ptr @"static reactor.POLL_EVENTS"
  %t54 = trunc i64 %t53 to i32
  %t55 = sext i32 %t54 to i64
  %t56 = icmp eq i64 %t55, %t53
  %t57 = trunc i64 %t53 to i32
  %t58 = xor i1 %t56, 1
  br i1 %t58, label %cast.6, label %casted.7
cast.6:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 11, i64 173, ptr @.bytes.1, i64 28, i64 %t53)
  unreachable
casted.7:
  store i32 %t57, ptr %l26
  %t59 = load i32, ptr %l24
  %t60 = load ptr, ptr %l25
  %t61 = load i32, ptr %l26
  %t62 = load i32, ptr %l16
  %t63 = call i32 @epoll_wait(i32 %t59, ptr %t60, i32 %t61, i32 %t62)
  store i32 %t63, ptr %l27
  br label %bb8
bb8:
  %t64 = load i32, ptr %l27
  store i32 %t64, ptr %l23
  store i64 0, ptr %l28
  store i64 -1, ptr %l29
  %t65 = load ptr, ptr %l3
  %t66 = load i64, ptr %l28
  %t67 = mul i64 %t66, 24
  %t68 = getelementptr i8, ptr %t65, i64 %t67
  %t69 = getelementptr i8, ptr %t68, i64 16
  store ptr %t69, ptr %l30
  %t70 = load ptr, ptr %l30
  %t71 = load i64, ptr %l29
  %t72 = call i64 @"saw Atomic.fetch_add(v: Int) args Int"(ptr %t70, i64 %t71)
  store i64 %t72, ptr %l31
  br label %bb9
bb9:
  store i8 0, ptr %l32
  store i64 0, ptr %l33
  br label %bb10
bb10:
  %t73 = load i64, ptr %l33
  store i64 %t73, ptr %l34
  %t74 = load i32, ptr %l23
  %t75 = sext i32 %t74 to i64
  %t76 = trunc i64 %t75 to i32
  %t77 = icmp eq i32 %t76, %t74
  %t78 = sext i32 %t74 to i64
  store i64 %t78, ptr %l35
  %t79 = load i64, ptr %l34
  %t80 = load i64, ptr %l35
  %t81 = icmp slt i64 %t79, %t80
  %t82 = zext i1 %t81 to i8
  store i8 %t82, ptr %l36
  %t83 = load i8, ptr %l36
  %t84 = icmp ne i8 %t83, 0
  br i1 %t84, label %bb12, label %bb11
bb11:
  %t85 = load i8, ptr %l32
  %t86 = icmp ne i8 %t85, 0
  br i1 %t86, label %bb17, label %bb18
bb12:
  %t87 = load ptr, ptr %l13
  store ptr %t87, ptr %l38
  %t88 = load i64, ptr %l33
  %t89 = load i64, ptr %l9
  %t90 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %t88, i64 %t89)
  %t91 = extractvalue { i64, i1 } %t90, 0
  %t92 = extractvalue { i64, i1 } %t90, 1
  br i1 %t92, label %check.8, label %checked.9
check.8:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 11, i64 178)
  unreachable
checked.9:
  store i64 %t91, ptr %l39
  %t93 = load i64, ptr %l39
  %t94 = load i64, ptr %l11
  %t95 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %t93, i64 %t94)
  %t96 = extractvalue { i64, i1 } %t95, 0
  %t97 = extractvalue { i64, i1 } %t95, 1
  br i1 %t97, label %check.10, label %checked.11
check.10:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 11, i64 178)
  unreachable
checked.11:
  store i64 %t96, ptr %l40
  %t98 = load ptr, ptr %l38
  %t99 = load i64, ptr %l40
  %t100 = mul i64 %t99, 1
  %t101 = getelementptr i8, ptr %t98, i64 %t100
  store ptr %t101, ptr %l41
  %t102 = load ptr, ptr %l41
  store ptr %t102, ptr %l42
  %t103 = load ptr, ptr %l42
  store ptr %t103, ptr %l37
  store i64 0, ptr %l44
  %t104 = load ptr, ptr %l37
  %t105 = load i64, ptr %l44
  %t106 = mul i64 %t105, 8
  %t107 = getelementptr i8, ptr %t104, i64 %t106
  %t108 = load i64, ptr %t107
  store i64 %t108, ptr %l43
  %t109 = load i64, ptr %l43
  %t110 = icmp ne i64 %t109, 0
  %t111 = zext i1 %t110 to i8
  store i8 %t111, ptr %l45
  %t112 = load i8, ptr %l45
  %t113 = icmp ne i8 %t112, 0
  br i1 %t113, label %bb14, label %bb15
bb13:
  %t114 = load i64, ptr %l33
  %t115 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %t114, i64 1)
  %t116 = extractvalue { i64, i1 } %t115, 0
  %t117 = extractvalue { i64, i1 } %t115, 1
  br i1 %t117, label %check.12, label %checked.13
check.12:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 11, i64 186)
  unreachable
checked.13:
  store i64 %t116, ptr %l49
  %t118 = load i64, ptr %l49
  store i64 %t118, ptr %l33
  br label %bb10
bb14:
  %t119 = load i64, ptr %l43
  %t120 = inttoptr i64 %t119 to ptr
  store ptr %t120, ptr %l47
  %t121 = load ptr, ptr %l47
  store ptr %t121, ptr %l46
  store i64 0, ptr %l48
  %t122 = load ptr, ptr %l46
  %t123 = load i64, ptr %l48
  %t124 = mul i64 %t123, 8
  %t125 = getelementptr i8, ptr %t122, i64 %t124
  store i64 0, ptr %t125
  br label %bb13
bb15:
  store i8 1, ptr %l32
  br label %bb13
bb16:
  %t126 = load ptr, ptr %l13
  call void @free(ptr %t126)
  br label %bb20
bb17:
  %t127 = load i64, ptr %l7
  %t128 = trunc i64 %t127 to i32
  %t129 = sext i32 %t128 to i64
  %t130 = icmp eq i64 %t129, %t127
  %t131 = trunc i64 %t127 to i32
  %t132 = xor i1 %t130, 1
  br i1 %t132, label %cast.14, label %casted.15
cast.14:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 11, i64 192, ptr @.bytes.1, i64 28, i64 %t127)
  unreachable
casted.15:
  store i32 %t131, ptr %l50
  %t133 = load i32, ptr %l50
  %t134 = load ptr, ptr %l13
  %t135 = call i64 @read(i32 %t133, ptr %t134, i64 8)
  store i64 %t135, ptr %l51
  br label %bb19
bb18:
  br label %bb16
bb19:
  br label %bb16
bb20:
  %t136 = load i8, ptr %l32
  %t137 = icmp ne i8 %t136, 0
  br i1 %t137, label %bb22, label %bb23
bb21:
  %t138 = load i32, ptr %l23
  %t139 = sext i32 %t138 to i64
  %t140 = trunc i64 %t139 to i32
  %t141 = icmp eq i32 %t140, %t138
  %t142 = sext i32 %t138 to i64
  store i64 %t142, ptr %l56
  %t143 = load i64, ptr %l56
  store i64 %t143, ptr %l0
  %t144 = load i64, ptr %l0
  ret i64 %t144
bb22:
  store i64 0, ptr %l52
  %t145 = load ptr, ptr %l3
  %t146 = load i64, ptr %l52
  %t147 = mul i64 %t146, 24
  %t148 = getelementptr i8, ptr %t145, i64 %t147
  %t149 = getelementptr i8, ptr %t148, i64 16
  store ptr %t149, ptr %l53
  %t150 = load ptr, ptr %l53
  %t151 = call i64 @"saw Atomic.load() args Int"(ptr %t150)
  store i64 %t151, ptr %l54
  br label %bb25
bb23:
  br label %bb21
bb24:
  br label %bb21
bb25:
  %t152 = load i64, ptr %l54
  %t153 = icmp sgt i64 %t152, 0
  %t154 = zext i1 %t153 to i8
  store i8 %t154, ptr %l55
  %t155 = load i8, ptr %l55
  %t156 = icmp ne i8 %t155, 0
  br i1 %t156, label %bb26, label %bb27
bb26:
  %t157 = load i64, ptr %l7
  call void @"saw reactor.rt_reactor_post(efd: Int)"(i64 %t157)
  br label %bb28
bb27:
  br label %bb24
bb28:
  br label %bb24
}

define void @"__saw_rt_reactor_wake"(i64 %p1) #0 {
entry:
  %l0 = alloca [0 x i8], align 1
  %l1 = alloca i64, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca i64, align 8
  store i64 %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load i64, ptr %l1
  %t1 = inttoptr i64 %t0 to ptr
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  store ptr %t2, ptr %l2
  store i64 0, ptr %l4
  %t3 = load ptr, ptr %l2
  %t4 = load i64, ptr %l4
  %t5 = mul i64 %t4, 24
  %t6 = getelementptr i8, ptr %t3, i64 %t5
  %t7 = getelementptr i8, ptr %t6, i64 8
  %t8 = load i64, ptr %t7
  call void @"saw reactor.rt_reactor_post(efd: Int)"(i64 %t8)
  br label %bb1
bb1:
  ret void
}

define void @"__saw_rt_reactor_destroy"(i64 %p1) #0 {
entry:
  %l0 = alloca [0 x i8], align 1
  %l1 = alloca i64, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca i64, align 8
  %l5 = alloca i32, align 4
  %l6 = alloca i32, align 4
  %l7 = alloca i64, align 8
  %l8 = alloca i32, align 4
  %l9 = alloca i32, align 4
  %l10 = alloca ptr, align 8
  store i64 %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load i64, ptr %l1
  %t1 = inttoptr i64 %t0 to ptr
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  store ptr %t2, ptr %l2
  store i64 0, ptr %l4
  %t3 = load ptr, ptr %l2
  %t4 = load i64, ptr %l4
  %t5 = mul i64 %t4, 24
  %t6 = getelementptr i8, ptr %t3, i64 %t5
  %t7 = load i64, ptr %t6
  %t8 = trunc i64 %t7 to i32
  %t9 = sext i32 %t8 to i64
  %t10 = icmp eq i64 %t9, %t7
  %t11 = trunc i64 %t7 to i32
  %t12 = xor i1 %t10, 1
  br i1 %t12, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 11, i64 217, ptr @.bytes.1, i64 28, i64 %t7)
  unreachable
casted.1:
  store i32 %t11, ptr %l5
  %t13 = load i32, ptr %l5
  %t14 = call i32 @close(i32 %t13)
  store i32 %t14, ptr %l6
  br label %bb1
bb1:
  store i64 0, ptr %l7
  %t15 = load ptr, ptr %l2
  %t16 = load i64, ptr %l7
  %t17 = mul i64 %t16, 24
  %t18 = getelementptr i8, ptr %t15, i64 %t17
  %t19 = getelementptr i8, ptr %t18, i64 8
  %t20 = load i64, ptr %t19
  %t21 = trunc i64 %t20 to i32
  %t22 = sext i32 %t21 to i64
  %t23 = icmp eq i64 %t22, %t20
  %t24 = trunc i64 %t20 to i32
  %t25 = xor i1 %t23, 1
  br i1 %t25, label %cast.2, label %casted.3
cast.2:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 11, i64 218, ptr @.bytes.1, i64 28, i64 %t20)
  unreachable
casted.3:
  store i32 %t24, ptr %l8
  %t26 = load i32, ptr %l8
  %t27 = call i32 @close(i32 %t26)
  store i32 %t27, ptr %l9
  br label %bb2
bb2:
  %t28 = load i64, ptr %l1
  %t29 = inttoptr i64 %t28 to ptr
  store ptr %t29, ptr %l10
  %t30 = load ptr, ptr %l10
  call void @free(ptr %t30)
  br label %bb3
bb3:
  ret void
}

define internal void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %p1, i64 %p2) #0 {
entry:
  %l0 = alloca [0 x i8], align 1
  %l1 = alloca ptr, align 8
  %l2 = alloca i64, align 8
  store ptr %p1, ptr %l1
  store i64 %p2, ptr %l2
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = load i64, ptr %l2
  call void @__saw_rt_panic(ptr %t0, i64 %t1)
  unreachable
}

define internal void @"saw std.string.string_literal(bytes: UnsafePointer<Int8>)"(ptr %ret, ptr %p1) #0 {
entry:
  %l0 = alloca [8 x i8], align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca [8 x i8], align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l2
  call void @llvm.memcpy.p0.p0.i64(ptr %l0, ptr %l2, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %ret, ptr %l0, i64 8, i1 false)
  ret void
}

define internal ptr @"saw std.string.string_bytes(text: &String)"(ptr noalias %p1) #0 {
entry:
  %l0 = alloca ptr, align 8
  %l1 = alloca ptr, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = load ptr, ptr %t0
  store ptr %t1, ptr %l0
  %t2 = load ptr, ptr %l0
  ret ptr %t2
}

define internal i64 @"saw std.string.string_length(text: &String)"(ptr noalias %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l2
  %t1 = load ptr, ptr %l2
  %t2 = call i64 @"saw std.string.String.len()"(ptr %t1)
  store i64 %t2, ptr %l3
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3
  store i64 %t3, ptr %l0
  %t4 = load i64, ptr %l0
  ret i64 %t4
}

define internal i64 @"saw Atomic.fetch_add(v: Int) args Int"(ptr %p1, i64 %p2) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca i64, align 8
  store ptr %p1, ptr %l1
  store i64 %p2, ptr %l2
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l3
  %t1 = load ptr, ptr %l3
  %t2 = load i64, ptr %l2
  %t3 = call i64 @"saw atomic_add_word(a: &Atomic<T>, v: Int) inst Int"(ptr %t1, i64 %t2)
  store i64 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i64, ptr %l4
  store i64 %t4, ptr %l0
  %t5 = load i64, ptr %l0
  ret i64 %t5
}

define internal i64 @"saw Atomic.load() args Int"(ptr %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l2
  %t1 = load ptr, ptr %l2
  %t2 = call i64 @"saw atomic_load_word(a: &Atomic<T>) inst Int"(ptr %t1)
  store i64 %t2, ptr %l3
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3
  store i64 %t3, ptr %l0
  %t4 = load i64, ptr %l0
  ret i64 %t4
}

define internal void @"saw reactor.rt_reactor_post(efd: Int)"(i64 %p1) #0 {
entry:
  %l0 = alloca [0 x i8], align 1
  %l1 = alloca i64, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca i32, align 4
  %l4 = alloca ptr, align 8
  %l5 = alloca ptr, align 8
  %l6 = alloca i64, align 8
  store i64 %p1, ptr %l1
  br label %bb0
bb0:
  store i64 1, ptr %l2
  %t0 = load i64, ptr %l1
  %t1 = trunc i64 %t0 to i32
  %t2 = sext i32 %t1 to i64
  %t3 = icmp eq i64 %t2, %t0
  %t4 = trunc i64 %t0 to i32
  %t5 = xor i1 %t3, 1
  br i1 %t5, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 11, i64 152, ptr @.bytes.1, i64 28, i64 %t0)
  unreachable
casted.1:
  store i32 %t4, ptr %l3
  store ptr %l2, ptr %l4
  %t6 = load ptr, ptr %l4
  store ptr %t6, ptr %l5
  %t7 = load i32, ptr %l3
  %t8 = load ptr, ptr %l5
  %t9 = call i64 @write(i32 %t7, ptr %t8, i64 8)
  store i64 %t9, ptr %l6
  br label %bb1
bb1:
  ret void
}

define internal i64 @"saw std.string.String.len()"(ptr noalias %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = load ptr, ptr %t0
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  store ptr %t2, ptr %l2
  %t3 = load i64, ptr @"static std.string.LENGTH_SLOT"
  store i64 %t3, ptr %l4
  %t4 = load ptr, ptr %l2
  %t5 = load i64, ptr %l4
  %t6 = mul i64 %t5, 8
  %t7 = getelementptr i8, ptr %t4, i64 %t6
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l0
  %t9 = load i64, ptr %l0
  ret i64 %t9
}

define internal i64 @"saw atomic_add_word(a: &Atomic<T>, v: Int) inst Int"(ptr %p1, i64 %p2) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca ptr, align 8
  %l5 = alloca ptr, align 8
  %l6 = alloca i64, align 8
  store ptr %p1, ptr %l1
  store i64 %p2, ptr %l2
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l3
  %t1 = load ptr, ptr %l3
  %t2 = call ptr @"saw UnsafeMutableInterior.ptr() args Int"(ptr %t1)
  store ptr %t2, ptr %l4
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l4
  store ptr %t3, ptr %l5
  %t4 = load ptr, ptr %l5
  %t5 = load i64, ptr %l2
  %t6 = atomicrmw add ptr %t4, i64 %t5 seq_cst
  store i64 %t6, ptr %l6
  br label %bb2
bb2:
  %t7 = load i64, ptr %l6
  store i64 %t7, ptr %l0
  %t8 = load i64, ptr %l0
  ret i64 %t8
}

define internal i64 @"saw atomic_load_word(a: &Atomic<T>) inst Int"(ptr %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca ptr, align 8
  %l5 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l2
  %t1 = load ptr, ptr %l2
  %t2 = call ptr @"saw UnsafeMutableInterior.ptr() args Int"(ptr %t1)
  store ptr %t2, ptr %l3
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l3
  store ptr %t3, ptr %l4
  %t4 = load ptr, ptr %l4
  %t5 = load atomic i64, ptr %t4 seq_cst, align 8
  store i64 %t5, ptr %l5
  br label %bb2
bb2:
  %t6 = load i64, ptr %l5
  store i64 %t6, ptr %l0
  %t7 = load i64, ptr %l0
  ret i64 %t7
}

define internal ptr @"saw UnsafeMutableInterior.ptr() args Int"(ptr %p1) #0 {
entry:
  %l0 = alloca ptr, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca ptr, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l2
  %t1 = load ptr, ptr %l2
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  store ptr %t2, ptr %l0
  %t3 = load ptr, ptr %l0
  ret ptr %t3
}

define internal i64 @__saw_render_uint(ptr %out, i64 %v) #0 {
entry:
  %tmp = alloca [24 x i8], align 1
  br label %loop
loop:
  %n = phi i64 [ %v, %entry ], [ %q, %loop ]
  %i = phi i64 [ 24, %entry ], [ %i1, %loop ]
  %q = udiv i64 %n, 10
  %r = urem i64 %n, 10
  %d = trunc i64 %r to i8
  %c = add i8 %d, 48
  %i1 = sub i64 %i, 1
  %p = getelementptr i8, ptr %tmp, i64 %i1
  store i8 %c, ptr %p
  %more = icmp ne i64 %q, 0
  br i1 %more, label %loop, label %done
done:
  %len = sub i64 24, %i1
  %src = getelementptr i8, ptr %tmp, i64 %i1
  call void @llvm.memcpy.p0.p0.i64(ptr %out, ptr %src, i64 %len, i1 false)
  ret i64 %len
}

define internal i64 @__saw_render_int(ptr %out, i64 %v) #0 {
entry:
  %neg = icmp slt i64 %v, 0
  br i1 %neg, label %minus, label %plain
minus:
  store i8 45, ptr %out
  %mag = sub i64 0, %v
  %rest = getelementptr i8, ptr %out, i64 1
  %n = call i64 @__saw_render_uint(ptr %rest, i64 %mag)
  %len = add i64 %n, 1
  ret i64 %len
plain:
  %m = call i64 @__saw_render_uint(ptr %out, i64 %v)
  ret i64 %m
}

define internal i64 @__saw_append(ptr %buf, i64 %pos, ptr %src, i64 %len) #0 {
entry:
  %closed = icmp slt i64 %pos, 0
  br i1 %closed, label %keep, label %open
keep:
  ret i64 %pos
open:
  %room = sub i64 508, %pos
  %fits = icmp ule i64 %len, %room
  br i1 %fits, label %whole, label %back
whole:
  %at = getelementptr i8, ptr %buf, i64 %pos
  call void @llvm.memcpy.p0.p0.i64(ptr %at, ptr %src, i64 %len, i1 false)
  %end = add i64 %pos, %len
  ret i64 %end
back:
  %n = phi i64 [ %room, %open ], [ %n1, %step ]
  %none = icmp eq i64 %n, 0
  br i1 %none, label %cut, label %test
test:
  %p = getelementptr i8, ptr %src, i64 %n
  %b = load i8, ptr %p
  %hi = and i8 %b, -64
  %inside = icmp eq i8 %hi, -128
  br i1 %inside, label %step, label %cut
step:
  %n1 = sub i64 %n, 1
  br label %back
cut:
  %at2 = getelementptr i8, ptr %buf, i64 %pos
  call void @llvm.memcpy.p0.p0.i64(ptr %at2, ptr %src, i64 %n, i1 false)
  %stop = add i64 %pos, %n
  %shut = sub i64 -1, %stop
  ret i64 %shut
}

define internal i64 @__saw_finish(ptr %buf, i64 %pos) #0 {
entry:
  %cut = icmp slt i64 %pos, 0
  br i1 %cut, label %mark, label %line
mark:
  %stop = sub i64 -1, %pos
  %m0 = getelementptr i8, ptr %buf, i64 %stop
  store i8 -30, ptr %m0
  %m1 = getelementptr i8, ptr %m0, i64 1
  store i8 -128, ptr %m1
  %m2 = getelementptr i8, ptr %m0, i64 2
  store i8 -90, ptr %m2
  %marked = add i64 %stop, 3
  br label %line
line:
  %end = phi i64 [ %marked, %mark ], [ %pos, %entry ]
  %nl = getelementptr i8, ptr %buf, i64 %end
  store i8 10, ptr %nl
  %total = add i64 %end, 1
  ret i64 %total
}

define internal i64 @__saw_append_int(ptr %buf, i64 %pos, i64 %v) #0 {
entry:
  %tmp = alloca [24 x i8], align 1
  %n = call i64 @__saw_render_int(ptr %tmp, i64 %v)
  %end = call i64 @__saw_append(ptr %buf, i64 %pos, ptr %tmp, i64 %n)
  ret i64 %end
}

define internal i64 @__saw_append_uint(ptr %buf, i64 %pos, i64 %v) #0 {
entry:
  %tmp = alloca [24 x i8], align 1
  %n = call i64 @__saw_render_uint(ptr %tmp, i64 %v)
  %end = call i64 @__saw_append(ptr %buf, i64 %pos, ptr %tmp, i64 %n)
  ret i64 %end
}

@__saw_fail_at = private unnamed_addr constant [9 x i8] c"panic at "
@__saw_fail_colon = private unnamed_addr constant [2 x i8] c": "
@__saw_fail_true = private unnamed_addr constant [4 x i8] c"true"
@__saw_fail_false = private unnamed_addr constant [5 x i8] c"false"
@__saw_fail_overflow.reason = private unnamed_addr constant [16 x i8] c"integer overflow"
@__saw_fail_divide.reason = private unnamed_addr constant [16 x i8] c"division by zero"
@__saw_fail_shift.reason = private unnamed_addr constant [18 x i8] c"shift out of range"
@__saw_fail_unwrap.reason = private unnamed_addr constant [20 x i8] c"force unwrap of None"
@__saw_fail_try.reason = private unnamed_addr constant [11 x i8] c"try! failed"

define internal i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line) #0 {
entry:
  %at = call i64 @__saw_append(ptr %buf, i64 0, ptr @__saw_fail_at, i64 9)
  %named = call i64 @__saw_append(ptr %buf, i64 %at, ptr %file, i64 %file_len)
  %known = icmp sge i64 %line, 0
  br i1 %known, label %number, label %tail
number:
  %colon = call i64 @__saw_append(ptr %buf, i64 %named, ptr @__saw_fail_colon, i64 1)
  %lined = call i64 @__saw_append_uint(ptr %buf, i64 %colon, i64 %line)
  br label %tail
tail:
  %pos = phi i64 [ %named, %entry ], [ %lined, %number ]
  %end = call i64 @__saw_append(ptr %buf, i64 %pos, ptr @__saw_fail_colon, i64 2)
  ret i64 %end
}

define internal void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr %text, i64 %text_len) noinline noreturn #0 {
entry:
  %buf = alloca [512 x i8], align 1
  %head = call i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line)
  %done = call i64 @__saw_append(ptr %buf, i64 %head, ptr %text, i64 %text_len)
  %end = call i64 @__saw_finish(ptr %buf, i64 %done)
  call void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %buf, i64 %end)
  unreachable
}

define internal void @__saw_fail_signed(ptr %file, i64 %file_len, i64 %line, ptr %text, i64 %text_len, i64 %v) noinline noreturn #0 {
entry:
  %buf = alloca [512 x i8], align 1
  %head = call i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line)
  %pos = call i64 @__saw_append(ptr %buf, i64 %head, ptr %text, i64 %text_len)
  %done = call i64 @__saw_append_int(ptr %buf, i64 %pos, i64 %v)
  %end = call i64 @__saw_finish(ptr %buf, i64 %done)
  call void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %buf, i64 %end)
  unreachable
}

define internal void @__saw_fail_unsigned(ptr %file, i64 %file_len, i64 %line, ptr %text, i64 %text_len, i64 %v) noinline noreturn #0 {
entry:
  %buf = alloca [512 x i8], align 1
  %head = call i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line)
  %pos = call i64 @__saw_append(ptr %buf, i64 %head, ptr %text, i64 %text_len)
  %done = call i64 @__saw_append_uint(ptr %buf, i64 %pos, i64 %v)
  %end = call i64 @__saw_finish(ptr %buf, i64 %done)
  call void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %buf, i64 %end)
  unreachable
}

define internal void @__saw_fail_parts(ptr %file, i64 %file_len, i64 %line, ptr %text, i64 %text_len, ptr %parts, i64 %count) noinline noreturn #0 {
entry:
  %buf = alloca [512 x i8], align 1
  %head = call i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line)
  %pos = call i64 @__saw_append(ptr %buf, i64 %head, ptr %text, i64 %text_len)
  br label %loop
loop:
  %i = phi i64 [ 0, %entry ], [ %i1, %next ]
  %at = phi i64 [ %pos, %entry ], [ %after, %next ]
  %more = icmp slt i64 %i, %count
  br i1 %more, label %part, label %last
part:
  %offset = mul i64 %i, 24
  %p = getelementptr i8, ptr %parts, i64 %offset
  %kind = load i64, ptr %p
  %first = getelementptr i8, ptr %p, i64 8
  %second = getelementptr i8, ptr %p, i64 16
  switch i64 %kind, label %run [ i64 1, label %signed i64 2, label %unsigned i64 3, label %bool ]
run:
  %src = load ptr, ptr %first
  %len = load i64, ptr %second
  %ran = call i64 @__saw_append(ptr %buf, i64 %at, ptr %src, i64 %len)
  br label %next
signed:
  %sv = load i64, ptr %first
  %sd = call i64 @__saw_append_int(ptr %buf, i64 %at, i64 %sv)
  br label %next
unsigned:
  %uv = load i64, ptr %first
  %ud = call i64 @__saw_append_uint(ptr %buf, i64 %at, i64 %uv)
  br label %next
bool:
  %byte = load i8, ptr %first
  %yes = icmp ne i8 %byte, 0
  %word = select i1 %yes, ptr @__saw_fail_true, ptr @__saw_fail_false
  %size = select i1 %yes, i64 4, i64 5
  %bd = call i64 @__saw_append(ptr %buf, i64 %at, ptr %word, i64 %size)
  br label %next
next:
  %after = phi i64 [ %ran, %run ], [ %sd, %signed ], [ %ud, %unsigned ], [ %bd, %bool ]
  %i1 = add i64 %i, 1
  br label %loop
last:
  %done = phi i64 [ %at, %loop ]
  %end = call i64 @__saw_finish(ptr %buf, i64 %done)
  call void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %buf, i64 %end)
  unreachable
}

define internal void @__saw_fail_overflow(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_overflow.reason, i64 16)
  unreachable
}

define internal void @__saw_fail_divide(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_divide.reason, i64 16)
  unreachable
}

define internal void @__saw_fail_shift(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_shift.reason, i64 18)
  unreachable
}

define internal void @__saw_fail_unwrap(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_unwrap.reason, i64 20)
  unreachable
}

define internal void @__saw_fail_try(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_try.reason, i64 11)
  unreachable
}

attributes #0 = { "frame-pointer"="non-leaf" }
