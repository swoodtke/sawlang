; sawc2 link manifest
; target x86_64-unknown-linux-gnu
; speed -O2
; runtime none

target triple = "x86_64-unknown-linux-gnu"

@"static os_ops.LOOPBACK_BE" = internal global i32 16777343
@"static os_ops.LISTEN_BACKLOG" = internal global i32 16
@"static os_ops.AF_INET" = internal global i32 2
@"static os_ops.SOCK_STREAM" = internal global i32 1
@"static os_ops.PROTO_DEFAULT" = internal global i32 0
@.bytes.0 = private unnamed_addr constant [10 x i8] c"os_ops.saw"
@.bytes.1 = private unnamed_addr constant [28 x i8] c"cast to Int32 out of range: "
@.bytes.2 = private unnamed_addr constant [29 x i8] c"cast to UInt32 out of range: "
@"static os_ops.OPT_REUSE_ADDRESS" = internal global i64 3
@"static os_ops.SOCKADDR_IN_LEN" = internal global i32 16
@.bytes.3 = private unnamed_addr constant [29 x i8] c"cast to UInt16 out of range: "
@.bytes.4 = private unnamed_addr constant [29 x i8] c"cast to UInt64 out of range: "
@"static os_ops.OPT_NO_DELAY" = internal global i64 1
@"static std.string.LENGTH_SLOT" = internal global i64 -1

declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare i32 @socket(i32, i32, i32)
declare i64 @__saw_rt_set_nonblocking(i64)
declare i64 @__saw_rt_last_syserror()
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare void @__saw_socket_suppress_sigpipe(i64)
declare i32 @close(i32)
declare i32 @bind(i32, ptr, i32)
declare i32 @listen(i32, i32)
declare i64 @__saw_sockopt_level(i64)
declare i64 @__saw_sockopt_name(i64)
declare i32 @setsockopt(i32, i32, i32, ptr, i32)
declare i32 @getsockname(i32, ptr, ptr)
declare i32 @accept(i32, ptr, ptr)
declare i32 @connect(i32, ptr, i32)
declare i64 @read(i32, ptr, i64)
declare i64 @__saw_socket_send_flags()
declare i64 @send(i32, ptr, i64, i32)
declare i32 @getaddrinfo(ptr, ptr, ptr, ptr)
declare i64 @__saw_gai_tag(i64)
declare void @freeaddrinfo(ptr)
declare i64 @__saw_ai_ipv4(ptr, ptr)
declare ptr @__saw_ai_next(ptr)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare i64 @__saw_open_flags(i64)
declare i32 @open(ptr, i32, ...)
declare i64 @write(i32, ptr, i64)
declare i64 @lseek(i32, i64, i32)
declare ptr @opendir(ptr)
declare i32 @unlink(ptr)
declare i32 @rename(ptr, ptr)
declare i32 @mkdir(ptr, i64)
declare i32 @rmdir(ptr)
declare i32 @chdir(ptr)
declare i32 @setenv(ptr, ptr, i32)
declare i32 @unsetenv(ptr)
declare void @__saw_rt_panic(ptr, i64)
declare void @__saw_rt_sin_set_family(ptr)

define i64 @"__saw_rt_tcp_listen"(i64 %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i64, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca i64, align 8
  store i64 %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load i32, ptr @"static os_ops.LOOPBACK_BE"
  %t1 = zext i32 %t0 to i64
  %t2 = trunc i64 %t1 to i32
  %t3 = icmp eq i32 %t2, %t0
  %t4 = icmp sge i64 %t1, 0
  %t5 = and i1 %t3, %t4
  %t6 = zext i32 %t0 to i64
  store i64 %t6, ptr %l2
  %t7 = load i64, ptr %l2
  %t8 = load i64, ptr %l1
  %t9 = call i64 @"__saw_rt_tcp_listen_on"(i64 %t7, i64 %t8)
  store i64 %t9, ptr %l3
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3
  store i64 %t10, ptr %l0
  %t11 = load i64, ptr %l0
  ret i64 %t11
}

define i64 @"__saw_rt_tcp_listen_on"(i64 %p1, i64 %p2) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i64, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca i64, align 8
  %l5 = alloca i64, align 8
  %l6 = alloca i64, align 8
  store i64 %p1, ptr %l1
  store i64 %p2, ptr %l2
  br label %bb0
bb0:
  %t0 = load i64, ptr %l1
  store i64 %t0, ptr %l3
  %t1 = load i64, ptr %l2
  store i64 %t1, ptr %l4
  %t2 = load i32, ptr @"static os_ops.LISTEN_BACKLOG"
  %t3 = sext i32 %t2 to i64
  %t4 = trunc i64 %t3 to i32
  %t5 = icmp eq i32 %t4, %t2
  %t6 = sext i32 %t2 to i64
  store i64 %t6, ptr %l5
  %t7 = load i64, ptr %l3
  %t8 = load i64, ptr %l4
  %t9 = load i64, ptr %l5
  %t10 = call i64 @"__saw_rt_tcp_listen_with"(i64 %t7, i64 %t8, i64 1, i64 %t9)
  store i64 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i64, ptr %l6
  store i64 %t11, ptr %l0
  %t12 = load i64, ptr %l0
  ret i64 %t12
}

define i64 @"__saw_rt_tcp_listen_with"(i64 %p1, i64 %p2, i64 %p3, i64 %p4) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i64, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca i64, align 8
  %l5 = alloca i32, align 4
  %l6 = alloca i32, align 4
  %l7 = alloca i32, align 4
  %l8 = alloca i32, align 4
  %l9 = alloca i8, align 1
  %l10 = alloca i64, align 8
  %l11 = alloca i64, align 8
  %l12 = alloca i64, align 8
  %l13 = alloca i64, align 8
  %l14 = alloca i64, align 8
  %l15 = alloca i8, align 1
  %l16 = alloca i64, align 8
  %l17 = alloca i64, align 8
  %l18 = alloca i64, align 8
  %l19 = alloca i8, align 1
  %l20 = alloca i32, align 4
  %l21 = alloca [16 x i8], align 8
  %l22 = alloca i32, align 4
  %l23 = alloca [16 x i8], align 8
  %l24 = alloca ptr, align 8
  %l25 = alloca ptr, align 8
  %l26 = alloca ptr, align 8
  %l27 = alloca i32, align 4
  %l28 = alloca i32, align 4
  %l29 = alloca i8, align 1
  %l30 = alloca i64, align 8
  %l31 = alloca i64, align 8
  %l32 = alloca i32, align 4
  %l33 = alloca i64, align 8
  %l34 = alloca i32, align 4
  %l35 = alloca i32, align 4
  %l36 = alloca i32, align 4
  %l37 = alloca i32, align 4
  %l38 = alloca i8, align 1
  %l39 = alloca i64, align 8
  %l40 = alloca i64, align 8
  %l41 = alloca i32, align 4
  %l42 = alloca i64, align 8
  %l43 = alloca i64, align 8
  store i64 %p1, ptr %l1
  store i64 %p2, ptr %l2
  store i64 %p3, ptr %l3
  store i64 %p4, ptr %l4
  br label %bb0
bb0:
  %t0 = load i32, ptr @"static os_ops.AF_INET"
  %t1 = load i32, ptr @"static os_ops.SOCK_STREAM"
  %t2 = load i32, ptr @"static os_ops.PROTO_DEFAULT"
  %t3 = call i32 @socket(i32 %t0, i32 %t1, i32 %t2)
  store i32 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i32, ptr %l6
  store i32 %t4, ptr %l5
  %t5 = load i32, ptr %l5
  store i32 %t5, ptr %l7
  %t6 = trunc i64 0 to i32
  %t7 = sext i32 %t6 to i64
  %t8 = icmp eq i64 %t7, 0
  %t9 = trunc i64 0 to i32
  %t10 = xor i1 %t8, 1
  br i1 %t10, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 180, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.1:
  store i32 %t9, ptr %l8
  %t11 = load i32, ptr %l7
  %t12 = load i32, ptr %l8
  %t13 = icmp slt i32 %t11, %t12
  %t14 = zext i1 %t13 to i8
  store i8 %t14, ptr %l9
  %t15 = load i8, ptr %l9
  %t16 = icmp ne i8 %t15, 0
  br i1 %t16, label %bb3, label %bb4
bb2:
  %t17 = load i32, ptr %l5
  %t18 = sext i32 %t17 to i64
  %t19 = trunc i64 %t18 to i32
  %t20 = icmp eq i32 %t19, %t17
  %t21 = sext i32 %t17 to i64
  store i64 %t21, ptr %l12
  %t22 = load i64, ptr %l12
  %t23 = call i64 @__saw_rt_set_nonblocking(i64 %t22)
  store i64 %t23, ptr %l13
  br label %bb6
bb3:
  %t24 = call i64 @__saw_rt_last_syserror()
  store i64 %t24, ptr %l10
  br label %bb5
bb4:
  br label %bb2
bb5:
  %t25 = load i64, ptr %l10
  %t26 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t25)
  %t27 = extractvalue { i64, i1 } %t26, 0
  %t28 = extractvalue { i64, i1 } %t26, 1
  br i1 %t28, label %check.2, label %checked.3
check.2:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 181)
  unreachable
checked.3:
  store i64 %t27, ptr %l11
  %t29 = load i64, ptr %l11
  store i64 %t29, ptr %l0
  %t30 = load i64, ptr %l0
  ret i64 %t30
bb6:
  %t31 = load i32, ptr %l5
  %t32 = sext i32 %t31 to i64
  %t33 = trunc i64 %t32 to i32
  %t34 = icmp eq i32 %t33, %t31
  %t35 = sext i32 %t31 to i64
  store i64 %t35, ptr %l14
  %t36 = load i64, ptr %l14
  call void @__saw_socket_suppress_sigpipe(i64 %t36)
  br label %bb7
bb7:
  %t37 = load i64, ptr %l3
  %t38 = icmp ne i64 %t37, 0
  %t39 = zext i1 %t38 to i8
  store i8 %t39, ptr %l15
  %t40 = load i8, ptr %l15
  %t41 = icmp ne i8 %t40, 0
  br i1 %t41, label %bb9, label %bb10
bb8:
  %t42 = load i64, ptr %l1
  %t43 = trunc i64 %t42 to i32
  %t44 = zext i32 %t43 to i64
  %t45 = icmp eq i64 %t44, %t42
  %t46 = icmp sge i64 %t42, 0
  %t47 = and i1 %t45, %t46
  %t48 = trunc i64 %t42 to i32
  %t49 = xor i1 %t47, 1
  br i1 %t49, label %cast.4, label %casted.5
cast.4:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 192, ptr @.bytes.2, i64 29, i64 %t42)
  unreachable
casted.5:
  store i32 %t48, ptr %l22
  %t50 = load i32, ptr %l22
  %t51 = load i64, ptr %l2
  call void @"saw os_ops.ipv4_sockaddr(addr: UInt32, port: Int)"(ptr %l23, i32 %t50, i64 %t51)
  br label %bb16
bb9:
  %t52 = load i32, ptr %l5
  %t53 = sext i32 %t52 to i64
  %t54 = trunc i64 %t53 to i32
  %t55 = icmp eq i32 %t54, %t52
  %t56 = sext i32 %t52 to i64
  store i64 %t56, ptr %l17
  %t57 = load i64, ptr %l17
  %t58 = load i64, ptr @"static os_ops.OPT_REUSE_ADDRESS"
  %t59 = call i64 @"__saw_rt_socket_set_option"(i64 %t57, i64 %t58, i64 1)
  store i64 %t59, ptr %l18
  br label %bb11
bb10:
  br label %bb8
bb11:
  %t60 = load i64, ptr %l18
  store i64 %t60, ptr %l16
  %t61 = load i64, ptr %l16
  %t62 = icmp slt i64 %t61, 0
  %t63 = zext i1 %t62 to i8
  store i8 %t63, ptr %l19
  %t64 = load i8, ptr %l19
  %t65 = icmp ne i8 %t64, 0
  br i1 %t65, label %bb13, label %bb14
bb12:
  br label %bb8
bb13:
  %t66 = load i32, ptr %l5
  %t67 = call i32 @close(i32 %t66)
  store i32 %t67, ptr %l20
  br label %bb15
bb14:
  br label %bb12
bb15:
  %t68 = load i64, ptr %l16
  store i64 %t68, ptr %l0
  %t69 = load i64, ptr %l0
  ret i64 %t69
bb16:
  call void @llvm.memcpy.p0.p0.i64(ptr %l21, ptr %l23, i64 16, i1 false)
  store ptr %l21, ptr %l25
  %t70 = load ptr, ptr %l25
  store ptr %t70, ptr %l26
  %t71 = load ptr, ptr %l26
  store ptr %t71, ptr %l24
  %t72 = load i32, ptr %l5
  %t73 = load ptr, ptr %l24
  %t74 = load i32, ptr @"static os_ops.SOCKADDR_IN_LEN"
  %t75 = call i32 @bind(i32 %t72, ptr %t73, i32 %t74)
  store i32 %t75, ptr %l27
  br label %bb18
bb17:
  %t76 = load i32, ptr %l5
  store i32 %t76, ptr %l34
  %t77 = load i64, ptr %l4
  %t78 = trunc i64 %t77 to i32
  %t79 = sext i32 %t78 to i64
  %t80 = icmp eq i64 %t79, %t77
  %t81 = trunc i64 %t77 to i32
  %t82 = xor i1 %t80, 1
  br i1 %t82, label %cast.6, label %casted.7
cast.6:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 199, ptr @.bytes.1, i64 28, i64 %t77)
  unreachable
casted.7:
  store i32 %t81, ptr %l35
  %t83 = load i32, ptr %l34
  %t84 = load i32, ptr %l35
  %t85 = call i32 @listen(i32 %t83, i32 %t84)
  store i32 %t85, ptr %l36
  br label %bb24
bb18:
  %t86 = trunc i64 0 to i32
  %t87 = sext i32 %t86 to i64
  %t88 = icmp eq i64 %t87, 0
  %t89 = trunc i64 0 to i32
  %t90 = xor i1 %t88, 1
  br i1 %t90, label %cast.8, label %casted.9
cast.8:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 194, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.9:
  store i32 %t89, ptr %l28
  %t91 = load i32, ptr %l27
  %t92 = load i32, ptr %l28
  %t93 = icmp ne i32 %t91, %t92
  %t94 = zext i1 %t93 to i8
  store i8 %t94, ptr %l29
  %t95 = load i8, ptr %l29
  %t96 = icmp ne i8 %t95, 0
  br i1 %t96, label %bb19, label %bb20
bb19:
  %t97 = call i64 @__saw_rt_last_syserror()
  store i64 %t97, ptr %l31
  br label %bb21
bb20:
  br label %bb17
bb21:
  %t98 = load i64, ptr %l31
  store i64 %t98, ptr %l30
  %t99 = load i32, ptr %l5
  %t100 = call i32 @close(i32 %t99)
  store i32 %t100, ptr %l32
  br label %bb22
bb22:
  %t101 = load i64, ptr %l30
  %t102 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t101)
  %t103 = extractvalue { i64, i1 } %t102, 0
  %t104 = extractvalue { i64, i1 } %t102, 1
  br i1 %t104, label %check.10, label %checked.11
check.10:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 197)
  unreachable
checked.11:
  store i64 %t103, ptr %l33
  %t105 = load i64, ptr %l33
  store i64 %t105, ptr %l0
  %t106 = load i64, ptr %l0
  ret i64 %t106
bb23:
  %t107 = load i32, ptr %l5
  %t108 = sext i32 %t107 to i64
  %t109 = trunc i64 %t108 to i32
  %t110 = icmp eq i32 %t109, %t107
  %t111 = sext i32 %t107 to i64
  store i64 %t111, ptr %l43
  %t112 = load i64, ptr %l43
  store i64 %t112, ptr %l0
  %t113 = load i64, ptr %l0
  ret i64 %t113
bb24:
  %t114 = trunc i64 0 to i32
  %t115 = sext i32 %t114 to i64
  %t116 = icmp eq i64 %t115, 0
  %t117 = trunc i64 0 to i32
  %t118 = xor i1 %t116, 1
  br i1 %t118, label %cast.12, label %casted.13
cast.12:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 199, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.13:
  store i32 %t117, ptr %l37
  %t119 = load i32, ptr %l36
  %t120 = load i32, ptr %l37
  %t121 = icmp ne i32 %t119, %t120
  %t122 = zext i1 %t121 to i8
  store i8 %t122, ptr %l38
  %t123 = load i8, ptr %l38
  %t124 = icmp ne i8 %t123, 0
  br i1 %t124, label %bb25, label %bb26
bb25:
  %t125 = call i64 @__saw_rt_last_syserror()
  store i64 %t125, ptr %l40
  br label %bb27
bb26:
  br label %bb23
bb27:
  %t126 = load i64, ptr %l40
  store i64 %t126, ptr %l39
  %t127 = load i32, ptr %l5
  %t128 = call i32 @close(i32 %t127)
  store i32 %t128, ptr %l41
  br label %bb28
bb28:
  %t129 = load i64, ptr %l39
  %t130 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t129)
  %t131 = extractvalue { i64, i1 } %t130, 0
  %t132 = extractvalue { i64, i1 } %t130, 1
  br i1 %t132, label %check.14, label %checked.15
check.14:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 202)
  unreachable
checked.15:
  store i64 %t131, ptr %l42
  %t133 = load i64, ptr %l42
  store i64 %t133, ptr %l0
  %t134 = load i64, ptr %l0
  ret i64 %t134
}

define i64 @"__saw_rt_socket_set_option"(i64 %p1, i64 %p2, i64 %p3) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i64, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca i64, align 8
  %l5 = alloca i64, align 8
  %l6 = alloca i64, align 8
  %l7 = alloca i64, align 8
  %l8 = alloca i8, align 1
  %l9 = alloca i8, align 1
  %l10 = alloca i8, align 1
  %l11 = alloca i8, align 1
  %l12 = alloca i8, align 1
  %l13 = alloca i64, align 8
  %l14 = alloca i64, align 8
  %l15 = alloca i32, align 4
  %l16 = alloca i32, align 4
  %l17 = alloca i32, align 4
  %l18 = alloca i32, align 4
  %l19 = alloca i32, align 4
  %l20 = alloca ptr, align 8
  %l21 = alloca ptr, align 8
  %l22 = alloca i32, align 4
  %l23 = alloca i32, align 4
  %l24 = alloca i32, align 4
  %l25 = alloca i8, align 1
  %l26 = alloca i64, align 8
  %l27 = alloca i64, align 8
  store i64 %p1, ptr %l1
  store i64 %p2, ptr %l2
  store i64 %p3, ptr %l3
  br label %bb0
bb0:
  %t0 = load i64, ptr %l2
  %t1 = call i64 @__saw_sockopt_level(i64 %t0)
  store i64 %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load i64, ptr %l5
  store i64 %t2, ptr %l4
  %t3 = load i64, ptr %l2
  %t4 = call i64 @__saw_sockopt_name(i64 %t3)
  store i64 %t4, ptr %l7
  br label %bb2
bb2:
  %t5 = load i64, ptr %l7
  store i64 %t5, ptr %l6
  %t6 = load i64, ptr %l4
  %t7 = icmp slt i64 %t6, 0
  %t8 = zext i1 %t7 to i8
  store i8 %t8, ptr %l9
  %t9 = load i8, ptr %l9
  %t10 = icmp ne i8 %t9, 0
  br i1 %t10, label %bb6, label %bb5
bb3:
  %t11 = load i64, ptr %l3
  %t12 = trunc i64 %t11 to i32
  %t13 = sext i32 %t12 to i64
  %t14 = icmp eq i64 %t13, %t11
  %t15 = trunc i64 %t11 to i32
  %t16 = xor i1 %t14, 1
  br i1 %t16, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 219, ptr @.bytes.1, i64 28, i64 %t11)
  unreachable
casted.1:
  store i32 %t15, ptr %l16
  %t17 = load i32, ptr %l16
  store i32 %t17, ptr %l15
  %t18 = load i64, ptr %l1
  %t19 = trunc i64 %t18 to i32
  %t20 = sext i32 %t19 to i64
  %t21 = icmp eq i64 %t20, %t18
  %t22 = trunc i64 %t18 to i32
  %t23 = xor i1 %t21, 1
  br i1 %t23, label %cast.2, label %casted.3
cast.2:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 220, ptr @.bytes.1, i64 28, i64 %t18)
  unreachable
casted.3:
  store i32 %t22, ptr %l17
  %t24 = load i64, ptr %l4
  %t25 = trunc i64 %t24 to i32
  %t26 = sext i32 %t25 to i64
  %t27 = icmp eq i64 %t26, %t24
  %t28 = trunc i64 %t24 to i32
  %t29 = xor i1 %t27, 1
  br i1 %t29, label %cast.4, label %casted.5
cast.4:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 220, ptr @.bytes.1, i64 28, i64 %t24)
  unreachable
casted.5:
  store i32 %t28, ptr %l18
  %t30 = load i64, ptr %l6
  %t31 = trunc i64 %t30 to i32
  %t32 = sext i32 %t31 to i64
  %t33 = icmp eq i64 %t32, %t30
  %t34 = trunc i64 %t30 to i32
  %t35 = xor i1 %t33, 1
  br i1 %t35, label %cast.6, label %casted.7
cast.6:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 220, ptr @.bytes.1, i64 28, i64 %t30)
  unreachable
casted.7:
  store i32 %t34, ptr %l19
  store ptr %l15, ptr %l20
  %t36 = load ptr, ptr %l20
  store ptr %t36, ptr %l21
  %t37 = trunc i64 4 to i32
  %t38 = sext i32 %t37 to i64
  %t39 = icmp eq i64 %t38, 4
  %t40 = trunc i64 4 to i32
  %t41 = xor i1 %t39, 1
  br i1 %t41, label %cast.8, label %casted.9
cast.8:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 221, ptr @.bytes.1, i64 28, i64 4)
  unreachable
casted.9:
  store i32 %t40, ptr %l22
  %t42 = load i32, ptr %l17
  %t43 = load i32, ptr %l18
  %t44 = load i32, ptr %l19
  %t45 = load ptr, ptr %l21
  %t46 = load i32, ptr %l22
  %t47 = call i32 @setsockopt(i32 %t42, i32 %t43, i32 %t44, ptr %t45, i32 %t46)
  store i32 %t47, ptr %l23
  br label %bb10
bb4:
  %t48 = load i8, ptr %l8
  %t49 = icmp ne i8 %t48, 0
  br i1 %t49, label %bb7, label %bb8
bb5:
  %t50 = load i64, ptr %l6
  %t51 = icmp slt i64 %t50, 0
  %t52 = zext i1 %t51 to i8
  store i8 %t52, ptr %l10
  %t53 = load i8, ptr %l10
  store i8 %t53, ptr %l8
  br label %bb4
bb6:
  store i8 1, ptr %l8
  br label %bb4
bb7:
  store i8 14, ptr %l11
  %t54 = load i8, ptr %l11
  %t55 = icmp eq i8 %t54, %t54
  store i8 %t54, ptr %l12
  %t56 = load i8, ptr %l12
  %t57 = zext i8 %t56 to i64
  %t58 = trunc i64 %t57 to i8
  %t59 = icmp eq i8 %t58, %t56
  %t60 = icmp sge i64 %t57, 0
  %t61 = and i1 %t59, %t60
  %t62 = zext i8 %t56 to i64
  store i64 %t62, ptr %l13
  %t63 = load i64, ptr %l13
  %t64 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t63)
  %t65 = extractvalue { i64, i1 } %t64, 0
  %t66 = extractvalue { i64, i1 } %t64, 1
  br i1 %t66, label %check.10, label %checked.11
check.10:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 217)
  unreachable
checked.11:
  store i64 %t65, ptr %l14
  %t67 = load i64, ptr %l14
  store i64 %t67, ptr %l0
  %t68 = load i64, ptr %l0
  ret i64 %t68
bb8:
  br label %bb3
bb9:
  store i64 0, ptr %l0
  %t69 = load i64, ptr %l0
  ret i64 %t69
bb10:
  %t70 = trunc i64 0 to i32
  %t71 = sext i32 %t70 to i64
  %t72 = icmp eq i64 %t71, 0
  %t73 = trunc i64 0 to i32
  %t74 = xor i1 %t72, 1
  br i1 %t74, label %cast.12, label %casted.13
cast.12:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 221, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.13:
  store i32 %t73, ptr %l24
  %t75 = load i32, ptr %l23
  %t76 = load i32, ptr %l24
  %t77 = icmp ne i32 %t75, %t76
  %t78 = zext i1 %t77 to i8
  store i8 %t78, ptr %l25
  %t79 = load i8, ptr %l25
  %t80 = icmp ne i8 %t79, 0
  br i1 %t80, label %bb11, label %bb12
bb11:
  %t81 = call i64 @__saw_rt_last_syserror()
  store i64 %t81, ptr %l26
  br label %bb13
bb12:
  br label %bb9
bb13:
  %t82 = load i64, ptr %l26
  %t83 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t82)
  %t84 = extractvalue { i64, i1 } %t83, 0
  %t85 = extractvalue { i64, i1 } %t83, 1
  br i1 %t85, label %check.14, label %checked.15
check.14:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 222)
  unreachable
checked.15:
  store i64 %t84, ptr %l27
  %t86 = load i64, ptr %l27
  store i64 %t86, ptr %l0
  %t87 = load i64, ptr %l0
  ret i64 %t87
}

define i64 @"__saw_rt_tcp_local_port"(i64 %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i64, align 8
  %l2 = alloca [16 x i8], align 8
  %l3 = alloca i16, align 2
  %l4 = alloca i16, align 2
  %l5 = alloca i32, align 4
  %l6 = alloca i64, align 8
  %l7 = alloca [16 x i8], align 8
  %l8 = alloca ptr, align 8
  %l9 = alloca ptr, align 8
  %l10 = alloca ptr, align 8
  %l11 = alloca i32, align 4
  %l12 = alloca ptr, align 8
  %l13 = alloca ptr, align 8
  %l14 = alloca ptr, align 8
  %l15 = alloca i32, align 4
  %l16 = alloca i32, align 4
  %l17 = alloca i64, align 8
  store i64 %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = trunc i64 0 to i16
  %t1 = zext i16 %t0 to i64
  %t2 = icmp eq i64 %t1, 0
  %t3 = icmp sge i64 0, 0
  %t4 = and i1 %t2, %t3
  %t5 = trunc i64 0 to i16
  %t6 = xor i1 %t4, 1
  br i1 %t6, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 230, ptr @.bytes.3, i64 29, i64 0)
  unreachable
casted.1:
  store i16 %t5, ptr %l3
  %t7 = trunc i64 0 to i16
  %t8 = zext i16 %t7 to i64
  %t9 = icmp eq i64 %t8, 0
  %t10 = icmp sge i64 0, 0
  %t11 = and i1 %t9, %t10
  %t12 = trunc i64 0 to i16
  %t13 = xor i1 %t11, 1
  br i1 %t13, label %cast.2, label %casted.3
cast.2:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 230, ptr @.bytes.3, i64 29, i64 0)
  unreachable
casted.3:
  store i16 %t12, ptr %l4
  %t14 = trunc i64 0 to i32
  %t15 = zext i32 %t14 to i64
  %t16 = icmp eq i64 %t15, 0
  %t17 = icmp sge i64 0, 0
  %t18 = and i1 %t16, %t17
  %t19 = trunc i64 0 to i32
  %t20 = xor i1 %t18, 1
  br i1 %t20, label %cast.4, label %casted.5
cast.4:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 230, ptr @.bytes.2, i64 29, i64 0)
  unreachable
casted.5:
  store i32 %t19, ptr %l5
  %t21 = icmp eq i64 0, 0
  %t22 = icmp sge i64 0, 0
  %t23 = and i1 %t21, %t22
  %t24 = xor i1 %t23, 1
  br i1 %t24, label %cast.6, label %casted.7
cast.6:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 230, ptr @.bytes.4, i64 29, i64 0)
  unreachable
casted.7:
  store i64 0, ptr %l6
  %t25 = load i16, ptr %l3
  store i16 %t25, ptr %l7
  %t26 = getelementptr i8, ptr %l7, i64 2
  %t27 = load i16, ptr %l4
  store i16 %t27, ptr %t26
  %t28 = getelementptr i8, ptr %l7, i64 4
  %t29 = load i32, ptr %l5
  store i32 %t29, ptr %t28
  %t30 = getelementptr i8, ptr %l7, i64 8
  %t31 = load i64, ptr %l6
  store i64 %t31, ptr %t30
  call void @llvm.memcpy.p0.p0.i64(ptr %l2, ptr %l7, i64 16, i1 false)
  store ptr %l2, ptr %l9
  %t32 = load ptr, ptr %l9
  store ptr %t32, ptr %l10
  %t33 = load ptr, ptr %l10
  store ptr %t33, ptr %l8
  %t34 = load i32, ptr @"static os_ops.SOCKADDR_IN_LEN"
  store i32 %t34, ptr %l11
  store ptr %l11, ptr %l13
  %t35 = load ptr, ptr %l13
  store ptr %t35, ptr %l14
  %t36 = load ptr, ptr %l14
  store ptr %t36, ptr %l12
  %t37 = load i64, ptr %l1
  %t38 = trunc i64 %t37 to i32
  %t39 = sext i32 %t38 to i64
  %t40 = icmp eq i64 %t39, %t37
  %t41 = trunc i64 %t37 to i32
  %t42 = xor i1 %t40, 1
  br i1 %t42, label %cast.8, label %casted.9
cast.8:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 234, ptr @.bytes.1, i64 28, i64 %t37)
  unreachable
casted.9:
  store i32 %t41, ptr %l15
  %t43 = load i32, ptr %l15
  %t44 = load ptr, ptr %l8
  %t45 = load ptr, ptr %l12
  %t46 = call i32 @getsockname(i32 %t43, ptr %t44, ptr %t45)
  store i32 %t46, ptr %l16
  br label %bb1
bb1:
  %t47 = getelementptr i8, ptr %l2, i64 2
  %t48 = load i16, ptr %t47
  %t49 = call i64 @"saw os_ops.ntohs(net: UInt16)"(i16 %t48)
  store i64 %t49, ptr %l17
  br label %bb2
bb2:
  %t50 = load i64, ptr %l17
  store i64 %t50, ptr %l0
  %t51 = load i64, ptr %l0
  ret i64 %t51
}

define i64 @"__saw_rt_tcp_accept"(i64 %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i64, align 8
  %l2 = alloca [16 x i8], align 8
  %l3 = alloca i16, align 2
  %l4 = alloca i16, align 2
  %l5 = alloca i32, align 4
  %l6 = alloca i64, align 8
  %l7 = alloca [16 x i8], align 8
  %l8 = alloca ptr, align 8
  %l9 = alloca ptr, align 8
  %l10 = alloca ptr, align 8
  %l11 = alloca i32, align 4
  %l12 = alloca ptr, align 8
  %l13 = alloca ptr, align 8
  %l14 = alloca ptr, align 8
  %l15 = alloca i32, align 4
  %l16 = alloca i32, align 4
  %l17 = alloca i32, align 4
  %l18 = alloca i32, align 4
  %l19 = alloca i32, align 4
  %l20 = alloca i8, align 1
  %l21 = alloca i64, align 8
  %l22 = alloca i64, align 8
  %l23 = alloca i64, align 8
  %l24 = alloca i64, align 8
  %l25 = alloca i64, align 8
  %l26 = alloca i64, align 8
  %l27 = alloca i64, align 8
  %l28 = alloca i64, align 8
  store i64 %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = trunc i64 0 to i16
  %t1 = zext i16 %t0 to i64
  %t2 = icmp eq i64 %t1, 0
  %t3 = icmp sge i64 0, 0
  %t4 = and i1 %t2, %t3
  %t5 = trunc i64 0 to i16
  %t6 = xor i1 %t4, 1
  br i1 %t6, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 242, ptr @.bytes.3, i64 29, i64 0)
  unreachable
casted.1:
  store i16 %t5, ptr %l3
  %t7 = trunc i64 0 to i16
  %t8 = zext i16 %t7 to i64
  %t9 = icmp eq i64 %t8, 0
  %t10 = icmp sge i64 0, 0
  %t11 = and i1 %t9, %t10
  %t12 = trunc i64 0 to i16
  %t13 = xor i1 %t11, 1
  br i1 %t13, label %cast.2, label %casted.3
cast.2:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 242, ptr @.bytes.3, i64 29, i64 0)
  unreachable
casted.3:
  store i16 %t12, ptr %l4
  %t14 = trunc i64 0 to i32
  %t15 = zext i32 %t14 to i64
  %t16 = icmp eq i64 %t15, 0
  %t17 = icmp sge i64 0, 0
  %t18 = and i1 %t16, %t17
  %t19 = trunc i64 0 to i32
  %t20 = xor i1 %t18, 1
  br i1 %t20, label %cast.4, label %casted.5
cast.4:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 242, ptr @.bytes.2, i64 29, i64 0)
  unreachable
casted.5:
  store i32 %t19, ptr %l5
  %t21 = icmp eq i64 0, 0
  %t22 = icmp sge i64 0, 0
  %t23 = and i1 %t21, %t22
  %t24 = xor i1 %t23, 1
  br i1 %t24, label %cast.6, label %casted.7
cast.6:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 242, ptr @.bytes.4, i64 29, i64 0)
  unreachable
casted.7:
  store i64 0, ptr %l6
  %t25 = load i16, ptr %l3
  store i16 %t25, ptr %l7
  %t26 = getelementptr i8, ptr %l7, i64 2
  %t27 = load i16, ptr %l4
  store i16 %t27, ptr %t26
  %t28 = getelementptr i8, ptr %l7, i64 4
  %t29 = load i32, ptr %l5
  store i32 %t29, ptr %t28
  %t30 = getelementptr i8, ptr %l7, i64 8
  %t31 = load i64, ptr %l6
  store i64 %t31, ptr %t30
  call void @llvm.memcpy.p0.p0.i64(ptr %l2, ptr %l7, i64 16, i1 false)
  store ptr %l2, ptr %l9
  %t32 = load ptr, ptr %l9
  store ptr %t32, ptr %l10
  %t33 = load ptr, ptr %l10
  store ptr %t33, ptr %l8
  %t34 = load i32, ptr @"static os_ops.SOCKADDR_IN_LEN"
  store i32 %t34, ptr %l11
  store ptr %l11, ptr %l13
  %t35 = load ptr, ptr %l13
  store ptr %t35, ptr %l14
  %t36 = load ptr, ptr %l14
  store ptr %t36, ptr %l12
  %t37 = load i64, ptr %l1
  %t38 = trunc i64 %t37 to i32
  %t39 = sext i32 %t38 to i64
  %t40 = icmp eq i64 %t39, %t37
  %t41 = trunc i64 %t37 to i32
  %t42 = xor i1 %t40, 1
  br i1 %t42, label %cast.8, label %casted.9
cast.8:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 246, ptr @.bytes.1, i64 28, i64 %t37)
  unreachable
casted.9:
  store i32 %t41, ptr %l16
  %t43 = load i32, ptr %l16
  %t44 = load ptr, ptr %l8
  %t45 = load ptr, ptr %l12
  %t46 = call i32 @accept(i32 %t43, ptr %t44, ptr %t45)
  store i32 %t46, ptr %l17
  br label %bb1
bb1:
  %t47 = load i32, ptr %l17
  store i32 %t47, ptr %l15
  %t48 = load i32, ptr %l15
  store i32 %t48, ptr %l18
  %t49 = trunc i64 0 to i32
  %t50 = sext i32 %t49 to i64
  %t51 = icmp eq i64 %t50, 0
  %t52 = trunc i64 0 to i32
  %t53 = xor i1 %t51, 1
  br i1 %t53, label %cast.10, label %casted.11
cast.10:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 247, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.11:
  store i32 %t52, ptr %l19
  %t54 = load i32, ptr %l18
  %t55 = load i32, ptr %l19
  %t56 = icmp sge i32 %t54, %t55
  %t57 = zext i1 %t56 to i8
  store i8 %t57, ptr %l20
  %t58 = load i8, ptr %l20
  %t59 = icmp ne i8 %t58, 0
  br i1 %t59, label %bb3, label %bb4
bb2:
  %t60 = call i64 @__saw_rt_last_syserror()
  store i64 %t60, ptr %l27
  br label %bb8
bb3:
  %t61 = load i32, ptr %l15
  %t62 = sext i32 %t61 to i64
  %t63 = trunc i64 %t62 to i32
  %t64 = icmp eq i32 %t63, %t61
  %t65 = sext i32 %t61 to i64
  store i64 %t65, ptr %l21
  %t66 = load i64, ptr %l21
  %t67 = call i64 @__saw_rt_set_nonblocking(i64 %t66)
  store i64 %t67, ptr %l22
  br label %bb5
bb4:
  br label %bb2
bb5:
  %t68 = load i32, ptr %l15
  %t69 = sext i32 %t68 to i64
  %t70 = trunc i64 %t69 to i32
  %t71 = icmp eq i32 %t70, %t68
  %t72 = sext i32 %t68 to i64
  store i64 %t72, ptr %l23
  %t73 = load i64, ptr %l23
  call void @__saw_socket_suppress_sigpipe(i64 %t73)
  br label %bb6
bb6:
  %t74 = load i32, ptr %l15
  %t75 = sext i32 %t74 to i64
  %t76 = trunc i64 %t75 to i32
  %t77 = icmp eq i32 %t76, %t74
  %t78 = sext i32 %t74 to i64
  store i64 %t78, ptr %l24
  %t79 = load i64, ptr %l24
  %t80 = load i64, ptr @"static os_ops.OPT_NO_DELAY"
  %t81 = call i64 @"__saw_rt_socket_set_option"(i64 %t79, i64 %t80, i64 1)
  store i64 %t81, ptr %l25
  br label %bb7
bb7:
  %t82 = load i32, ptr %l15
  %t83 = sext i32 %t82 to i64
  %t84 = trunc i64 %t83 to i32
  %t85 = icmp eq i32 %t84, %t82
  %t86 = sext i32 %t82 to i64
  store i64 %t86, ptr %l26
  %t87 = load i64, ptr %l26
  store i64 %t87, ptr %l0
  %t88 = load i64, ptr %l0
  ret i64 %t88
bb8:
  %t89 = load i64, ptr %l27
  %t90 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t89)
  %t91 = extractvalue { i64, i1 } %t90, 0
  %t92 = extractvalue { i64, i1 } %t90, 1
  br i1 %t92, label %check.12, label %checked.13
check.12:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 255)
  unreachable
checked.13:
  store i64 %t91, ptr %l28
  %t93 = load i64, ptr %l28
  store i64 %t93, ptr %l0
  %t94 = load i64, ptr %l0
  ret i64 %t94
}

define i64 @"__saw_rt_tcp_connect_start"(i64 %p1, i64 %p2) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i64, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca i32, align 4
  %l4 = alloca i32, align 4
  %l5 = alloca i32, align 4
  %l6 = alloca i32, align 4
  %l7 = alloca i8, align 1
  %l8 = alloca i64, align 8
  %l9 = alloca i64, align 8
  %l10 = alloca i64, align 8
  %l11 = alloca i64, align 8
  %l12 = alloca i64, align 8
  %l13 = alloca i64, align 8
  %l14 = alloca i64, align 8
  %l15 = alloca [16 x i8], align 8
  %l16 = alloca i32, align 4
  %l17 = alloca [16 x i8], align 8
  %l18 = alloca ptr, align 8
  %l19 = alloca ptr, align 8
  %l20 = alloca ptr, align 8
  %l21 = alloca i32, align 4
  %l22 = alloca i32, align 4
  %l23 = alloca i32, align 4
  %l24 = alloca i32, align 4
  %l25 = alloca i8, align 1
  %l26 = alloca i64, align 8
  %l27 = alloca i64, align 8
  %l28 = alloca i64, align 8
  %l29 = alloca i8, align 1
  %l30 = alloca i64, align 8
  %l31 = alloca i8, align 1
  %l32 = alloca i8, align 1
  %l33 = alloca i64, align 8
  %l34 = alloca i8, align 1
  %l35 = alloca i64, align 8
  %l36 = alloca i8, align 1
  %l37 = alloca i8, align 1
  %l38 = alloca i64, align 8
  %l39 = alloca i8, align 1
  %l40 = alloca i64, align 8
  %l41 = alloca i32, align 4
  %l42 = alloca i64, align 8
  store i64 %p1, ptr %l1
  store i64 %p2, ptr %l2
  br label %bb0
bb0:
  %t0 = load i32, ptr @"static os_ops.AF_INET"
  %t1 = load i32, ptr @"static os_ops.SOCK_STREAM"
  %t2 = load i32, ptr @"static os_ops.PROTO_DEFAULT"
  %t3 = call i32 @socket(i32 %t0, i32 %t1, i32 %t2)
  store i32 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i32, ptr %l4
  store i32 %t4, ptr %l3
  %t5 = load i32, ptr %l3
  store i32 %t5, ptr %l5
  %t6 = trunc i64 0 to i32
  %t7 = sext i32 %t6 to i64
  %t8 = icmp eq i64 %t7, 0
  %t9 = trunc i64 0 to i32
  %t10 = xor i1 %t8, 1
  br i1 %t10, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 264, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.1:
  store i32 %t9, ptr %l6
  %t11 = load i32, ptr %l5
  %t12 = load i32, ptr %l6
  %t13 = icmp slt i32 %t11, %t12
  %t14 = zext i1 %t13 to i8
  store i8 %t14, ptr %l7
  %t15 = load i8, ptr %l7
  %t16 = icmp ne i8 %t15, 0
  br i1 %t16, label %bb3, label %bb4
bb2:
  %t17 = load i32, ptr %l3
  %t18 = sext i32 %t17 to i64
  %t19 = trunc i64 %t18 to i32
  %t20 = icmp eq i32 %t19, %t17
  %t21 = sext i32 %t17 to i64
  store i64 %t21, ptr %l10
  %t22 = load i64, ptr %l10
  %t23 = call i64 @__saw_rt_set_nonblocking(i64 %t22)
  store i64 %t23, ptr %l11
  br label %bb6
bb3:
  %t24 = call i64 @__saw_rt_last_syserror()
  store i64 %t24, ptr %l8
  br label %bb5
bb4:
  br label %bb2
bb5:
  %t25 = load i64, ptr %l8
  %t26 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t25)
  %t27 = extractvalue { i64, i1 } %t26, 0
  %t28 = extractvalue { i64, i1 } %t26, 1
  br i1 %t28, label %check.2, label %checked.3
check.2:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 265)
  unreachable
checked.3:
  store i64 %t27, ptr %l9
  %t29 = load i64, ptr %l9
  store i64 %t29, ptr %l0
  %t30 = load i64, ptr %l0
  ret i64 %t30
bb6:
  %t31 = load i32, ptr %l3
  %t32 = sext i32 %t31 to i64
  %t33 = trunc i64 %t32 to i32
  %t34 = icmp eq i32 %t33, %t31
  %t35 = sext i32 %t31 to i64
  store i64 %t35, ptr %l12
  %t36 = load i64, ptr %l12
  call void @__saw_socket_suppress_sigpipe(i64 %t36)
  br label %bb7
bb7:
  %t37 = load i32, ptr %l3
  %t38 = sext i32 %t37 to i64
  %t39 = trunc i64 %t38 to i32
  %t40 = icmp eq i32 %t39, %t37
  %t41 = sext i32 %t37 to i64
  store i64 %t41, ptr %l13
  %t42 = load i64, ptr %l13
  %t43 = load i64, ptr @"static os_ops.OPT_NO_DELAY"
  %t44 = call i64 @"__saw_rt_socket_set_option"(i64 %t42, i64 %t43, i64 1)
  store i64 %t44, ptr %l14
  br label %bb8
bb8:
  %t45 = load i64, ptr %l1
  %t46 = trunc i64 %t45 to i32
  %t47 = zext i32 %t46 to i64
  %t48 = icmp eq i64 %t47, %t45
  %t49 = icmp sge i64 %t45, 0
  %t50 = and i1 %t48, %t49
  %t51 = trunc i64 %t45 to i32
  %t52 = xor i1 %t50, 1
  br i1 %t52, label %cast.4, label %casted.5
cast.4:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 272, ptr @.bytes.2, i64 29, i64 %t45)
  unreachable
casted.5:
  store i32 %t51, ptr %l16
  %t53 = load i32, ptr %l16
  %t54 = load i64, ptr %l2
  call void @"saw os_ops.ipv4_sockaddr(addr: UInt32, port: Int)"(ptr %l17, i32 %t53, i64 %t54)
  br label %bb9
bb9:
  call void @llvm.memcpy.p0.p0.i64(ptr %l15, ptr %l17, i64 16, i1 false)
  store ptr %l15, ptr %l19
  %t55 = load ptr, ptr %l19
  store ptr %t55, ptr %l20
  %t56 = load ptr, ptr %l20
  store ptr %t56, ptr %l18
  %t57 = load i32, ptr %l3
  %t58 = load ptr, ptr %l18
  %t59 = load i32, ptr @"static os_ops.SOCKADDR_IN_LEN"
  %t60 = call i32 @connect(i32 %t57, ptr %t58, i32 %t59)
  store i32 %t60, ptr %l22
  br label %bb10
bb10:
  %t61 = load i32, ptr %l22
  store i32 %t61, ptr %l21
  %t62 = load i32, ptr %l21
  store i32 %t62, ptr %l23
  %t63 = trunc i64 0 to i32
  %t64 = sext i32 %t63 to i64
  %t65 = icmp eq i64 %t64, 0
  %t66 = trunc i64 0 to i32
  %t67 = xor i1 %t65, 1
  br i1 %t67, label %cast.6, label %casted.7
cast.6:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 275, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.7:
  store i32 %t66, ptr %l24
  %t68 = load i32, ptr %l23
  %t69 = load i32, ptr %l24
  %t70 = icmp eq i32 %t68, %t69
  %t71 = zext i1 %t70 to i8
  store i8 %t71, ptr %l25
  %t72 = load i8, ptr %l25
  %t73 = icmp ne i8 %t72, 0
  br i1 %t73, label %bb12, label %bb13
bb11:
  %t74 = call i64 @__saw_rt_last_syserror()
  store i64 %t74, ptr %l28
  br label %bb14
bb12:
  %t75 = load i32, ptr %l3
  %t76 = sext i32 %t75 to i64
  %t77 = trunc i64 %t76 to i32
  %t78 = icmp eq i32 %t77, %t75
  %t79 = sext i32 %t75 to i64
  store i64 %t79, ptr %l26
  %t80 = load i64, ptr %l26
  store i64 %t80, ptr %l0
  %t81 = load i64, ptr %l0
  ret i64 %t81
bb13:
  br label %bb11
bb14:
  %t82 = load i64, ptr %l28
  store i64 %t82, ptr %l27
  %t83 = load i64, ptr %l27
  store i64 %t83, ptr %l30
  store i8 1, ptr %l31
  %t84 = load i8, ptr %l31
  %t85 = icmp eq i8 %t84, %t84
  store i8 %t84, ptr %l32
  %t86 = load i8, ptr %l32
  %t87 = zext i8 %t86 to i64
  %t88 = trunc i64 %t87 to i8
  %t89 = icmp eq i8 %t88, %t86
  %t90 = icmp sge i64 %t87, 0
  %t91 = and i1 %t89, %t90
  %t92 = zext i8 %t86 to i64
  store i64 %t92, ptr %l33
  %t93 = load i64, ptr %l30
  %t94 = load i64, ptr %l33
  %t95 = icmp eq i64 %t93, %t94
  %t96 = zext i1 %t95 to i8
  store i8 %t96, ptr %l34
  %t97 = load i8, ptr %l34
  %t98 = icmp ne i8 %t97, 0
  br i1 %t98, label %bb18, label %bb17
bb15:
  %t99 = load i32, ptr %l3
  %t100 = call i32 @close(i32 %t99)
  store i32 %t100, ptr %l41
  br label %bb21
bb16:
  %t101 = load i8, ptr %l29
  %t102 = icmp ne i8 %t101, 0
  br i1 %t102, label %bb19, label %bb20
bb17:
  %t103 = load i64, ptr %l27
  store i64 %t103, ptr %l35
  store i8 2, ptr %l36
  %t104 = load i8, ptr %l36
  %t105 = icmp eq i8 %t104, %t104
  store i8 %t104, ptr %l37
  %t106 = load i8, ptr %l37
  %t107 = zext i8 %t106 to i64
  %t108 = trunc i64 %t107 to i8
  %t109 = icmp eq i8 %t108, %t106
  %t110 = icmp sge i64 %t107, 0
  %t111 = and i1 %t109, %t110
  %t112 = zext i8 %t106 to i64
  store i64 %t112, ptr %l38
  %t113 = load i64, ptr %l35
  %t114 = load i64, ptr %l38
  %t115 = icmp eq i64 %t113, %t114
  %t116 = zext i1 %t115 to i8
  store i8 %t116, ptr %l39
  %t117 = load i8, ptr %l39
  store i8 %t117, ptr %l29
  br label %bb16
bb18:
  store i8 1, ptr %l29
  br label %bb16
bb19:
  %t118 = load i32, ptr %l3
  %t119 = sext i32 %t118 to i64
  %t120 = trunc i64 %t119 to i32
  %t121 = icmp eq i32 %t120, %t118
  %t122 = sext i32 %t118 to i64
  store i64 %t122, ptr %l40
  %t123 = load i64, ptr %l40
  store i64 %t123, ptr %l0
  %t124 = load i64, ptr %l0
  ret i64 %t124
bb20:
  br label %bb15
bb21:
  %t125 = load i64, ptr %l27
  %t126 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t125)
  %t127 = extractvalue { i64, i1 } %t126, 0
  %t128 = extractvalue { i64, i1 } %t126, 1
  br i1 %t128, label %check.8, label %checked.9
check.8:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 283)
  unreachable
checked.9:
  store i64 %t127, ptr %l42
  %t129 = load i64, ptr %l42
  store i64 %t129, ptr %l0
  %t130 = load i64, ptr %l0
  ret i64 %t130
}

define i64 @"__saw_rt_tcp_connect_check"(i64 %p1, i64 %p2, i64 %p3) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i64, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca [16 x i8], align 8
  %l5 = alloca i32, align 4
  %l6 = alloca [16 x i8], align 8
  %l7 = alloca ptr, align 8
  %l8 = alloca ptr, align 8
  %l9 = alloca ptr, align 8
  %l10 = alloca i32, align 4
  %l11 = alloca i32, align 4
  %l12 = alloca i32, align 4
  %l13 = alloca i32, align 4
  %l14 = alloca i32, align 4
  %l15 = alloca i8, align 1
  %l16 = alloca i64, align 8
  %l17 = alloca i64, align 8
  %l18 = alloca i64, align 8
  %l19 = alloca i8, align 1
  %l20 = alloca i8, align 1
  %l21 = alloca i64, align 8
  %l22 = alloca i8, align 1
  %l23 = alloca i8, align 1
  %l24 = alloca i64, align 8
  %l25 = alloca i8, align 1
  %l26 = alloca i8, align 1
  %l27 = alloca i64, align 8
  %l28 = alloca i8, align 1
  %l29 = alloca i64, align 8
  %l30 = alloca i8, align 1
  %l31 = alloca i8, align 1
  %l32 = alloca i64, align 8
  %l33 = alloca i8, align 1
  %l34 = alloca i8, align 1
  %l35 = alloca i8, align 1
  %l36 = alloca i64, align 8
  %l37 = alloca i64, align 8
  %l38 = alloca i64, align 8
  store i64 %p1, ptr %l1
  store i64 %p2, ptr %l2
  store i64 %p3, ptr %l3
  br label %bb0
bb0:
  %t0 = load i64, ptr %l2
  %t1 = trunc i64 %t0 to i32
  %t2 = zext i32 %t1 to i64
  %t3 = icmp eq i64 %t2, %t0
  %t4 = icmp sge i64 %t0, 0
  %t5 = and i1 %t3, %t4
  %t6 = trunc i64 %t0 to i32
  %t7 = xor i1 %t5, 1
  br i1 %t7, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 291, ptr @.bytes.2, i64 29, i64 %t0)
  unreachable
casted.1:
  store i32 %t6, ptr %l5
  %t8 = load i32, ptr %l5
  %t9 = load i64, ptr %l3
  call void @"saw os_ops.ipv4_sockaddr(addr: UInt32, port: Int)"(ptr %l6, i32 %t8, i64 %t9)
  br label %bb1
bb1:
  call void @llvm.memcpy.p0.p0.i64(ptr %l4, ptr %l6, i64 16, i1 false)
  store ptr %l4, ptr %l8
  %t10 = load ptr, ptr %l8
  store ptr %t10, ptr %l9
  %t11 = load ptr, ptr %l9
  store ptr %t11, ptr %l7
  %t12 = load i64, ptr %l1
  %t13 = trunc i64 %t12 to i32
  %t14 = sext i32 %t13 to i64
  %t15 = icmp eq i64 %t14, %t12
  %t16 = trunc i64 %t12 to i32
  %t17 = xor i1 %t15, 1
  br i1 %t17, label %cast.2, label %casted.3
cast.2:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 293, ptr @.bytes.1, i64 28, i64 %t12)
  unreachable
casted.3:
  store i32 %t16, ptr %l11
  %t18 = load i32, ptr %l11
  %t19 = load ptr, ptr %l7
  %t20 = load i32, ptr @"static os_ops.SOCKADDR_IN_LEN"
  %t21 = call i32 @connect(i32 %t18, ptr %t19, i32 %t20)
  store i32 %t21, ptr %l12
  br label %bb2
bb2:
  %t22 = load i32, ptr %l12
  store i32 %t22, ptr %l10
  %t23 = load i32, ptr %l10
  store i32 %t23, ptr %l13
  %t24 = trunc i64 0 to i32
  %t25 = sext i32 %t24 to i64
  %t26 = icmp eq i64 %t25, 0
  %t27 = trunc i64 0 to i32
  %t28 = xor i1 %t26, 1
  br i1 %t28, label %cast.4, label %casted.5
cast.4:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 294, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.5:
  store i32 %t27, ptr %l14
  %t29 = load i32, ptr %l13
  %t30 = load i32, ptr %l14
  %t31 = icmp eq i32 %t29, %t30
  %t32 = zext i1 %t31 to i8
  store i8 %t32, ptr %l15
  %t33 = load i8, ptr %l15
  %t34 = icmp ne i8 %t33, 0
  br i1 %t34, label %bb4, label %bb5
bb3:
  %t35 = call i64 @__saw_rt_last_syserror()
  store i64 %t35, ptr %l17
  br label %bb6
bb4:
  store i64 0, ptr %l0
  %t36 = load i64, ptr %l0
  ret i64 %t36
bb5:
  br label %bb3
bb6:
  %t37 = load i64, ptr %l17
  store i64 %t37, ptr %l16
  %t38 = load i64, ptr %l16
  store i64 %t38, ptr %l18
  store i8 3, ptr %l19
  %t39 = load i8, ptr %l19
  %t40 = icmp eq i8 %t39, %t39
  store i8 %t39, ptr %l20
  %t41 = load i8, ptr %l20
  %t42 = zext i8 %t41 to i64
  %t43 = trunc i64 %t42 to i8
  %t44 = icmp eq i8 %t43, %t41
  %t45 = icmp sge i64 %t42, 0
  %t46 = and i1 %t44, %t45
  %t47 = zext i8 %t41 to i64
  store i64 %t47, ptr %l21
  %t48 = load i64, ptr %l18
  %t49 = load i64, ptr %l21
  %t50 = icmp eq i64 %t48, %t49
  %t51 = zext i1 %t50 to i8
  store i8 %t51, ptr %l22
  %t52 = load i8, ptr %l22
  %t53 = icmp ne i8 %t52, 0
  br i1 %t53, label %bb8, label %bb9
bb7:
  %t54 = load i64, ptr %l16
  store i64 %t54, ptr %l24
  store i8 2, ptr %l25
  %t55 = load i8, ptr %l25
  %t56 = icmp eq i8 %t55, %t55
  store i8 %t55, ptr %l26
  %t57 = load i8, ptr %l26
  %t58 = zext i8 %t57 to i64
  %t59 = trunc i64 %t58 to i8
  %t60 = icmp eq i8 %t59, %t57
  %t61 = icmp sge i64 %t58, 0
  %t62 = and i1 %t60, %t61
  %t63 = zext i8 %t57 to i64
  store i64 %t63, ptr %l27
  %t64 = load i64, ptr %l24
  %t65 = load i64, ptr %l27
  %t66 = icmp eq i64 %t64, %t65
  %t67 = zext i1 %t66 to i8
  store i8 %t67, ptr %l28
  %t68 = load i8, ptr %l28
  %t69 = icmp ne i8 %t68, 0
  br i1 %t69, label %bb13, label %bb12
bb8:
  store i64 0, ptr %l0
  %t70 = load i64, ptr %l0
  ret i64 %t70
bb9:
  br label %bb7
bb10:
  %t71 = load i64, ptr %l16
  %t72 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t71)
  %t73 = extractvalue { i64, i1 } %t72, 0
  %t74 = extractvalue { i64, i1 } %t72, 1
  br i1 %t74, label %check.6, label %checked.7
check.6:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 304)
  unreachable
checked.7:
  store i64 %t73, ptr %l38
  %t75 = load i64, ptr %l38
  store i64 %t75, ptr %l0
  %t76 = load i64, ptr %l0
  ret i64 %t76
bb11:
  %t77 = load i8, ptr %l23
  %t78 = icmp ne i8 %t77, 0
  br i1 %t78, label %bb14, label %bb15
bb12:
  %t79 = load i64, ptr %l16
  store i64 %t79, ptr %l29
  store i8 1, ptr %l30
  %t80 = load i8, ptr %l30
  %t81 = icmp eq i8 %t80, %t80
  store i8 %t80, ptr %l31
  %t82 = load i8, ptr %l31
  %t83 = zext i8 %t82 to i64
  %t84 = trunc i64 %t83 to i8
  %t85 = icmp eq i8 %t84, %t82
  %t86 = icmp sge i64 %t83, 0
  %t87 = and i1 %t85, %t86
  %t88 = zext i8 %t82 to i64
  store i64 %t88, ptr %l32
  %t89 = load i64, ptr %l29
  %t90 = load i64, ptr %l32
  %t91 = icmp eq i64 %t89, %t90
  %t92 = zext i1 %t91 to i8
  store i8 %t92, ptr %l33
  %t93 = load i8, ptr %l33
  store i8 %t93, ptr %l23
  br label %bb11
bb13:
  store i8 1, ptr %l23
  br label %bb11
bb14:
  store i8 2, ptr %l34
  %t94 = load i8, ptr %l34
  %t95 = icmp eq i8 %t94, %t94
  store i8 %t94, ptr %l35
  %t96 = load i8, ptr %l35
  %t97 = zext i8 %t96 to i64
  %t98 = trunc i64 %t97 to i8
  %t99 = icmp eq i8 %t98, %t96
  %t100 = icmp sge i64 %t97, 0
  %t101 = and i1 %t99, %t100
  %t102 = zext i8 %t96 to i64
  store i64 %t102, ptr %l36
  %t103 = load i64, ptr %l36
  %t104 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t103)
  %t105 = extractvalue { i64, i1 } %t104, 0
  %t106 = extractvalue { i64, i1 } %t104, 1
  br i1 %t106, label %check.8, label %checked.9
check.8:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 302)
  unreachable
checked.9:
  store i64 %t105, ptr %l37
  %t107 = load i64, ptr %l37
  store i64 %t107, ptr %l0
  %t108 = load i64, ptr %l0
  ret i64 %t108
bb15:
  br label %bb10
}

define i64 @"__saw_rt_tcp_read"(i64 %p1, ptr %p2, i64 %p3) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i64, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca i64, align 8
  %l5 = alloca i32, align 4
  %l6 = alloca i64, align 8
  %l7 = alloca i8, align 1
  %l8 = alloca i64, align 8
  %l9 = alloca i64, align 8
  store i64 %p1, ptr %l1
  store ptr %p2, ptr %l2
  store i64 %p3, ptr %l3
  br label %bb0
bb0:
  %t0 = load i64, ptr %l1
  %t1 = trunc i64 %t0 to i32
  %t2 = sext i32 %t1 to i64
  %t3 = icmp eq i64 %t2, %t0
  %t4 = trunc i64 %t0 to i32
  %t5 = xor i1 %t3, 1
  br i1 %t5, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 310, ptr @.bytes.1, i64 28, i64 %t0)
  unreachable
casted.1:
  store i32 %t4, ptr %l5
  %t6 = load i32, ptr %l5
  %t7 = load ptr, ptr %l2
  %t8 = load i64, ptr %l3
  %t9 = call i64 @read(i32 %t6, ptr %t7, i64 %t8)
  store i64 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i64, ptr %l6
  store i64 %t10, ptr %l4
  %t11 = load i64, ptr %l4
  %t12 = icmp sge i64 %t11, 0
  %t13 = zext i1 %t12 to i8
  store i8 %t13, ptr %l7
  %t14 = load i8, ptr %l7
  %t15 = icmp ne i8 %t14, 0
  br i1 %t15, label %bb3, label %bb4
bb2:
  %t16 = call i64 @__saw_rt_last_syserror()
  store i64 %t16, ptr %l8
  br label %bb5
bb3:
  %t17 = load i64, ptr %l4
  store i64 %t17, ptr %l0
  %t18 = load i64, ptr %l0
  ret i64 %t18
bb4:
  br label %bb2
bb5:
  %t19 = load i64, ptr %l8
  %t20 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t19)
  %t21 = extractvalue { i64, i1 } %t20, 0
  %t22 = extractvalue { i64, i1 } %t20, 1
  br i1 %t22, label %check.2, label %checked.3
check.2:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 314)
  unreachable
checked.3:
  store i64 %t21, ptr %l9
  %t23 = load i64, ptr %l9
  store i64 %t23, ptr %l0
  %t24 = load i64, ptr %l0
  ret i64 %t24
}

define i64 @"__saw_rt_tcp_write"(i64 %p1, ptr %p2, i64 %p3) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i64, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca i64, align 8
  %l5 = alloca i32, align 4
  %l6 = alloca ptr, align 8
  %l7 = alloca i64, align 8
  %l8 = alloca i64, align 8
  %l9 = alloca i32, align 4
  %l10 = alloca i64, align 8
  %l11 = alloca i8, align 1
  %l12 = alloca i64, align 8
  %l13 = alloca i64, align 8
  store i64 %p1, ptr %l1
  store ptr %p2, ptr %l2
  store i64 %p3, ptr %l3
  br label %bb0
bb0:
  %t0 = load i64, ptr %l1
  %t1 = trunc i64 %t0 to i32
  %t2 = sext i32 %t1 to i64
  %t3 = icmp eq i64 %t2, %t0
  %t4 = trunc i64 %t0 to i32
  %t5 = xor i1 %t3, 1
  br i1 %t5, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 325, ptr @.bytes.1, i64 28, i64 %t0)
  unreachable
casted.1:
  store i32 %t4, ptr %l5
  %t6 = load ptr, ptr %l2
  store ptr %t6, ptr %l6
  %t7 = load i64, ptr %l3
  store i64 %t7, ptr %l7
  %t8 = call i64 @__saw_socket_send_flags()
  store i64 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load i64, ptr %l8
  %t10 = trunc i64 %t9 to i32
  %t11 = sext i32 %t10 to i64
  %t12 = icmp eq i64 %t11, %t9
  %t13 = trunc i64 %t9 to i32
  %t14 = xor i1 %t12, 1
  br i1 %t14, label %cast.2, label %casted.3
cast.2:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 325, ptr @.bytes.1, i64 28, i64 %t9)
  unreachable
casted.3:
  store i32 %t13, ptr %l9
  %t15 = load i32, ptr %l5
  %t16 = load ptr, ptr %l6
  %t17 = load i64, ptr %l7
  %t18 = load i32, ptr %l9
  %t19 = call i64 @send(i32 %t15, ptr %t16, i64 %t17, i32 %t18)
  store i64 %t19, ptr %l10
  br label %bb2
bb2:
  %t20 = load i64, ptr %l10
  store i64 %t20, ptr %l4
  %t21 = load i64, ptr %l4
  %t22 = icmp sge i64 %t21, 0
  %t23 = zext i1 %t22 to i8
  store i8 %t23, ptr %l11
  %t24 = load i8, ptr %l11
  %t25 = icmp ne i8 %t24, 0
  br i1 %t25, label %bb4, label %bb5
bb3:
  %t26 = call i64 @__saw_rt_last_syserror()
  store i64 %t26, ptr %l12
  br label %bb6
bb4:
  %t27 = load i64, ptr %l4
  store i64 %t27, ptr %l0
  %t28 = load i64, ptr %l0
  ret i64 %t28
bb5:
  br label %bb3
bb6:
  %t29 = load i64, ptr %l12
  %t30 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t29)
  %t31 = extractvalue { i64, i1 } %t30, 0
  %t32 = extractvalue { i64, i1 } %t30, 1
  br i1 %t32, label %check.4, label %checked.5
check.4:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 329)
  unreachable
checked.5:
  store i64 %t31, ptr %l13
  %t33 = load i64, ptr %l13
  store i64 %t33, ptr %l0
  %t34 = load i64, ptr %l0
  ret i64 %t34
}

define i64 @"__saw_rt_resolve_ipv4"(ptr %p1, ptr %p2, i64 %p3) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca i8, align 1
  %l5 = alloca i8, align 1
  %l6 = alloca i8, align 1
  %l7 = alloca i64, align 8
  %l8 = alloca i64, align 8
  %l9 = alloca [48 x i8], align 8
  %l10 = alloca i32, align 4
  %l11 = alloca i32, align 4
  %l12 = alloca i32, align 4
  %l13 = alloca i32, align 4
  %l14 = alloca i32, align 4
  %l15 = alloca i32, align 4
  %l16 = alloca i64, align 8
  %l17 = alloca i64, align 8
  %l18 = alloca i64, align 8
  %l19 = alloca [48 x i8], align 8
  %l20 = alloca ptr, align 8
  %l21 = alloca ptr, align 8
  %l22 = alloca i32, align 4
  %l23 = alloca ptr, align 8
  %l24 = alloca ptr, align 8
  %l25 = alloca ptr, align 8
  %l26 = alloca ptr, align 8
  %l27 = alloca ptr, align 8
  %l28 = alloca ptr, align 8
  %l29 = alloca i32, align 4
  %l30 = alloca i32, align 4
  %l31 = alloca i32, align 4
  %l32 = alloca i8, align 1
  %l33 = alloca i64, align 8
  %l34 = alloca i64, align 8
  %l35 = alloca i64, align 8
  %l36 = alloca i8, align 1
  %l37 = alloca i64, align 8
  %l38 = alloca i8, align 1
  %l39 = alloca i8, align 1
  %l40 = alloca i8, align 1
  %l41 = alloca i64, align 8
  %l42 = alloca i64, align 8
  %l43 = alloca [16 x i8], align 8
  %l44 = alloca [16 x i8], align 8
  %l45 = alloca i64, align 8
  %l46 = alloca i8, align 1
  %l47 = alloca ptr, align 8
  %l48 = alloca i32, align 4
  %l49 = alloca i32, align 4
  %l50 = alloca ptr, align 8
  %l51 = alloca ptr, align 8
  %l52 = alloca ptr, align 8
  %l53 = alloca i64, align 8
  %l54 = alloca i8, align 1
  %l55 = alloca i64, align 8
  %l56 = alloca i64, align 8
  %l57 = alloca [16 x i8], align 8
  store ptr %p1, ptr %l1
  store ptr %p2, ptr %l2
  store i64 %p3, ptr %l3
  br label %bb0
bb0:
  %t0 = load i64, ptr %l3
  %t1 = icmp sle i64 %t0, 0
  %t2 = zext i1 %t1 to i8
  store i8 %t2, ptr %l4
  %t3 = load i8, ptr %l4
  %t4 = icmp ne i8 %t3, 0
  br i1 %t4, label %bb2, label %bb3
bb1:
  %t5 = trunc i64 0 to i32
  %t6 = sext i32 %t5 to i64
  %t7 = icmp eq i64 %t6, 0
  %t8 = trunc i64 0 to i32
  %t9 = xor i1 %t7, 1
  br i1 %t9, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 348, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.1:
  store i32 %t8, ptr %l10
  %t10 = load i32, ptr @"static os_ops.AF_INET"
  store i32 %t10, ptr %l11
  %t11 = load i32, ptr @"static os_ops.SOCK_STREAM"
  store i32 %t11, ptr %l12
  %t12 = load i32, ptr @"static os_ops.PROTO_DEFAULT"
  store i32 %t12, ptr %l13
  %t13 = trunc i64 0 to i32
  %t14 = zext i32 %t13 to i64
  %t15 = icmp eq i64 %t14, 0
  %t16 = icmp sge i64 0, 0
  %t17 = and i1 %t15, %t16
  %t18 = trunc i64 0 to i32
  %t19 = xor i1 %t17, 1
  br i1 %t19, label %cast.2, label %casted.3
cast.2:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 350, ptr @.bytes.2, i64 29, i64 0)
  unreachable
casted.3:
  store i32 %t18, ptr %l14
  %t20 = trunc i64 0 to i32
  %t21 = zext i32 %t20 to i64
  %t22 = icmp eq i64 %t21, 0
  %t23 = icmp sge i64 0, 0
  %t24 = and i1 %t22, %t23
  %t25 = trunc i64 0 to i32
  %t26 = xor i1 %t24, 1
  br i1 %t26, label %cast.4, label %casted.5
cast.4:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 350, ptr @.bytes.2, i64 29, i64 0)
  unreachable
casted.5:
  store i32 %t25, ptr %l15
  %t27 = icmp eq i64 0, 0
  %t28 = icmp sge i64 0, 0
  %t29 = and i1 %t27, %t28
  %t30 = xor i1 %t29, 1
  br i1 %t30, label %cast.6, label %casted.7
cast.6:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 351, ptr @.bytes.4, i64 29, i64 0)
  unreachable
casted.7:
  store i64 0, ptr %l16
  %t31 = icmp eq i64 0, 0
  %t32 = icmp sge i64 0, 0
  %t33 = and i1 %t31, %t32
  %t34 = xor i1 %t33, 1
  br i1 %t34, label %cast.8, label %casted.9
cast.8:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 351, ptr @.bytes.4, i64 29, i64 0)
  unreachable
casted.9:
  store i64 0, ptr %l17
  %t35 = icmp eq i64 0, 0
  %t36 = icmp sge i64 0, 0
  %t37 = and i1 %t35, %t36
  %t38 = xor i1 %t37, 1
  br i1 %t38, label %cast.10, label %casted.11
cast.10:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 352, ptr @.bytes.4, i64 29, i64 0)
  unreachable
casted.11:
  store i64 0, ptr %l18
  %t39 = load i32, ptr %l10
  store i32 %t39, ptr %l19
  %t40 = getelementptr i8, ptr %l19, i64 4
  %t41 = load i32, ptr %l11
  store i32 %t41, ptr %t40
  %t42 = getelementptr i8, ptr %l19, i64 8
  %t43 = load i32, ptr %l12
  store i32 %t43, ptr %t42
  %t44 = getelementptr i8, ptr %l19, i64 12
  %t45 = load i32, ptr %l13
  store i32 %t45, ptr %t44
  %t46 = getelementptr i8, ptr %l19, i64 16
  %t47 = load i32, ptr %l14
  store i32 %t47, ptr %t46
  %t48 = getelementptr i8, ptr %l19, i64 20
  %t49 = load i32, ptr %l15
  store i32 %t49, ptr %t48
  %t50 = getelementptr i8, ptr %l19, i64 24
  %t51 = load i64, ptr %l16
  store i64 %t51, ptr %t50
  %t52 = getelementptr i8, ptr %l19, i64 32
  %t53 = load i64, ptr %l17
  store i64 %t53, ptr %t52
  %t54 = getelementptr i8, ptr %l19, i64 40
  %t55 = load i64, ptr %l18
  store i64 %t55, ptr %t54
  call void @llvm.memcpy.p0.p0.i64(ptr %l9, ptr %l19, i64 48, i1 false)
  %t56 = inttoptr i64 0 to ptr
  store ptr %t56, ptr %l21
  %t57 = load ptr, ptr %l21
  store ptr %t57, ptr %l20
  %t58 = load ptr, ptr %l1
  store ptr %t58, ptr %l23
  %t59 = inttoptr i64 0 to ptr
  store ptr %t59, ptr %l24
  store ptr %l9, ptr %l25
  %t60 = load ptr, ptr %l25
  store ptr %t60, ptr %l26
  store ptr %l20, ptr %l27
  %t61 = load ptr, ptr %l27
  store ptr %t61, ptr %l28
  %t62 = load ptr, ptr %l23
  %t63 = load ptr, ptr %l24
  %t64 = load ptr, ptr %l26
  %t65 = load ptr, ptr %l28
  %t66 = call i32 @getaddrinfo(ptr %t62, ptr %t63, ptr %t64, ptr %t65)
  store i32 %t66, ptr %l29
  br label %bb4
bb2:
  store i8 14, ptr %l5
  %t67 = load i8, ptr %l5
  %t68 = icmp eq i8 %t67, %t67
  store i8 %t67, ptr %l6
  %t69 = load i8, ptr %l6
  %t70 = zext i8 %t69 to i64
  %t71 = trunc i64 %t70 to i8
  %t72 = icmp eq i8 %t71, %t69
  %t73 = icmp sge i64 %t70, 0
  %t74 = and i1 %t72, %t73
  %t75 = zext i8 %t69 to i64
  store i64 %t75, ptr %l7
  %t76 = load i64, ptr %l7
  %t77 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t76)
  %t78 = extractvalue { i64, i1 } %t77, 0
  %t79 = extractvalue { i64, i1 } %t77, 1
  br i1 %t79, label %check.12, label %checked.13
check.12:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 346)
  unreachable
checked.13:
  store i64 %t78, ptr %l8
  %t80 = load i64, ptr %l8
  store i64 %t80, ptr %l0
  %t81 = load i64, ptr %l0
  ret i64 %t81
bb3:
  br label %bb1
bb4:
  %t82 = load i32, ptr %l29
  store i32 %t82, ptr %l22
  %t83 = load i32, ptr %l22
  store i32 %t83, ptr %l30
  %t84 = trunc i64 0 to i32
  %t85 = sext i32 %t84 to i64
  %t86 = icmp eq i64 %t85, 0
  %t87 = trunc i64 0 to i32
  %t88 = xor i1 %t86, 1
  br i1 %t88, label %cast.14, label %casted.15
cast.14:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 357, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.15:
  store i32 %t87, ptr %l31
  %t89 = load i32, ptr %l30
  %t90 = load i32, ptr %l31
  %t91 = icmp ne i32 %t89, %t90
  %t92 = zext i1 %t91 to i8
  store i8 %t92, ptr %l32
  %t93 = load i8, ptr %l32
  %t94 = icmp ne i8 %t93, 0
  br i1 %t94, label %bb6, label %bb7
bb5:
  store i8 1, ptr %l44
  %t95 = getelementptr i8, ptr %l44, i64 8
  %t96 = load ptr, ptr %l20
  store ptr %t96, ptr %t95
  call void @llvm.memcpy.p0.p0.i64(ptr %l43, ptr %l44, i64 16, i1 false)
  store i64 0, ptr %l45
  br label %bb16
bb6:
  %t97 = load i32, ptr %l22
  %t98 = sext i32 %t97 to i64
  %t99 = trunc i64 %t98 to i32
  %t100 = icmp eq i32 %t99, %t97
  %t101 = sext i32 %t97 to i64
  store i64 %t101, ptr %l34
  %t102 = load i64, ptr %l34
  %t103 = call i64 @__saw_gai_tag(i64 %t102)
  store i64 %t103, ptr %l35
  br label %bb8
bb7:
  br label %bb5
bb8:
  %t104 = load i64, ptr %l35
  store i64 %t104, ptr %l33
  %t105 = load i64, ptr %l33
  %t106 = icmp eq i64 %t105, 0
  %t107 = zext i1 %t106 to i8
  store i8 %t107, ptr %l36
  %t108 = load i8, ptr %l36
  %t109 = icmp ne i8 %t108, 0
  br i1 %t109, label %bb10, label %bb11
bb9:
  %t110 = load i64, ptr %l33
  %t111 = icmp eq i64 %t110, 0
  %t112 = zext i1 %t111 to i8
  store i8 %t112, ptr %l38
  %t113 = load i8, ptr %l38
  %t114 = icmp ne i8 %t113, 0
  br i1 %t114, label %bb14, label %bb15
bb10:
  %t115 = call i64 @__saw_rt_last_syserror()
  store i64 %t115, ptr %l37
  br label %bb12
bb11:
  br label %bb9
bb12:
  %t116 = load i64, ptr %l37
  store i64 %t116, ptr %l33
  br label %bb9
bb13:
  %t117 = load i64, ptr %l33
  %t118 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t117)
  %t119 = extractvalue { i64, i1 } %t118, 0
  %t120 = extractvalue { i64, i1 } %t118, 1
  br i1 %t120, label %check.16, label %checked.17
check.16:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 367)
  unreachable
checked.17:
  store i64 %t119, ptr %l42
  %t121 = load i64, ptr %l42
  store i64 %t121, ptr %l0
  %t122 = load i64, ptr %l0
  ret i64 %t122
bb14:
  store i8 16, ptr %l39
  %t123 = load i8, ptr %l39
  %t124 = icmp eq i8 %t123, %t123
  store i8 %t123, ptr %l40
  %t125 = load i8, ptr %l40
  %t126 = zext i8 %t125 to i64
  %t127 = trunc i64 %t126 to i8
  %t128 = icmp eq i8 %t127, %t125
  %t129 = icmp sge i64 %t126, 0
  %t130 = and i1 %t128, %t129
  %t131 = zext i8 %t125 to i64
  store i64 %t131, ptr %l41
  %t132 = load i64, ptr %l41
  store i64 %t132, ptr %l33
  br label %bb13
bb15:
  br label %bb13
bb16:
  %t133 = load i64, ptr %l45
  %t134 = load i64, ptr %l3
  %t135 = icmp slt i64 %t133, %t134
  %t136 = zext i1 %t135 to i8
  store i8 %t136, ptr %l46
  %t137 = load i8, ptr %l46
  %t138 = icmp ne i8 %t137, 0
  br i1 %t138, label %bb18, label %bb17
bb17:
  %t139 = load ptr, ptr %l20
  call void @freeaddrinfo(ptr %t139)
  br label %bb27
bb18:
  br label %bb19
bb19:
  %t140 = load i8, ptr %l43
  %t141 = zext i8 %t140 to i64
  switch i64 %t141, label %nocase.18 [ i64 1, label %bb20 i64 0, label %bb21 ]
nocase.18:
  unreachable
bb20:
  %t142 = getelementptr i8, ptr %l43, i64 8
  %t143 = load ptr, ptr %t142
  store ptr %t143, ptr %l47
  %t144 = trunc i64 0 to i32
  %t145 = zext i32 %t144 to i64
  %t146 = icmp eq i64 %t145, 0
  %t147 = icmp sge i64 0, 0
  %t148 = and i1 %t146, %t147
  %t149 = trunc i64 0 to i32
  %t150 = xor i1 %t148, 1
  br i1 %t150, label %cast.19, label %casted.20
cast.19:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 375, ptr @.bytes.2, i64 29, i64 0)
  unreachable
casted.20:
  store i32 %t149, ptr %l49
  %t151 = load i32, ptr %l49
  store i32 %t151, ptr %l48
  %t152 = load ptr, ptr %l47
  store ptr %t152, ptr %l50
  store ptr %l48, ptr %l51
  %t153 = load ptr, ptr %l51
  store ptr %t153, ptr %l52
  %t154 = load ptr, ptr %l50
  %t155 = load ptr, ptr %l52
  %t156 = call i64 @__saw_ai_ipv4(ptr %t154, ptr %t155)
  store i64 %t156, ptr %l53
  br label %bb23
bb21:
  br label %bb17
bb22:
  %t157 = load ptr, ptr %l47
  %t158 = call ptr @__saw_ai_next(ptr %t157)
  %t159 = icmp ne ptr %t158, null
  %t160 = zext i1 %t159 to i8
  store i8 %t160, ptr %l57
  %t161 = getelementptr i8, ptr %l57, i64 8
  store ptr %t158, ptr %t161
  br label %bb26
bb23:
  %t162 = load i64, ptr %l53
  %t163 = icmp ne i64 %t162, 0
  %t164 = zext i1 %t163 to i8
  store i8 %t164, ptr %l54
  %t165 = load i8, ptr %l54
  %t166 = icmp ne i8 %t165, 0
  br i1 %t166, label %bb24, label %bb25
bb24:
  %t167 = load i64, ptr %l45
  store i64 %t167, ptr %l55
  %t168 = load ptr, ptr %l2
  %t169 = load i64, ptr %l55
  %t170 = mul i64 %t169, 4
  %t171 = getelementptr i8, ptr %t168, i64 %t170
  %t172 = load i32, ptr %l48
  store i32 %t172, ptr %t171
  %t173 = load i64, ptr %l45
  %t174 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %t173, i64 1)
  %t175 = extractvalue { i64, i1 } %t174, 0
  %t176 = extractvalue { i64, i1 } %t174, 1
  br i1 %t176, label %check.21, label %checked.22
check.21:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 378)
  unreachable
checked.22:
  store i64 %t175, ptr %l56
  %t177 = load i64, ptr %l56
  store i64 %t177, ptr %l45
  br label %bb22
bb25:
  br label %bb22
bb26:
  call void @llvm.memcpy.p0.p0.i64(ptr %l43, ptr %l57, i64 16, i1 false)
  br label %bb16
bb27:
  %t178 = load i64, ptr %l45
  store i64 %t178, ptr %l0
  %t179 = load i64, ptr %l0
  ret i64 %t179
}

define i64 @"__saw_rt_fs_open"(ptr %p1, i64 %p2, i64 %p3) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca i64, align 8
  %l5 = alloca i64, align 8
  %l6 = alloca i8, align 1
  %l7 = alloca i8, align 1
  %l8 = alloca i8, align 1
  %l9 = alloca i64, align 8
  %l10 = alloca i64, align 8
  %l11 = alloca i32, align 4
  %l12 = alloca ptr, align 8
  %l13 = alloca i32, align 4
  %l14 = alloca i32, align 4
  %l15 = alloca i32, align 4
  %l16 = alloca i32, align 4
  %l17 = alloca i8, align 1
  %l18 = alloca i64, align 8
  %l19 = alloca i64, align 8
  %l20 = alloca i64, align 8
  store ptr %p1, ptr %l1
  store i64 %p2, ptr %l2
  store i64 %p3, ptr %l3
  br label %bb0
bb0:
  %t0 = load i64, ptr %l2
  %t1 = call i64 @__saw_open_flags(i64 %t0)
  store i64 %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load i64, ptr %l5
  store i64 %t2, ptr %l4
  %t3 = load i64, ptr %l4
  %t4 = icmp slt i64 %t3, 0
  %t5 = zext i1 %t4 to i8
  store i8 %t5, ptr %l6
  %t6 = load i8, ptr %l6
  %t7 = icmp ne i8 %t6, 0
  br i1 %t7, label %bb3, label %bb4
bb2:
  %t8 = load ptr, ptr %l1
  store ptr %t8, ptr %l12
  %t9 = load i64, ptr %l4
  %t10 = trunc i64 %t9 to i32
  %t11 = sext i32 %t10 to i64
  %t12 = icmp eq i64 %t11, %t9
  %t13 = trunc i64 %t9 to i32
  %t14 = xor i1 %t12, 1
  br i1 %t14, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 400, ptr @.bytes.1, i64 28, i64 %t9)
  unreachable
casted.1:
  store i32 %t13, ptr %l13
  %t15 = load ptr, ptr %l12
  %t16 = load i32, ptr %l13
  %t17 = load i64, ptr %l3
  %t18 = call i32 (ptr, i32, ...) @open(ptr %t15, i32 %t16, i64 %t17)
  store i32 %t18, ptr %l14
  br label %bb5
bb3:
  store i8 14, ptr %l7
  %t19 = load i8, ptr %l7
  %t20 = icmp eq i8 %t19, %t19
  store i8 %t19, ptr %l8
  %t21 = load i8, ptr %l8
  %t22 = zext i8 %t21 to i64
  %t23 = trunc i64 %t22 to i8
  %t24 = icmp eq i8 %t23, %t21
  %t25 = icmp sge i64 %t22, 0
  %t26 = and i1 %t24, %t25
  %t27 = zext i8 %t21 to i64
  store i64 %t27, ptr %l9
  %t28 = load i64, ptr %l9
  %t29 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t28)
  %t30 = extractvalue { i64, i1 } %t29, 0
  %t31 = extractvalue { i64, i1 } %t29, 1
  br i1 %t31, label %check.2, label %checked.3
check.2:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 398)
  unreachable
checked.3:
  store i64 %t30, ptr %l10
  %t32 = load i64, ptr %l10
  store i64 %t32, ptr %l0
  %t33 = load i64, ptr %l0
  ret i64 %t33
bb4:
  br label %bb2
bb5:
  %t34 = load i32, ptr %l14
  store i32 %t34, ptr %l11
  %t35 = load i32, ptr %l11
  store i32 %t35, ptr %l15
  %t36 = trunc i64 0 to i32
  %t37 = sext i32 %t36 to i64
  %t38 = icmp eq i64 %t37, 0
  %t39 = trunc i64 0 to i32
  %t40 = xor i1 %t38, 1
  br i1 %t40, label %cast.4, label %casted.5
cast.4:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 401, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.5:
  store i32 %t39, ptr %l16
  %t41 = load i32, ptr %l15
  %t42 = load i32, ptr %l16
  %t43 = icmp sge i32 %t41, %t42
  %t44 = zext i1 %t43 to i8
  store i8 %t44, ptr %l17
  %t45 = load i8, ptr %l17
  %t46 = icmp ne i8 %t45, 0
  br i1 %t46, label %bb7, label %bb8
bb6:
  %t47 = call i64 @__saw_rt_last_syserror()
  store i64 %t47, ptr %l19
  br label %bb9
bb7:
  %t48 = load i32, ptr %l11
  %t49 = sext i32 %t48 to i64
  %t50 = trunc i64 %t49 to i32
  %t51 = icmp eq i32 %t50, %t48
  %t52 = sext i32 %t48 to i64
  store i64 %t52, ptr %l18
  %t53 = load i64, ptr %l18
  store i64 %t53, ptr %l0
  %t54 = load i64, ptr %l0
  ret i64 %t54
bb8:
  br label %bb6
bb9:
  %t55 = load i64, ptr %l19
  %t56 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t55)
  %t57 = extractvalue { i64, i1 } %t56, 0
  %t58 = extractvalue { i64, i1 } %t56, 1
  br i1 %t58, label %check.6, label %checked.7
check.6:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 404)
  unreachable
checked.7:
  store i64 %t57, ptr %l20
  %t59 = load i64, ptr %l20
  store i64 %t59, ptr %l0
  %t60 = load i64, ptr %l0
  ret i64 %t60
}

define i64 @"__saw_rt_fs_read"(i64 %p1, ptr %p2, i64 %p3) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i64, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca i64, align 8
  %l5 = alloca i32, align 4
  %l6 = alloca i64, align 8
  %l7 = alloca i8, align 1
  %l8 = alloca i64, align 8
  %l9 = alloca i64, align 8
  store i64 %p1, ptr %l1
  store ptr %p2, ptr %l2
  store i64 %p3, ptr %l3
  br label %bb0
bb0:
  %t0 = load i64, ptr %l1
  %t1 = trunc i64 %t0 to i32
  %t2 = sext i32 %t1 to i64
  %t3 = icmp eq i64 %t2, %t0
  %t4 = trunc i64 %t0 to i32
  %t5 = xor i1 %t3, 1
  br i1 %t5, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 409, ptr @.bytes.1, i64 28, i64 %t0)
  unreachable
casted.1:
  store i32 %t4, ptr %l5
  %t6 = load i32, ptr %l5
  %t7 = load ptr, ptr %l2
  %t8 = load i64, ptr %l3
  %t9 = call i64 @read(i32 %t6, ptr %t7, i64 %t8)
  store i64 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i64, ptr %l6
  store i64 %t10, ptr %l4
  %t11 = load i64, ptr %l4
  %t12 = icmp sge i64 %t11, 0
  %t13 = zext i1 %t12 to i8
  store i8 %t13, ptr %l7
  %t14 = load i8, ptr %l7
  %t15 = icmp ne i8 %t14, 0
  br i1 %t15, label %bb3, label %bb4
bb2:
  %t16 = call i64 @__saw_rt_last_syserror()
  store i64 %t16, ptr %l8
  br label %bb5
bb3:
  %t17 = load i64, ptr %l4
  store i64 %t17, ptr %l0
  %t18 = load i64, ptr %l0
  ret i64 %t18
bb4:
  br label %bb2
bb5:
  %t19 = load i64, ptr %l8
  %t20 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t19)
  %t21 = extractvalue { i64, i1 } %t20, 0
  %t22 = extractvalue { i64, i1 } %t20, 1
  br i1 %t22, label %check.2, label %checked.3
check.2:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 413)
  unreachable
checked.3:
  store i64 %t21, ptr %l9
  %t23 = load i64, ptr %l9
  store i64 %t23, ptr %l0
  %t24 = load i64, ptr %l0
  ret i64 %t24
}

define i64 @"__saw_rt_fs_write"(i64 %p1, ptr %p2, i64 %p3) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i64, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca i64, align 8
  %l5 = alloca i32, align 4
  %l6 = alloca i64, align 8
  %l7 = alloca i8, align 1
  %l8 = alloca i64, align 8
  %l9 = alloca i64, align 8
  store i64 %p1, ptr %l1
  store ptr %p2, ptr %l2
  store i64 %p3, ptr %l3
  br label %bb0
bb0:
  %t0 = load i64, ptr %l1
  %t1 = trunc i64 %t0 to i32
  %t2 = sext i32 %t1 to i64
  %t3 = icmp eq i64 %t2, %t0
  %t4 = trunc i64 %t0 to i32
  %t5 = xor i1 %t3, 1
  br i1 %t5, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 418, ptr @.bytes.1, i64 28, i64 %t0)
  unreachable
casted.1:
  store i32 %t4, ptr %l5
  %t6 = load i32, ptr %l5
  %t7 = load ptr, ptr %l2
  %t8 = load i64, ptr %l3
  %t9 = call i64 @write(i32 %t6, ptr %t7, i64 %t8)
  store i64 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i64, ptr %l6
  store i64 %t10, ptr %l4
  %t11 = load i64, ptr %l4
  %t12 = icmp sge i64 %t11, 0
  %t13 = zext i1 %t12 to i8
  store i8 %t13, ptr %l7
  %t14 = load i8, ptr %l7
  %t15 = icmp ne i8 %t14, 0
  br i1 %t15, label %bb3, label %bb4
bb2:
  %t16 = call i64 @__saw_rt_last_syserror()
  store i64 %t16, ptr %l8
  br label %bb5
bb3:
  %t17 = load i64, ptr %l4
  store i64 %t17, ptr %l0
  %t18 = load i64, ptr %l0
  ret i64 %t18
bb4:
  br label %bb2
bb5:
  %t19 = load i64, ptr %l8
  %t20 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t19)
  %t21 = extractvalue { i64, i1 } %t20, 0
  %t22 = extractvalue { i64, i1 } %t20, 1
  br i1 %t22, label %check.2, label %checked.3
check.2:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 422)
  unreachable
checked.3:
  store i64 %t21, ptr %l9
  %t23 = load i64, ptr %l9
  store i64 %t23, ptr %l0
  %t24 = load i64, ptr %l0
  ret i64 %t24
}

define i64 @"__saw_rt_fs_lseek"(i64 %p1, i64 %p2, i64 %p3) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i64, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca i64, align 8
  %l5 = alloca i32, align 4
  %l6 = alloca i64, align 8
  %l7 = alloca i32, align 4
  %l8 = alloca i64, align 8
  %l9 = alloca i64, align 8
  %l10 = alloca i64, align 8
  %l11 = alloca i8, align 1
  %l12 = alloca i64, align 8
  %l13 = alloca i64, align 8
  %l14 = alloca i64, align 8
  store i64 %p1, ptr %l1
  store i64 %p2, ptr %l2
  store i64 %p3, ptr %l3
  br label %bb0
bb0:
  %t0 = load i64, ptr %l1
  %t1 = trunc i64 %t0 to i32
  %t2 = sext i32 %t1 to i64
  %t3 = icmp eq i64 %t2, %t0
  %t4 = trunc i64 %t0 to i32
  %t5 = xor i1 %t3, 1
  br i1 %t5, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 429, ptr @.bytes.1, i64 28, i64 %t0)
  unreachable
casted.1:
  store i32 %t4, ptr %l5
  %t6 = load i64, ptr %l2
  %t7 = icmp eq i64 %t6, %t6
  store i64 %t6, ptr %l6
  %t8 = load i64, ptr %l3
  %t9 = trunc i64 %t8 to i32
  %t10 = sext i32 %t9 to i64
  %t11 = icmp eq i64 %t10, %t8
  %t12 = trunc i64 %t8 to i32
  %t13 = xor i1 %t11, 1
  br i1 %t13, label %cast.2, label %casted.3
cast.2:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 429, ptr @.bytes.1, i64 28, i64 %t8)
  unreachable
casted.3:
  store i32 %t12, ptr %l7
  %t14 = load i32, ptr %l5
  %t15 = load i64, ptr %l6
  %t16 = load i32, ptr %l7
  %t17 = call i64 @lseek(i32 %t14, i64 %t15, i32 %t16)
  store i64 %t17, ptr %l8
  br label %bb1
bb1:
  %t18 = load i64, ptr %l8
  store i64 %t18, ptr %l4
  %t19 = load i64, ptr %l4
  store i64 %t19, ptr %l9
  %t20 = icmp eq i64 0, 0
  store i64 0, ptr %l10
  %t21 = load i64, ptr %l9
  %t22 = load i64, ptr %l10
  %t23 = icmp sge i64 %t21, %t22
  %t24 = zext i1 %t23 to i8
  store i8 %t24, ptr %l11
  %t25 = load i8, ptr %l11
  %t26 = icmp ne i8 %t25, 0
  br i1 %t26, label %bb3, label %bb4
bb2:
  %t27 = call i64 @__saw_rt_last_syserror()
  store i64 %t27, ptr %l13
  br label %bb5
bb3:
  %t28 = load i64, ptr %l4
  %t29 = icmp eq i64 %t28, %t28
  store i64 %t28, ptr %l12
  %t30 = load i64, ptr %l12
  store i64 %t30, ptr %l0
  %t31 = load i64, ptr %l0
  ret i64 %t31
bb4:
  br label %bb2
bb5:
  %t32 = load i64, ptr %l13
  %t33 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t32)
  %t34 = extractvalue { i64, i1 } %t33, 0
  %t35 = extractvalue { i64, i1 } %t33, 1
  br i1 %t35, label %check.4, label %checked.5
check.4:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 433)
  unreachable
checked.5:
  store i64 %t34, ptr %l14
  %t36 = load i64, ptr %l14
  store i64 %t36, ptr %l0
  %t37 = load i64, ptr %l0
  ret i64 %t37
}

define ptr @"__saw_rt_fs_opendir"(ptr %p1, ptr %p2) #0 {
entry:
  %l0 = alloca ptr, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca [16 x i8], align 8
  %l4 = alloca ptr, align 8
  %l5 = alloca i64, align 8
  %l6 = alloca i64, align 8
  %l7 = alloca i64, align 8
  %l8 = alloca ptr, align 8
  store ptr %p1, ptr %l1
  store ptr %p2, ptr %l2
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = call ptr @opendir(ptr %t0)
  %t2 = icmp ne ptr %t1, null
  %t3 = zext i1 %t2 to i8
  store i8 %t3, ptr %l3
  %t4 = getelementptr i8, ptr %l3, i64 8
  store ptr %t1, ptr %t4
  br label %bb2
bb1:
  store i64 0, ptr %l6
  %t5 = call i64 @__saw_rt_last_syserror()
  store i64 %t5, ptr %l7
  br label %bb5
bb2:
  %t6 = load i8, ptr %l3
  %t7 = zext i8 %t6 to i64
  switch i64 %t7, label %nocase.0 [ i64 1, label %bb3 i64 0, label %bb4 ]
nocase.0:
  unreachable
bb3:
  %t8 = getelementptr i8, ptr %l3, i64 8
  %t9 = load ptr, ptr %t8
  store ptr %t9, ptr %l4
  store i64 0, ptr %l5
  %t10 = load ptr, ptr %l2
  %t11 = load i64, ptr %l5
  %t12 = mul i64 %t11, 8
  %t13 = getelementptr i8, ptr %t10, i64 %t12
  store i64 0, ptr %t13
  %t14 = load ptr, ptr %l4
  store ptr %t14, ptr %l0
  %t15 = load ptr, ptr %l0
  ret ptr %t15
bb4:
  br label %bb1
bb5:
  %t16 = load ptr, ptr %l2
  %t17 = load i64, ptr %l6
  %t18 = mul i64 %t17, 8
  %t19 = getelementptr i8, ptr %t16, i64 %t18
  %t20 = load i64, ptr %l7
  store i64 %t20, ptr %t19
  %t21 = inttoptr i64 0 to ptr
  store ptr %t21, ptr %l8
  %t22 = load ptr, ptr %l8
  store ptr %t22, ptr %l0
  %t23 = load ptr, ptr %l0
  ret ptr %t23
}

define i64 @"__saw_rt_fs_unlink"(ptr %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca i32, align 4
  %l3 = alloca i32, align 4
  %l4 = alloca i8, align 1
  %l5 = alloca i64, align 8
  %l6 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = call i32 @unlink(ptr %t0)
  store i32 %t1, ptr %l2
  br label %bb2
bb1:
  %t2 = load i64, ptr %l0
  ret i64 %t2
bb2:
  %t3 = trunc i64 0 to i32
  %t4 = sext i32 %t3 to i64
  %t5 = icmp eq i64 %t4, 0
  %t6 = trunc i64 0 to i32
  %t7 = xor i1 %t5, 1
  br i1 %t7, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 452, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.1:
  store i32 %t6, ptr %l3
  %t8 = load i32, ptr %l2
  %t9 = load i32, ptr %l3
  %t10 = icmp eq i32 %t8, %t9
  %t11 = zext i1 %t10 to i8
  store i8 %t11, ptr %l4
  %t12 = load i8, ptr %l4
  %t13 = icmp ne i8 %t12, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  store i64 0, ptr %l0
  br label %bb1
bb4:
  %t14 = call i64 @__saw_rt_last_syserror()
  store i64 %t14, ptr %l5
  br label %bb5
bb5:
  %t15 = load i64, ptr %l5
  %t16 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t15)
  %t17 = extractvalue { i64, i1 } %t16, 0
  %t18 = extractvalue { i64, i1 } %t16, 1
  br i1 %t18, label %check.2, label %checked.3
check.2:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 455)
  unreachable
checked.3:
  store i64 %t17, ptr %l6
  %t19 = load i64, ptr %l6
  store i64 %t19, ptr %l0
  br label %bb1
}

define i64 @"__saw_rt_fs_rename"(ptr %p1, ptr %p2) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca i32, align 4
  %l4 = alloca i32, align 4
  %l5 = alloca i8, align 1
  %l6 = alloca i64, align 8
  %l7 = alloca i64, align 8
  store ptr %p1, ptr %l1
  store ptr %p2, ptr %l2
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = load ptr, ptr %l2
  %t2 = call i32 @rename(ptr %t0, ptr %t1)
  store i32 %t2, ptr %l3
  br label %bb2
bb1:
  %t3 = load i64, ptr %l0
  ret i64 %t3
bb2:
  %t4 = trunc i64 0 to i32
  %t5 = sext i32 %t4 to i64
  %t6 = icmp eq i64 %t5, 0
  %t7 = trunc i64 0 to i32
  %t8 = xor i1 %t6, 1
  br i1 %t8, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 461, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.1:
  store i32 %t7, ptr %l4
  %t9 = load i32, ptr %l3
  %t10 = load i32, ptr %l4
  %t11 = icmp eq i32 %t9, %t10
  %t12 = zext i1 %t11 to i8
  store i8 %t12, ptr %l5
  %t13 = load i8, ptr %l5
  %t14 = icmp ne i8 %t13, 0
  br i1 %t14, label %bb3, label %bb4
bb3:
  store i64 0, ptr %l0
  br label %bb1
bb4:
  %t15 = call i64 @__saw_rt_last_syserror()
  store i64 %t15, ptr %l6
  br label %bb5
bb5:
  %t16 = load i64, ptr %l6
  %t17 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t16)
  %t18 = extractvalue { i64, i1 } %t17, 0
  %t19 = extractvalue { i64, i1 } %t17, 1
  br i1 %t19, label %check.2, label %checked.3
check.2:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 464)
  unreachable
checked.3:
  store i64 %t18, ptr %l7
  %t20 = load i64, ptr %l7
  store i64 %t20, ptr %l0
  br label %bb1
}

define i64 @"__saw_rt_fs_mkdir"(ptr %p1, i64 %p2) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca i32, align 4
  %l4 = alloca i32, align 4
  %l5 = alloca i8, align 1
  %l6 = alloca i64, align 8
  %l7 = alloca i64, align 8
  store ptr %p1, ptr %l1
  store i64 %p2, ptr %l2
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = load i64, ptr %l2
  %t2 = call i32 @mkdir(ptr %t0, i64 %t1)
  store i32 %t2, ptr %l3
  br label %bb2
bb1:
  %t3 = load i64, ptr %l0
  ret i64 %t3
bb2:
  %t4 = trunc i64 0 to i32
  %t5 = sext i32 %t4 to i64
  %t6 = icmp eq i64 %t5, 0
  %t7 = trunc i64 0 to i32
  %t8 = xor i1 %t6, 1
  br i1 %t8, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 470, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.1:
  store i32 %t7, ptr %l4
  %t9 = load i32, ptr %l3
  %t10 = load i32, ptr %l4
  %t11 = icmp eq i32 %t9, %t10
  %t12 = zext i1 %t11 to i8
  store i8 %t12, ptr %l5
  %t13 = load i8, ptr %l5
  %t14 = icmp ne i8 %t13, 0
  br i1 %t14, label %bb3, label %bb4
bb3:
  store i64 0, ptr %l0
  br label %bb1
bb4:
  %t15 = call i64 @__saw_rt_last_syserror()
  store i64 %t15, ptr %l6
  br label %bb5
bb5:
  %t16 = load i64, ptr %l6
  %t17 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t16)
  %t18 = extractvalue { i64, i1 } %t17, 0
  %t19 = extractvalue { i64, i1 } %t17, 1
  br i1 %t19, label %check.2, label %checked.3
check.2:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 473)
  unreachable
checked.3:
  store i64 %t18, ptr %l7
  %t20 = load i64, ptr %l7
  store i64 %t20, ptr %l0
  br label %bb1
}

define i64 @"__saw_rt_fs_rmdir"(ptr %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca i32, align 4
  %l3 = alloca i32, align 4
  %l4 = alloca i8, align 1
  %l5 = alloca i64, align 8
  %l6 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = call i32 @rmdir(ptr %t0)
  store i32 %t1, ptr %l2
  br label %bb2
bb1:
  %t2 = load i64, ptr %l0
  ret i64 %t2
bb2:
  %t3 = trunc i64 0 to i32
  %t4 = sext i32 %t3 to i64
  %t5 = icmp eq i64 %t4, 0
  %t6 = trunc i64 0 to i32
  %t7 = xor i1 %t5, 1
  br i1 %t7, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 479, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.1:
  store i32 %t6, ptr %l3
  %t8 = load i32, ptr %l2
  %t9 = load i32, ptr %l3
  %t10 = icmp eq i32 %t8, %t9
  %t11 = zext i1 %t10 to i8
  store i8 %t11, ptr %l4
  %t12 = load i8, ptr %l4
  %t13 = icmp ne i8 %t12, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  store i64 0, ptr %l0
  br label %bb1
bb4:
  %t14 = call i64 @__saw_rt_last_syserror()
  store i64 %t14, ptr %l5
  br label %bb5
bb5:
  %t15 = load i64, ptr %l5
  %t16 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t15)
  %t17 = extractvalue { i64, i1 } %t16, 0
  %t18 = extractvalue { i64, i1 } %t16, 1
  br i1 %t18, label %check.2, label %checked.3
check.2:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 482)
  unreachable
checked.3:
  store i64 %t17, ptr %l6
  %t19 = load i64, ptr %l6
  store i64 %t19, ptr %l0
  br label %bb1
}

define i64 @"__saw_rt_fs_chdir"(ptr %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca i32, align 4
  %l3 = alloca i32, align 4
  %l4 = alloca i8, align 1
  %l5 = alloca i64, align 8
  %l6 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = call i32 @chdir(ptr %t0)
  store i32 %t1, ptr %l2
  br label %bb2
bb1:
  %t2 = load i64, ptr %l0
  ret i64 %t2
bb2:
  %t3 = trunc i64 0 to i32
  %t4 = sext i32 %t3 to i64
  %t5 = icmp eq i64 %t4, 0
  %t6 = trunc i64 0 to i32
  %t7 = xor i1 %t5, 1
  br i1 %t7, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 488, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.1:
  store i32 %t6, ptr %l3
  %t8 = load i32, ptr %l2
  %t9 = load i32, ptr %l3
  %t10 = icmp eq i32 %t8, %t9
  %t11 = zext i1 %t10 to i8
  store i8 %t11, ptr %l4
  %t12 = load i8, ptr %l4
  %t13 = icmp ne i8 %t12, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  store i64 0, ptr %l0
  br label %bb1
bb4:
  %t14 = call i64 @__saw_rt_last_syserror()
  store i64 %t14, ptr %l5
  br label %bb5
bb5:
  %t15 = load i64, ptr %l5
  %t16 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t15)
  %t17 = extractvalue { i64, i1 } %t16, 0
  %t18 = extractvalue { i64, i1 } %t16, 1
  br i1 %t18, label %check.2, label %checked.3
check.2:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 491)
  unreachable
checked.3:
  store i64 %t17, ptr %l6
  %t19 = load i64, ptr %l6
  store i64 %t19, ptr %l0
  br label %bb1
}

define i64 @"__saw_rt_env_set"(ptr %p1, ptr %p2, i64 %p3) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca ptr, align 8
  %l5 = alloca ptr, align 8
  %l6 = alloca i32, align 4
  %l7 = alloca i32, align 4
  %l8 = alloca i32, align 4
  %l9 = alloca i8, align 1
  %l10 = alloca i64, align 8
  %l11 = alloca i64, align 8
  store ptr %p1, ptr %l1
  store ptr %p2, ptr %l2
  store i64 %p3, ptr %l3
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l4
  %t1 = load ptr, ptr %l2
  store ptr %t1, ptr %l5
  %t2 = load i64, ptr %l3
  %t3 = trunc i64 %t2 to i32
  %t4 = sext i32 %t3 to i64
  %t5 = icmp eq i64 %t4, %t2
  %t6 = trunc i64 %t2 to i32
  %t7 = xor i1 %t5, 1
  br i1 %t7, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 497, ptr @.bytes.1, i64 28, i64 %t2)
  unreachable
casted.1:
  store i32 %t6, ptr %l6
  %t8 = load ptr, ptr %l4
  %t9 = load ptr, ptr %l5
  %t10 = load i32, ptr %l6
  %t11 = call i32 @setenv(ptr %t8, ptr %t9, i32 %t10)
  store i32 %t11, ptr %l7
  br label %bb2
bb1:
  %t12 = load i64, ptr %l0
  ret i64 %t12
bb2:
  %t13 = trunc i64 0 to i32
  %t14 = sext i32 %t13 to i64
  %t15 = icmp eq i64 %t14, 0
  %t16 = trunc i64 0 to i32
  %t17 = xor i1 %t15, 1
  br i1 %t17, label %cast.2, label %casted.3
cast.2:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 497, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.3:
  store i32 %t16, ptr %l8
  %t18 = load i32, ptr %l7
  %t19 = load i32, ptr %l8
  %t20 = icmp eq i32 %t18, %t19
  %t21 = zext i1 %t20 to i8
  store i8 %t21, ptr %l9
  %t22 = load i8, ptr %l9
  %t23 = icmp ne i8 %t22, 0
  br i1 %t23, label %bb3, label %bb4
bb3:
  store i64 0, ptr %l0
  br label %bb1
bb4:
  %t24 = call i64 @__saw_rt_last_syserror()
  store i64 %t24, ptr %l10
  br label %bb5
bb5:
  %t25 = load i64, ptr %l10
  %t26 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t25)
  %t27 = extractvalue { i64, i1 } %t26, 0
  %t28 = extractvalue { i64, i1 } %t26, 1
  br i1 %t28, label %check.4, label %checked.5
check.4:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 500)
  unreachable
checked.5:
  store i64 %t27, ptr %l11
  %t29 = load i64, ptr %l11
  store i64 %t29, ptr %l0
  br label %bb1
}

define i64 @"__saw_rt_env_unset"(ptr %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca i32, align 4
  %l3 = alloca i32, align 4
  %l4 = alloca i8, align 1
  %l5 = alloca i64, align 8
  %l6 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = call i32 @unsetenv(ptr %t0)
  store i32 %t1, ptr %l2
  br label %bb2
bb1:
  %t2 = load i64, ptr %l0
  ret i64 %t2
bb2:
  %t3 = trunc i64 0 to i32
  %t4 = sext i32 %t3 to i64
  %t5 = icmp eq i64 %t4, 0
  %t6 = trunc i64 0 to i32
  %t7 = xor i1 %t5, 1
  br i1 %t7, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 506, ptr @.bytes.1, i64 28, i64 0)
  unreachable
casted.1:
  store i32 %t6, ptr %l3
  %t8 = load i32, ptr %l2
  %t9 = load i32, ptr %l3
  %t10 = icmp eq i32 %t8, %t9
  %t11 = zext i1 %t10 to i8
  store i8 %t11, ptr %l4
  %t12 = load i8, ptr %l4
  %t13 = icmp ne i8 %t12, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  store i64 0, ptr %l0
  br label %bb1
bb4:
  %t14 = call i64 @__saw_rt_last_syserror()
  store i64 %t14, ptr %l5
  br label %bb5
bb5:
  %t15 = load i64, ptr %l5
  %t16 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 0, i64 %t15)
  %t17 = extractvalue { i64, i1 } %t16, 0
  %t18 = extractvalue { i64, i1 } %t16, 1
  br i1 %t18, label %check.2, label %checked.3
check.2:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 509)
  unreachable
checked.3:
  store i64 %t17, ptr %l6
  %t19 = load i64, ptr %l6
  store i64 %t19, ptr %l0
  br label %bb1
}

define internal void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %p1, i64 %p2) #0 {
entry:
  %l0 = alloca [0 x i8], align 1
  %l1 = alloca ptr, align 8
  %l2 = alloca i64, align 8
  store ptr %p1, ptr %l1
  store i64 %p2, ptr %l2
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = load i64, ptr %l2
  call void @__saw_rt_panic(ptr %t0, i64 %t1)
  unreachable
}

define internal void @"saw std.string.string_literal(bytes: UnsafePointer<Int8>)"(ptr %ret, ptr %p1) #0 {
entry:
  %l0 = alloca [8 x i8], align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca [8 x i8], align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l2
  call void @llvm.memcpy.p0.p0.i64(ptr %l0, ptr %l2, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %ret, ptr %l0, i64 8, i1 false)
  ret void
}

define internal ptr @"saw std.string.string_bytes(text: &String)"(ptr noalias %p1) #0 {
entry:
  %l0 = alloca ptr, align 8
  %l1 = alloca ptr, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = load ptr, ptr %t0
  store ptr %t1, ptr %l0
  %t2 = load ptr, ptr %l0
  ret ptr %t2
}

define internal i64 @"saw std.string.string_length(text: &String)"(ptr noalias %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l2
  %t1 = load ptr, ptr %l2
  %t2 = call i64 @"saw std.string.String.len()"(ptr %t1)
  store i64 %t2, ptr %l3
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3
  store i64 %t3, ptr %l0
  %t4 = load i64, ptr %l0
  ret i64 %t4
}

define internal void @"saw os_ops.ipv4_sockaddr(addr: UInt32, port: Int)"(ptr %ret, i32 %p1, i64 %p2) #0 {
entry:
  %l0 = alloca [16 x i8], align 8
  %l1 = alloca i32, align 4
  %l2 = alloca i64, align 8
  %l3 = alloca [16 x i8], align 8
  %l4 = alloca i16, align 2
  %l5 = alloca i16, align 2
  %l6 = alloca i32, align 4
  %l7 = alloca i64, align 8
  %l8 = alloca [16 x i8], align 8
  %l9 = alloca ptr, align 8
  %l10 = alloca ptr, align 8
  store i32 %p1, ptr %l1
  store i64 %p2, ptr %l2
  br label %bb0
bb0:
  %t0 = trunc i64 0 to i16
  %t1 = zext i16 %t0 to i64
  %t2 = icmp eq i64 %t1, 0
  %t3 = icmp sge i64 0, 0
  %t4 = and i1 %t2, %t3
  %t5 = trunc i64 0 to i16
  %t6 = xor i1 %t4, 1
  br i1 %t6, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 146, ptr @.bytes.3, i64 29, i64 0)
  unreachable
casted.1:
  store i16 %t5, ptr %l4
  %t7 = load i64, ptr %l2
  %t8 = call i16 @"saw os_ops.htons(port: Int)"(i64 %t7)
  store i16 %t8, ptr %l5
  br label %bb1
bb1:
  %t9 = load i32, ptr %l1
  store i32 %t9, ptr %l6
  %t10 = icmp eq i64 0, 0
  %t11 = icmp sge i64 0, 0
  %t12 = and i1 %t10, %t11
  %t13 = xor i1 %t12, 1
  br i1 %t13, label %cast.2, label %casted.3
cast.2:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 146, ptr @.bytes.4, i64 29, i64 0)
  unreachable
casted.3:
  store i64 0, ptr %l7
  %t14 = load i16, ptr %l4
  store i16 %t14, ptr %l8
  %t15 = getelementptr i8, ptr %l8, i64 2
  %t16 = load i16, ptr %l5
  store i16 %t16, ptr %t15
  %t17 = getelementptr i8, ptr %l8, i64 4
  %t18 = load i32, ptr %l6
  store i32 %t18, ptr %t17
  %t19 = getelementptr i8, ptr %l8, i64 8
  %t20 = load i64, ptr %l7
  store i64 %t20, ptr %t19
  call void @llvm.memcpy.p0.p0.i64(ptr %l3, ptr %l8, i64 16, i1 false)
  store ptr %l3, ptr %l9
  %t21 = load ptr, ptr %l9
  store ptr %t21, ptr %l10
  %t22 = load ptr, ptr %l10
  call void @__saw_rt_sin_set_family(ptr %t22)
  br label %bb2
bb2:
  call void @llvm.memcpy.p0.p0.i64(ptr %l0, ptr %l3, i64 16, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %ret, ptr %l0, i64 16, i1 false)
  ret void
}

define internal i64 @"saw os_ops.ntohs(net: UInt16)"(i16 %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i16, align 2
  %l2 = alloca i64, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca i64, align 8
  %l5 = alloca i64, align 8
  %l6 = alloca i64, align 8
  %l7 = alloca i64, align 8
  %l8 = alloca i64, align 8
  store i16 %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load i16, ptr %l1
  %t1 = zext i16 %t0 to i64
  %t2 = trunc i64 %t1 to i16
  %t3 = icmp eq i16 %t2, %t0
  %t4 = icmp sge i64 %t1, 0
  %t5 = and i1 %t3, %t4
  %t6 = zext i16 %t0 to i64
  store i64 %t6, ptr %l3
  %t7 = load i64, ptr %l3
  store i64 %t7, ptr %l2
  %t8 = load i64, ptr %l2
  %t9 = and i64 %t8, 255
  store i64 %t9, ptr %l4
  %t10 = load i64, ptr %l4
  %t11 = icmp uge i64 8, 64
  br i1 %t11, label %check.0, label %checked.1
check.0:
  call void @__saw_fail_shift(ptr @.bytes.0, i64 10, i64 139)
  unreachable
checked.1:
  %t12 = shl i64 %t10, 8
  store i64 %t12, ptr %l5
  %t13 = load i64, ptr %l2
  %t14 = icmp uge i64 8, 64
  br i1 %t14, label %check.2, label %checked.3
check.2:
  call void @__saw_fail_shift(ptr @.bytes.0, i64 10, i64 139)
  unreachable
checked.3:
  %t15 = ashr i64 %t13, 8
  store i64 %t15, ptr %l6
  %t16 = load i64, ptr %l6
  %t17 = and i64 %t16, 255
  store i64 %t17, ptr %l7
  %t18 = load i64, ptr %l5
  %t19 = load i64, ptr %l7
  %t20 = or i64 %t18, %t19
  store i64 %t20, ptr %l8
  %t21 = load i64, ptr %l8
  store i64 %t21, ptr %l0
  %t22 = load i64, ptr %l0
  ret i64 %t22
}

define internal i64 @"saw std.string.String.len()"(ptr noalias %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = load ptr, ptr %t0
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  store ptr %t2, ptr %l2
  %t3 = load i64, ptr @"static std.string.LENGTH_SLOT"
  store i64 %t3, ptr %l4
  %t4 = load ptr, ptr %l2
  %t5 = load i64, ptr %l4
  %t6 = mul i64 %t5, 8
  %t7 = getelementptr i8, ptr %t4, i64 %t6
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l0
  %t9 = load i64, ptr %l0
  ret i64 %t9
}

define internal i16 @"saw os_ops.htons(port: Int)"(i64 %p1) #0 {
entry:
  %l0 = alloca i16, align 2
  %l1 = alloca i64, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca i64, align 8
  %l5 = alloca i64, align 8
  %l6 = alloca i64, align 8
  %l7 = alloca i16, align 2
  store i64 %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load i64, ptr %l1
  %t1 = and i64 %t0, 255
  store i64 %t1, ptr %l2
  %t2 = load i64, ptr %l2
  %t3 = icmp uge i64 8, 64
  br i1 %t3, label %check.0, label %checked.1
check.0:
  call void @__saw_fail_shift(ptr @.bytes.0, i64 10, i64 133)
  unreachable
checked.1:
  %t4 = shl i64 %t2, 8
  store i64 %t4, ptr %l3
  %t5 = load i64, ptr %l1
  %t6 = icmp uge i64 8, 64
  br i1 %t6, label %check.2, label %checked.3
check.2:
  call void @__saw_fail_shift(ptr @.bytes.0, i64 10, i64 133)
  unreachable
checked.3:
  %t7 = ashr i64 %t5, 8
  store i64 %t7, ptr %l4
  %t8 = load i64, ptr %l4
  %t9 = and i64 %t8, 255
  store i64 %t9, ptr %l5
  %t10 = load i64, ptr %l3
  %t11 = load i64, ptr %l5
  %t12 = or i64 %t10, %t11
  store i64 %t12, ptr %l6
  %t13 = load i64, ptr %l6
  %t14 = trunc i64 %t13 to i16
  %t15 = zext i16 %t14 to i64
  %t16 = icmp eq i64 %t15, %t13
  %t17 = icmp sge i64 %t13, 0
  %t18 = and i1 %t16, %t17
  %t19 = trunc i64 %t13 to i16
  %t20 = xor i1 %t18, 1
  br i1 %t20, label %cast.4, label %casted.5
cast.4:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 10, i64 133, ptr @.bytes.3, i64 29, i64 %t13)
  unreachable
casted.5:
  store i16 %t19, ptr %l7
  %t21 = load i16, ptr %l7
  store i16 %t21, ptr %l0
  %t22 = load i16, ptr %l0
  ret i16 %t22
}

define internal i64 @__saw_render_uint(ptr %out, i64 %v) #0 {
entry:
  %tmp = alloca [24 x i8], align 1
  br label %loop
loop:
  %n = phi i64 [ %v, %entry ], [ %q, %loop ]
  %i = phi i64 [ 24, %entry ], [ %i1, %loop ]
  %q = udiv i64 %n, 10
  %r = urem i64 %n, 10
  %d = trunc i64 %r to i8
  %c = add i8 %d, 48
  %i1 = sub i64 %i, 1
  %p = getelementptr i8, ptr %tmp, i64 %i1
  store i8 %c, ptr %p
  %more = icmp ne i64 %q, 0
  br i1 %more, label %loop, label %done
done:
  %len = sub i64 24, %i1
  %src = getelementptr i8, ptr %tmp, i64 %i1
  call void @llvm.memcpy.p0.p0.i64(ptr %out, ptr %src, i64 %len, i1 false)
  ret i64 %len
}

define internal i64 @__saw_render_int(ptr %out, i64 %v) #0 {
entry:
  %neg = icmp slt i64 %v, 0
  br i1 %neg, label %minus, label %plain
minus:
  store i8 45, ptr %out
  %mag = sub i64 0, %v
  %rest = getelementptr i8, ptr %out, i64 1
  %n = call i64 @__saw_render_uint(ptr %rest, i64 %mag)
  %len = add i64 %n, 1
  ret i64 %len
plain:
  %m = call i64 @__saw_render_uint(ptr %out, i64 %v)
  ret i64 %m
}

define internal i64 @__saw_append(ptr %buf, i64 %pos, ptr %src, i64 %len) #0 {
entry:
  %closed = icmp slt i64 %pos, 0
  br i1 %closed, label %keep, label %open
keep:
  ret i64 %pos
open:
  %room = sub i64 508, %pos
  %fits = icmp ule i64 %len, %room
  br i1 %fits, label %whole, label %back
whole:
  %at = getelementptr i8, ptr %buf, i64 %pos
  call void @llvm.memcpy.p0.p0.i64(ptr %at, ptr %src, i64 %len, i1 false)
  %end = add i64 %pos, %len
  ret i64 %end
back:
  %n = phi i64 [ %room, %open ], [ %n1, %step ]
  %none = icmp eq i64 %n, 0
  br i1 %none, label %cut, label %test
test:
  %p = getelementptr i8, ptr %src, i64 %n
  %b = load i8, ptr %p
  %hi = and i8 %b, -64
  %inside = icmp eq i8 %hi, -128
  br i1 %inside, label %step, label %cut
step:
  %n1 = sub i64 %n, 1
  br label %back
cut:
  %at2 = getelementptr i8, ptr %buf, i64 %pos
  call void @llvm.memcpy.p0.p0.i64(ptr %at2, ptr %src, i64 %n, i1 false)
  %stop = add i64 %pos, %n
  %shut = sub i64 -1, %stop
  ret i64 %shut
}

define internal i64 @__saw_finish(ptr %buf, i64 %pos) #0 {
entry:
  %cut = icmp slt i64 %pos, 0
  br i1 %cut, label %mark, label %line
mark:
  %stop = sub i64 -1, %pos
  %m0 = getelementptr i8, ptr %buf, i64 %stop
  store i8 -30, ptr %m0
  %m1 = getelementptr i8, ptr %m0, i64 1
  store i8 -128, ptr %m1
  %m2 = getelementptr i8, ptr %m0, i64 2
  store i8 -90, ptr %m2
  %marked = add i64 %stop, 3
  br label %line
line:
  %end = phi i64 [ %marked, %mark ], [ %pos, %entry ]
  %nl = getelementptr i8, ptr %buf, i64 %end
  store i8 10, ptr %nl
  %total = add i64 %end, 1
  ret i64 %total
}

define internal i64 @__saw_append_int(ptr %buf, i64 %pos, i64 %v) #0 {
entry:
  %tmp = alloca [24 x i8], align 1
  %n = call i64 @__saw_render_int(ptr %tmp, i64 %v)
  %end = call i64 @__saw_append(ptr %buf, i64 %pos, ptr %tmp, i64 %n)
  ret i64 %end
}

define internal i64 @__saw_append_uint(ptr %buf, i64 %pos, i64 %v) #0 {
entry:
  %tmp = alloca [24 x i8], align 1
  %n = call i64 @__saw_render_uint(ptr %tmp, i64 %v)
  %end = call i64 @__saw_append(ptr %buf, i64 %pos, ptr %tmp, i64 %n)
  ret i64 %end
}

@__saw_fail_at = private unnamed_addr constant [9 x i8] c"panic at "
@__saw_fail_colon = private unnamed_addr constant [2 x i8] c": "
@__saw_fail_true = private unnamed_addr constant [4 x i8] c"true"
@__saw_fail_false = private unnamed_addr constant [5 x i8] c"false"
@__saw_fail_overflow.reason = private unnamed_addr constant [16 x i8] c"integer overflow"
@__saw_fail_divide.reason = private unnamed_addr constant [16 x i8] c"division by zero"
@__saw_fail_shift.reason = private unnamed_addr constant [18 x i8] c"shift out of range"
@__saw_fail_unwrap.reason = private unnamed_addr constant [20 x i8] c"force unwrap of None"
@__saw_fail_try.reason = private unnamed_addr constant [11 x i8] c"try! failed"

define internal i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line) #0 {
entry:
  %at = call i64 @__saw_append(ptr %buf, i64 0, ptr @__saw_fail_at, i64 9)
  %named = call i64 @__saw_append(ptr %buf, i64 %at, ptr %file, i64 %file_len)
  %known = icmp sge i64 %line, 0
  br i1 %known, label %number, label %tail
number:
  %colon = call i64 @__saw_append(ptr %buf, i64 %named, ptr @__saw_fail_colon, i64 1)
  %lined = call i64 @__saw_append_uint(ptr %buf, i64 %colon, i64 %line)
  br label %tail
tail:
  %pos = phi i64 [ %named, %entry ], [ %lined, %number ]
  %end = call i64 @__saw_append(ptr %buf, i64 %pos, ptr @__saw_fail_colon, i64 2)
  ret i64 %end
}

define internal void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr %text, i64 %text_len) noinline noreturn #0 {
entry:
  %buf = alloca [512 x i8], align 1
  %head = call i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line)
  %done = call i64 @__saw_append(ptr %buf, i64 %head, ptr %text, i64 %text_len)
  %end = call i64 @__saw_finish(ptr %buf, i64 %done)
  call void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %buf, i64 %end)
  unreachable
}

define internal void @__saw_fail_signed(ptr %file, i64 %file_len, i64 %line, ptr %text, i64 %text_len, i64 %v) noinline noreturn #0 {
entry:
  %buf = alloca [512 x i8], align 1
  %head = call i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line)
  %pos = call i64 @__saw_append(ptr %buf, i64 %head, ptr %text, i64 %text_len)
  %done = call i64 @__saw_append_int(ptr %buf, i64 %pos, i64 %v)
  %end = call i64 @__saw_finish(ptr %buf, i64 %done)
  call void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %buf, i64 %end)
  unreachable
}

define internal void @__saw_fail_unsigned(ptr %file, i64 %file_len, i64 %line, ptr %text, i64 %text_len, i64 %v) noinline noreturn #0 {
entry:
  %buf = alloca [512 x i8], align 1
  %head = call i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line)
  %pos = call i64 @__saw_append(ptr %buf, i64 %head, ptr %text, i64 %text_len)
  %done = call i64 @__saw_append_uint(ptr %buf, i64 %pos, i64 %v)
  %end = call i64 @__saw_finish(ptr %buf, i64 %done)
  call void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %buf, i64 %end)
  unreachable
}

define internal void @__saw_fail_parts(ptr %file, i64 %file_len, i64 %line, ptr %text, i64 %text_len, ptr %parts, i64 %count) noinline noreturn #0 {
entry:
  %buf = alloca [512 x i8], align 1
  %head = call i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line)
  %pos = call i64 @__saw_append(ptr %buf, i64 %head, ptr %text, i64 %text_len)
  br label %loop
loop:
  %i = phi i64 [ 0, %entry ], [ %i1, %next ]
  %at = phi i64 [ %pos, %entry ], [ %after, %next ]
  %more = icmp slt i64 %i, %count
  br i1 %more, label %part, label %last
part:
  %offset = mul i64 %i, 24
  %p = getelementptr i8, ptr %parts, i64 %offset
  %kind = load i64, ptr %p
  %first = getelementptr i8, ptr %p, i64 8
  %second = getelementptr i8, ptr %p, i64 16
  switch i64 %kind, label %run [ i64 1, label %signed i64 2, label %unsigned i64 3, label %bool ]
run:
  %src = load ptr, ptr %first
  %len = load i64, ptr %second
  %ran = call i64 @__saw_append(ptr %buf, i64 %at, ptr %src, i64 %len)
  br label %next
signed:
  %sv = load i64, ptr %first
  %sd = call i64 @__saw_append_int(ptr %buf, i64 %at, i64 %sv)
  br label %next
unsigned:
  %uv = load i64, ptr %first
  %ud = call i64 @__saw_append_uint(ptr %buf, i64 %at, i64 %uv)
  br label %next
bool:
  %byte = load i8, ptr %first
  %yes = icmp ne i8 %byte, 0
  %word = select i1 %yes, ptr @__saw_fail_true, ptr @__saw_fail_false
  %size = select i1 %yes, i64 4, i64 5
  %bd = call i64 @__saw_append(ptr %buf, i64 %at, ptr %word, i64 %size)
  br label %next
next:
  %after = phi i64 [ %ran, %run ], [ %sd, %signed ], [ %ud, %unsigned ], [ %bd, %bool ]
  %i1 = add i64 %i, 1
  br label %loop
last:
  %done = phi i64 [ %at, %loop ]
  %end = call i64 @__saw_finish(ptr %buf, i64 %done)
  call void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %buf, i64 %end)
  unreachable
}

define internal void @__saw_fail_overflow(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_overflow.reason, i64 16)
  unreachable
}

define internal void @__saw_fail_divide(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_divide.reason, i64 16)
  unreachable
}

define internal void @__saw_fail_shift(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_shift.reason, i64 18)
  unreachable
}

define internal void @__saw_fail_unwrap(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_unwrap.reason, i64 20)
  unreachable
}

define internal void @__saw_fail_try(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_try.reason, i64 11)
  unreachable
}

attributes #0 = { "frame-pointer"="non-leaf" }
