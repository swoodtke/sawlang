; sawc2 link manifest
; target x86_64-unknown-linux-gnu
; speed -O2
; runtime none

target triple = "x86_64-unknown-linux-gnu"

@.bytes.0 = private unnamed_addr constant [10 x i8] c"net_os.saw"
@"static net_os.EAGAIN" = internal global i64 11
@"static net_os.EINPROGRESS" = internal global i64 115
@"static net_os.EALREADY" = internal global i64 114
@"static net_os.EISCONN" = internal global i64 106
@"static net_os.EINTR" = internal global i64 4
@"static net_os.ECONNRESET" = internal global i64 104
@"static net_os.ECONNREFUSED" = internal global i64 111
@"static net_os.ECONNABORTED" = internal global i64 103
@"static net_os.EPIPE" = internal global i64 32
@"static net_os.ENOTCONN" = internal global i64 107
@"static net_os.ENOENT" = internal global i64 2
@"static net_os.EACCES" = internal global i64 13
@"static net_os.EPERM" = internal global i64 1
@"static net_os.EEXIST" = internal global i64 17
@"static net_os.EADDRINUSE" = internal global i64 98
@"static net_os.EINVAL" = internal global i64 22
@"static net_os.EMFILE" = internal global i64 24
@"static net_os.ENFILE" = internal global i64 23
@"static net_os.ENOMEM" = internal global i64 12
@"static net_os.ENOSPC" = internal global i64 28
@"static net_os.EHOSTUNREACH" = internal global i64 113
@"static net_os.ENETUNREACH" = internal global i64 101
@"static net_os.ETIMEDOUT" = internal global i64 110
@"static net_os.EHOSTDOWN" = internal global i64 112
@"static net_os.ENETDOWN" = internal global i64 100
@"static net_os.AF_INET_LO" = internal global i8 2
@"static net_os.AF_INET_HI" = internal global i8 0
@"static net_os.RAW_CODE_KEY" = internal global i64 0, align 8
@"static std.string.LENGTH_SLOT" = internal global i64 -1

declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare i64 @pthread_getspecific(i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare void @__saw_rt_panic(ptr, i64)
declare i32 @pthread_key_create(ptr, ptr)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare i32 @pthread_key_delete(i64)
declare ptr @__errno_location()
declare i32 @pthread_setspecific(i64, i64)

define i64 @"__saw_rt_last_raw_code"() #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i64, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca i8, align 1
  %l5 = alloca i64, align 8
  br label %bb0
bb0:
  %t0 = call i64 @"saw net_os.raw_code_key()"()
  store i64 %t0, ptr %l2
  br label %bb1
bb1:
  %t1 = load i64, ptr %l2
  %t2 = call i64 @pthread_getspecific(i64 %t1)
  store i64 %t2, ptr %l3
  br label %bb2
bb2:
  %t3 = load i64, ptr %l3
  store i64 %t3, ptr %l1
  %t4 = load i64, ptr %l1
  %t5 = icmp eq i64 %t4, 0
  %t6 = zext i1 %t5 to i8
  store i8 %t6, ptr %l4
  %t7 = load i8, ptr %l4
  %t8 = icmp ne i8 %t7, 0
  br i1 %t8, label %bb4, label %bb5
bb3:
  %t9 = load i64, ptr %l1
  %t10 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %t9, i64 1)
  %t11 = extractvalue { i64, i1 } %t10, 0
  %t12 = extractvalue { i64, i1 } %t10, 1
  br i1 %t12, label %check.0, label %checked.1
check.0:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 126)
  unreachable
checked.1:
  store i64 %t11, ptr %l5
  %t13 = load i64, ptr %l5
  store i64 %t13, ptr %l0
  %t14 = load i64, ptr %l0
  ret i64 %t14
bb4:
  store i64 0, ptr %l0
  %t15 = load i64, ptr %l0
  ret i64 %t15
bb5:
  br label %bb3
}

define i64 @"__saw_rt_last_syserror"() #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i64, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca i8, align 1
  %l4 = alloca i8, align 1
  %l5 = alloca i8, align 1
  %l6 = alloca i8, align 1
  %l7 = alloca i8, align 1
  %l8 = alloca i8, align 1
  %l9 = alloca i8, align 1
  %l10 = alloca i8, align 1
  %l11 = alloca i8, align 1
  %l12 = alloca i8, align 1
  %l13 = alloca i8, align 1
  %l14 = alloca i8, align 1
  %l15 = alloca i8, align 1
  %l16 = alloca i8, align 1
  %l17 = alloca i8, align 1
  %l18 = alloca i8, align 1
  %l19 = alloca i8, align 1
  %l20 = alloca i8, align 1
  %l21 = alloca i8, align 1
  %l22 = alloca i8, align 1
  %l23 = alloca i8, align 1
  %l24 = alloca i8, align 1
  %l25 = alloca i8, align 1
  %l26 = alloca i8, align 1
  %l27 = alloca i8, align 1
  %l28 = alloca i8, align 1
  %l29 = alloca i8, align 1
  %l30 = alloca i8, align 1
  %l31 = alloca i8, align 1
  %l32 = alloca i8, align 1
  %l33 = alloca i8, align 1
  %l34 = alloca i8, align 1
  %l35 = alloca i8, align 1
  %l36 = alloca i8, align 1
  %l37 = alloca i8, align 1
  %l38 = alloca i8, align 1
  %l39 = alloca i8, align 1
  %l40 = alloca i8, align 1
  %l41 = alloca i8, align 1
  %l42 = alloca i8, align 1
  %l43 = alloca i8, align 1
  %l44 = alloca i8, align 1
  %l45 = alloca i8, align 1
  %l46 = alloca i8, align 1
  %l47 = alloca i8, align 1
  %l48 = alloca i8, align 1
  %l49 = alloca i8, align 1
  %l50 = alloca i8, align 1
  %l51 = alloca i8, align 1
  %l52 = alloca i8, align 1
  %l53 = alloca i8, align 1
  %l54 = alloca i64, align 8
  br label %bb0
bb0:
  %t0 = call i64 @"saw net_os.errno_value()"()
  store i64 %t0, ptr %l2
  br label %bb1
bb1:
  %t1 = load i64, ptr %l2
  store i64 %t1, ptr %l1
  %t2 = load i64, ptr %l1
  call void @"saw net_os.raw_code_store(value: Int)"(i64 %t2)
  br label %bb2
bb2:
  %t3 = load i64, ptr %l1
  %t4 = load i64, ptr @"static net_os.EAGAIN"
  %t5 = icmp eq i64 %t3, %t4
  %t6 = zext i1 %t5 to i8
  store i8 %t6, ptr %l4
  %t7 = load i8, ptr %l4
  %t8 = icmp ne i8 %t7, 0
  br i1 %t8, label %bb4, label %bb5
bb3:
  %t9 = load i8, ptr %l3
  %t10 = icmp eq i8 %t9, %t9
  store i8 %t9, ptr %l53
  %t11 = load i8, ptr %l53
  %t12 = zext i8 %t11 to i64
  %t13 = trunc i64 %t12 to i8
  %t14 = icmp eq i8 %t13, %t11
  %t15 = icmp sge i64 %t12, 0
  %t16 = and i1 %t14, %t15
  %t17 = zext i8 %t11 to i64
  store i64 %t17, ptr %l54
  %t18 = load i64, ptr %l54
  store i64 %t18, ptr %l0
  %t19 = load i64, ptr %l0
  ret i64 %t19
bb4:
  store i8 1, ptr %l5
  %t20 = load i8, ptr %l5
  store i8 %t20, ptr %l3
  br label %bb3
bb5:
  %t21 = load i64, ptr %l1
  %t22 = load i64, ptr @"static net_os.EINPROGRESS"
  %t23 = icmp eq i64 %t21, %t22
  %t24 = zext i1 %t23 to i8
  store i8 %t24, ptr %l7
  %t25 = load i8, ptr %l7
  %t26 = icmp ne i8 %t25, 0
  br i1 %t26, label %bb8, label %bb7
bb6:
  %t27 = load i8, ptr %l6
  %t28 = icmp ne i8 %t27, 0
  br i1 %t28, label %bb9, label %bb10
bb7:
  %t29 = load i64, ptr %l1
  %t30 = load i64, ptr @"static net_os.EALREADY"
  %t31 = icmp eq i64 %t29, %t30
  %t32 = zext i1 %t31 to i8
  store i8 %t32, ptr %l8
  %t33 = load i8, ptr %l8
  store i8 %t33, ptr %l6
  br label %bb6
bb8:
  store i8 1, ptr %l6
  br label %bb6
bb9:
  store i8 2, ptr %l9
  %t34 = load i8, ptr %l9
  store i8 %t34, ptr %l3
  br label %bb3
bb10:
  %t35 = load i64, ptr %l1
  %t36 = load i64, ptr @"static net_os.EISCONN"
  %t37 = icmp eq i64 %t35, %t36
  %t38 = zext i1 %t37 to i8
  store i8 %t38, ptr %l10
  %t39 = load i8, ptr %l10
  %t40 = icmp ne i8 %t39, 0
  br i1 %t40, label %bb11, label %bb12
bb11:
  store i8 3, ptr %l11
  %t41 = load i8, ptr %l11
  store i8 %t41, ptr %l3
  br label %bb3
bb12:
  %t42 = load i64, ptr %l1
  %t43 = load i64, ptr @"static net_os.EINTR"
  %t44 = icmp eq i64 %t42, %t43
  %t45 = zext i1 %t44 to i8
  store i8 %t45, ptr %l12
  %t46 = load i8, ptr %l12
  %t47 = icmp ne i8 %t46, 0
  br i1 %t47, label %bb13, label %bb14
bb13:
  store i8 4, ptr %l13
  %t48 = load i8, ptr %l13
  store i8 %t48, ptr %l3
  br label %bb3
bb14:
  %t49 = load i64, ptr %l1
  %t50 = load i64, ptr @"static net_os.ECONNRESET"
  %t51 = icmp eq i64 %t49, %t50
  %t52 = zext i1 %t51 to i8
  store i8 %t52, ptr %l14
  %t53 = load i8, ptr %l14
  %t54 = icmp ne i8 %t53, 0
  br i1 %t54, label %bb15, label %bb16
bb15:
  store i8 5, ptr %l15
  %t55 = load i8, ptr %l15
  store i8 %t55, ptr %l3
  br label %bb3
bb16:
  %t56 = load i64, ptr %l1
  %t57 = load i64, ptr @"static net_os.ECONNREFUSED"
  %t58 = icmp eq i64 %t56, %t57
  %t59 = zext i1 %t58 to i8
  store i8 %t59, ptr %l16
  %t60 = load i8, ptr %l16
  %t61 = icmp ne i8 %t60, 0
  br i1 %t61, label %bb17, label %bb18
bb17:
  store i8 6, ptr %l17
  %t62 = load i8, ptr %l17
  store i8 %t62, ptr %l3
  br label %bb3
bb18:
  %t63 = load i64, ptr %l1
  %t64 = load i64, ptr @"static net_os.ECONNABORTED"
  %t65 = icmp eq i64 %t63, %t64
  %t66 = zext i1 %t65 to i8
  store i8 %t66, ptr %l18
  %t67 = load i8, ptr %l18
  %t68 = icmp ne i8 %t67, 0
  br i1 %t68, label %bb19, label %bb20
bb19:
  store i8 7, ptr %l19
  %t69 = load i8, ptr %l19
  store i8 %t69, ptr %l3
  br label %bb3
bb20:
  %t70 = load i64, ptr %l1
  %t71 = load i64, ptr @"static net_os.EPIPE"
  %t72 = icmp eq i64 %t70, %t71
  %t73 = zext i1 %t72 to i8
  store i8 %t73, ptr %l20
  %t74 = load i8, ptr %l20
  %t75 = icmp ne i8 %t74, 0
  br i1 %t75, label %bb21, label %bb22
bb21:
  store i8 8, ptr %l21
  %t76 = load i8, ptr %l21
  store i8 %t76, ptr %l3
  br label %bb3
bb22:
  %t77 = load i64, ptr %l1
  %t78 = load i64, ptr @"static net_os.ENOTCONN"
  %t79 = icmp eq i64 %t77, %t78
  %t80 = zext i1 %t79 to i8
  store i8 %t80, ptr %l22
  %t81 = load i8, ptr %l22
  %t82 = icmp ne i8 %t81, 0
  br i1 %t82, label %bb23, label %bb24
bb23:
  store i8 9, ptr %l23
  %t83 = load i8, ptr %l23
  store i8 %t83, ptr %l3
  br label %bb3
bb24:
  %t84 = load i64, ptr %l1
  %t85 = load i64, ptr @"static net_os.ENOENT"
  %t86 = icmp eq i64 %t84, %t85
  %t87 = zext i1 %t86 to i8
  store i8 %t87, ptr %l24
  %t88 = load i8, ptr %l24
  %t89 = icmp ne i8 %t88, 0
  br i1 %t89, label %bb25, label %bb26
bb25:
  store i8 10, ptr %l25
  %t90 = load i8, ptr %l25
  store i8 %t90, ptr %l3
  br label %bb3
bb26:
  %t91 = load i64, ptr %l1
  %t92 = load i64, ptr @"static net_os.EACCES"
  %t93 = icmp eq i64 %t91, %t92
  %t94 = zext i1 %t93 to i8
  store i8 %t94, ptr %l27
  %t95 = load i8, ptr %l27
  %t96 = icmp ne i8 %t95, 0
  br i1 %t96, label %bb29, label %bb28
bb27:
  %t97 = load i8, ptr %l26
  %t98 = icmp ne i8 %t97, 0
  br i1 %t98, label %bb30, label %bb31
bb28:
  %t99 = load i64, ptr %l1
  %t100 = load i64, ptr @"static net_os.EPERM"
  %t101 = icmp eq i64 %t99, %t100
  %t102 = zext i1 %t101 to i8
  store i8 %t102, ptr %l28
  %t103 = load i8, ptr %l28
  store i8 %t103, ptr %l26
  br label %bb27
bb29:
  store i8 1, ptr %l26
  br label %bb27
bb30:
  store i8 11, ptr %l29
  %t104 = load i8, ptr %l29
  store i8 %t104, ptr %l3
  br label %bb3
bb31:
  %t105 = load i64, ptr %l1
  %t106 = load i64, ptr @"static net_os.EEXIST"
  %t107 = icmp eq i64 %t105, %t106
  %t108 = zext i1 %t107 to i8
  store i8 %t108, ptr %l30
  %t109 = load i8, ptr %l30
  %t110 = icmp ne i8 %t109, 0
  br i1 %t110, label %bb32, label %bb33
bb32:
  store i8 12, ptr %l31
  %t111 = load i8, ptr %l31
  store i8 %t111, ptr %l3
  br label %bb3
bb33:
  %t112 = load i64, ptr %l1
  %t113 = load i64, ptr @"static net_os.EADDRINUSE"
  %t114 = icmp eq i64 %t112, %t113
  %t115 = zext i1 %t114 to i8
  store i8 %t115, ptr %l32
  %t116 = load i8, ptr %l32
  %t117 = icmp ne i8 %t116, 0
  br i1 %t117, label %bb34, label %bb35
bb34:
  store i8 13, ptr %l33
  %t118 = load i8, ptr %l33
  store i8 %t118, ptr %l3
  br label %bb3
bb35:
  %t119 = load i64, ptr %l1
  %t120 = load i64, ptr @"static net_os.EINVAL"
  %t121 = icmp eq i64 %t119, %t120
  %t122 = zext i1 %t121 to i8
  store i8 %t122, ptr %l34
  %t123 = load i8, ptr %l34
  %t124 = icmp ne i8 %t123, 0
  br i1 %t124, label %bb36, label %bb37
bb36:
  store i8 14, ptr %l35
  %t125 = load i8, ptr %l35
  store i8 %t125, ptr %l3
  br label %bb3
bb37:
  %t126 = load i64, ptr %l1
  %t127 = load i64, ptr @"static net_os.EMFILE"
  %t128 = icmp eq i64 %t126, %t127
  %t129 = zext i1 %t128 to i8
  store i8 %t129, ptr %l37
  %t130 = load i8, ptr %l37
  %t131 = icmp ne i8 %t130, 0
  br i1 %t131, label %bb40, label %bb39
bb38:
  %t132 = load i8, ptr %l36
  %t133 = icmp ne i8 %t132, 0
  br i1 %t133, label %bb45, label %bb46
bb39:
  %t134 = load i64, ptr %l1
  %t135 = load i64, ptr @"static net_os.ENFILE"
  %t136 = icmp eq i64 %t134, %t135
  %t137 = zext i1 %t136 to i8
  store i8 %t137, ptr %l38
  %t138 = load i8, ptr %l38
  %t139 = icmp ne i8 %t138, 0
  br i1 %t139, label %bb42, label %bb41
bb40:
  store i8 1, ptr %l36
  br label %bb38
bb41:
  %t140 = load i64, ptr %l1
  %t141 = load i64, ptr @"static net_os.ENOMEM"
  %t142 = icmp eq i64 %t140, %t141
  %t143 = zext i1 %t142 to i8
  store i8 %t143, ptr %l39
  %t144 = load i8, ptr %l39
  %t145 = icmp ne i8 %t144, 0
  br i1 %t145, label %bb44, label %bb43
bb42:
  store i8 1, ptr %l36
  br label %bb38
bb43:
  %t146 = load i64, ptr %l1
  %t147 = load i64, ptr @"static net_os.ENOSPC"
  %t148 = icmp eq i64 %t146, %t147
  %t149 = zext i1 %t148 to i8
  store i8 %t149, ptr %l40
  %t150 = load i8, ptr %l40
  store i8 %t150, ptr %l36
  br label %bb38
bb44:
  store i8 1, ptr %l36
  br label %bb38
bb45:
  store i8 15, ptr %l41
  %t151 = load i8, ptr %l41
  store i8 %t151, ptr %l3
  br label %bb3
bb46:
  %t152 = load i64, ptr %l1
  %t153 = load i64, ptr @"static net_os.EHOSTUNREACH"
  %t154 = icmp eq i64 %t152, %t153
  %t155 = zext i1 %t154 to i8
  store i8 %t155, ptr %l42
  %t156 = load i8, ptr %l42
  %t157 = icmp ne i8 %t156, 0
  br i1 %t157, label %bb47, label %bb48
bb47:
  store i8 17, ptr %l43
  %t158 = load i8, ptr %l43
  store i8 %t158, ptr %l3
  br label %bb3
bb48:
  %t159 = load i64, ptr %l1
  %t160 = load i64, ptr @"static net_os.ENETUNREACH"
  %t161 = icmp eq i64 %t159, %t160
  %t162 = zext i1 %t161 to i8
  store i8 %t162, ptr %l44
  %t163 = load i8, ptr %l44
  %t164 = icmp ne i8 %t163, 0
  br i1 %t164, label %bb49, label %bb50
bb49:
  store i8 18, ptr %l45
  %t165 = load i8, ptr %l45
  store i8 %t165, ptr %l3
  br label %bb3
bb50:
  %t166 = load i64, ptr %l1
  %t167 = load i64, ptr @"static net_os.ETIMEDOUT"
  %t168 = icmp eq i64 %t166, %t167
  %t169 = zext i1 %t168 to i8
  store i8 %t169, ptr %l46
  %t170 = load i8, ptr %l46
  %t171 = icmp ne i8 %t170, 0
  br i1 %t171, label %bb51, label %bb52
bb51:
  store i8 19, ptr %l47
  %t172 = load i8, ptr %l47
  store i8 %t172, ptr %l3
  br label %bb3
bb52:
  %t173 = load i64, ptr %l1
  %t174 = load i64, ptr @"static net_os.EHOSTDOWN"
  %t175 = icmp eq i64 %t173, %t174
  %t176 = zext i1 %t175 to i8
  store i8 %t176, ptr %l48
  %t177 = load i8, ptr %l48
  %t178 = icmp ne i8 %t177, 0
  br i1 %t178, label %bb53, label %bb54
bb53:
  store i8 20, ptr %l49
  %t179 = load i8, ptr %l49
  store i8 %t179, ptr %l3
  br label %bb3
bb54:
  %t180 = load i64, ptr %l1
  %t181 = load i64, ptr @"static net_os.ENETDOWN"
  %t182 = icmp eq i64 %t180, %t181
  %t183 = zext i1 %t182 to i8
  store i8 %t183, ptr %l50
  %t184 = load i8, ptr %l50
  %t185 = icmp ne i8 %t184, 0
  br i1 %t185, label %bb55, label %bb56
bb55:
  store i8 21, ptr %l51
  %t186 = load i8, ptr %l51
  store i8 %t186, ptr %l3
  br label %bb3
bb56:
  store i8 16, ptr %l52
  %t187 = load i8, ptr %l52
  store i8 %t187, ptr %l3
  br label %bb3
}

define void @"__saw_rt_sin_set_family"(ptr %p1) #0 {
entry:
  %l0 = alloca [0 x i8], align 1
  %l1 = alloca ptr, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  store i64 0, ptr %l2
  %t0 = load ptr, ptr %l1
  %t1 = load i64, ptr %l2
  %t2 = mul i64 %t1, 1
  %t3 = getelementptr i8, ptr %t0, i64 %t2
  %t4 = load i8, ptr @"static net_os.AF_INET_LO"
  store i8 %t4, ptr %t3
  store i64 1, ptr %l3
  %t5 = load ptr, ptr %l1
  %t6 = load i64, ptr %l3
  %t7 = mul i64 %t6, 1
  %t8 = getelementptr i8, ptr %t5, i64 %t7
  %t9 = load i8, ptr @"static net_os.AF_INET_HI"
  store i8 %t9, ptr %t8
  ret void
}

define internal void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %p1, i64 %p2) #0 {
entry:
  %l0 = alloca [0 x i8], align 1
  %l1 = alloca ptr, align 8
  %l2 = alloca i64, align 8
  store ptr %p1, ptr %l1
  store i64 %p2, ptr %l2
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = load i64, ptr %l2
  call void @__saw_rt_panic(ptr %t0, i64 %t1)
  unreachable
}

define internal void @"saw std.string.string_literal(bytes: UnsafePointer<Int8>)"(ptr %ret, ptr %p1) #0 {
entry:
  %l0 = alloca [8 x i8], align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca [8 x i8], align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l2
  call void @llvm.memcpy.p0.p0.i64(ptr %l0, ptr %l2, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %ret, ptr %l0, i64 8, i1 false)
  ret void
}

define internal ptr @"saw std.string.string_bytes(text: &String)"(ptr noalias %p1) #0 {
entry:
  %l0 = alloca ptr, align 8
  %l1 = alloca ptr, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = load ptr, ptr %t0
  store ptr %t1, ptr %l0
  %t2 = load ptr, ptr %l0
  ret ptr %t2
}

define internal i64 @"saw std.string.string_length(text: &String)"(ptr noalias %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l2
  %t1 = load ptr, ptr %l2
  %t2 = call i64 @"saw std.string.String.len()"(ptr %t1)
  store i64 %t2, ptr %l3
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3
  store i64 %t3, ptr %l0
  %t4 = load i64, ptr %l0
  ret i64 %t4
}

define internal i64 @"saw net_os.raw_code_key()"() #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i64, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca i8, align 1
  %l5 = alloca i64, align 8
  %l6 = alloca i64, align 8
  %l7 = alloca ptr, align 8
  %l8 = alloca ptr, align 8
  %l9 = alloca ptr, align 8
  %l10 = alloca i32, align 4
  %l11 = alloca i64, align 8
  %l12 = alloca ptr, align 8
  %l13 = alloca i8, align 1
  %l14 = alloca i32, align 4
  %l15 = alloca ptr, align 8
  %l16 = alloca i64, align 8
  %l17 = alloca i64, align 8
  br label %bb0
bb0:
  store ptr @"static net_os.RAW_CODE_KEY", ptr %l2
  %t0 = load ptr, ptr %l2
  %t1 = call i64 @"saw Atomic.load() args Int"(ptr %t0)
  store i64 %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load i64, ptr %l3
  store i64 %t2, ptr %l1
  %t3 = load i64, ptr %l1
  %t4 = icmp ne i64 %t3, 0
  %t5 = zext i1 %t4 to i8
  store i8 %t5, ptr %l4
  %t6 = load i8, ptr %l4
  %t7 = icmp ne i8 %t6, 0
  br i1 %t7, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l6
  store ptr %l6, ptr %l7
  %t8 = load ptr, ptr %l7
  store ptr %t8, ptr %l8
  %t9 = inttoptr i64 0 to ptr
  store ptr %t9, ptr %l9
  %t10 = load ptr, ptr %l8
  %t11 = load ptr, ptr %l9
  %t12 = call i32 @pthread_key_create(ptr %t10, ptr %t11)
  store i32 %t12, ptr %l10
  br label %bb5
bb3:
  %t13 = load i64, ptr %l1
  %t14 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %t13, i64 1)
  %t15 = extractvalue { i64, i1 } %t14, 0
  %t16 = extractvalue { i64, i1 } %t14, 1
  br i1 %t16, label %check.0, label %checked.1
check.0:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 105)
  unreachable
checked.1:
  store i64 %t15, ptr %l5
  %t17 = load i64, ptr %l5
  store i64 %t17, ptr %l0
  %t18 = load i64, ptr %l0
  ret i64 %t18
bb4:
  br label %bb2
bb5:
  %t19 = load i64, ptr %l6
  %t20 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %t19, i64 1)
  %t21 = extractvalue { i64, i1 } %t20, 0
  %t22 = extractvalue { i64, i1 } %t20, 1
  br i1 %t22, label %check.2, label %checked.3
check.2:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 109)
  unreachable
checked.3:
  store i64 %t21, ptr %l11
  store ptr @"static net_os.RAW_CODE_KEY", ptr %l12
  %t23 = load ptr, ptr %l12
  %t24 = load i64, ptr %l11
  %t25 = call i8 @"saw Atomic.compare_exchange(expected: Int, desired: Int) args Int"(ptr %t23, i64 0, i64 %t24)
  store i8 %t25, ptr %l13
  br label %bb7
bb6:
  %t26 = load i64, ptr %l6
  %t27 = call i32 @pthread_key_delete(i64 %t26)
  store i32 %t27, ptr %l14
  br label %bb10
bb7:
  %t28 = load i8, ptr %l13
  %t29 = icmp ne i8 %t28, 0
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t30 = load i64, ptr %l6
  store i64 %t30, ptr %l0
  %t31 = load i64, ptr %l0
  ret i64 %t31
bb9:
  br label %bb6
bb10:
  store ptr @"static net_os.RAW_CODE_KEY", ptr %l15
  %t32 = load ptr, ptr %l15
  %t33 = call i64 @"saw Atomic.load() args Int"(ptr %t32)
  store i64 %t33, ptr %l16
  br label %bb11
bb11:
  %t34 = load i64, ptr %l16
  %t35 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %t34, i64 1)
  %t36 = extractvalue { i64, i1 } %t35, 0
  %t37 = extractvalue { i64, i1 } %t35, 1
  br i1 %t37, label %check.4, label %checked.5
check.4:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 113)
  unreachable
checked.5:
  store i64 %t36, ptr %l17
  %t38 = load i64, ptr %l17
  store i64 %t38, ptr %l0
  %t39 = load i64, ptr %l0
  ret i64 %t39
}

define internal i64 @"saw net_os.errno_value()"() #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca i64, align 8
  br label %bb0
bb0:
  %t0 = call ptr @__errno_location()
  store ptr %t0, ptr %l1
  br label %bb1
bb1:
  store i64 0, ptr %l2
  %t1 = load ptr, ptr %l1
  %t2 = load i64, ptr %l2
  %t3 = mul i64 %t2, 4
  %t4 = getelementptr i8, ptr %t1, i64 %t3
  %t5 = load i32, ptr %t4
  %t6 = sext i32 %t5 to i64
  %t7 = trunc i64 %t6 to i32
  %t8 = icmp eq i32 %t7, %t5
  %t9 = sext i32 %t5 to i64
  store i64 %t9, ptr %l3
  %t10 = load i64, ptr %l3
  store i64 %t10, ptr %l0
  %t11 = load i64, ptr %l0
  ret i64 %t11
}

define internal void @"saw net_os.raw_code_store(value: Int)"(i64 %p1) #0 {
entry:
  %l0 = alloca [0 x i8], align 1
  %l1 = alloca i64, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca i32, align 4
  store i64 %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = call i64 @"saw net_os.raw_code_key()"()
  store i64 %t0, ptr %l2
  br label %bb1
bb1:
  %t1 = load i64, ptr %l1
  %t2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %t1, i64 1)
  %t3 = extractvalue { i64, i1 } %t2, 0
  %t4 = extractvalue { i64, i1 } %t2, 1
  br i1 %t4, label %check.0, label %checked.1
check.0:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 10, i64 117)
  unreachable
checked.1:
  store i64 %t3, ptr %l3
  %t5 = load i64, ptr %l2
  %t6 = load i64, ptr %l3
  %t7 = call i32 @pthread_setspecific(i64 %t5, i64 %t6)
  store i32 %t7, ptr %l4
  br label %bb2
bb2:
  ret void
}

define internal i64 @"saw std.string.String.len()"(ptr noalias %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = load ptr, ptr %t0
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  store ptr %t2, ptr %l2
  %t3 = load i64, ptr @"static std.string.LENGTH_SLOT"
  store i64 %t3, ptr %l4
  %t4 = load ptr, ptr %l2
  %t5 = load i64, ptr %l4
  %t6 = mul i64 %t5, 8
  %t7 = getelementptr i8, ptr %t4, i64 %t6
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l0
  %t9 = load i64, ptr %l0
  ret i64 %t9
}

define internal i64 @"saw Atomic.load() args Int"(ptr %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l2
  %t1 = load ptr, ptr %l2
  %t2 = call i64 @"saw atomic_load_word(a: &Atomic<T>) inst Int"(ptr %t1)
  store i64 %t2, ptr %l3
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3
  store i64 %t3, ptr %l0
  %t4 = load i64, ptr %l0
  ret i64 %t4
}

define internal i8 @"saw Atomic.compare_exchange(expected: Int, desired: Int) args Int"(ptr %p1, i64 %p2, i64 %p3) #0 {
entry:
  %l0 = alloca i8, align 1
  %l1 = alloca ptr, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca ptr, align 8
  %l5 = alloca i8, align 1
  store ptr %p1, ptr %l1
  store i64 %p2, ptr %l2
  store i64 %p3, ptr %l3
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l4
  %t1 = load ptr, ptr %l4
  %t2 = load i64, ptr %l2
  %t3 = load i64, ptr %l3
  %t4 = call i8 @"saw atomic_exchange_word(a: &Atomic<T>, expected: Int, desired: Int) inst Int"(ptr %t1, i64 %t2, i64 %t3)
  store i8 %t4, ptr %l5
  br label %bb1
bb1:
  %t5 = load i8, ptr %l5
  store i8 %t5, ptr %l0
  %t6 = load i8, ptr %l0
  ret i8 %t6
}

define internal i64 @"saw atomic_load_word(a: &Atomic<T>) inst Int"(ptr %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca ptr, align 8
  %l5 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l2
  %t1 = load ptr, ptr %l2
  %t2 = call ptr @"saw UnsafeMutableInterior.ptr() args Int"(ptr %t1)
  store ptr %t2, ptr %l3
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l3
  store ptr %t3, ptr %l4
  %t4 = load ptr, ptr %l4
  %t5 = load atomic i64, ptr %t4 seq_cst, align 8
  store i64 %t5, ptr %l5
  br label %bb2
bb2:
  %t6 = load i64, ptr %l5
  store i64 %t6, ptr %l0
  %t7 = load i64, ptr %l0
  ret i64 %t7
}

define internal i8 @"saw atomic_exchange_word(a: &Atomic<T>, expected: Int, desired: Int) inst Int"(ptr %p1, i64 %p2, i64 %p3) #0 {
entry:
  %l0 = alloca i8, align 1
  %l1 = alloca ptr, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca ptr, align 8
  %l5 = alloca ptr, align 8
  %l6 = alloca ptr, align 8
  %l7 = alloca i8, align 1
  store ptr %p1, ptr %l1
  store i64 %p2, ptr %l2
  store i64 %p3, ptr %l3
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l4
  %t1 = load ptr, ptr %l4
  %t2 = call ptr @"saw UnsafeMutableInterior.ptr() args Int"(ptr %t1)
  store ptr %t2, ptr %l5
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l5
  store ptr %t3, ptr %l6
  %t4 = load ptr, ptr %l6
  %t5 = load i64, ptr %l2
  %t6 = load i64, ptr %l3
  %t7 = cmpxchg ptr %t4, i64 %t5, i64 %t6 seq_cst seq_cst
  %t8 = extractvalue { i64, i1 } %t7, 1
  %t9 = zext i1 %t8 to i8
  store i8 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i8, ptr %l7
  store i8 %t10, ptr %l0
  %t11 = load i8, ptr %l0
  ret i8 %t11
}

define internal ptr @"saw UnsafeMutableInterior.ptr() args Int"(ptr %p1) #0 {
entry:
  %l0 = alloca ptr, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca ptr, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l2
  %t1 = load ptr, ptr %l2
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  store ptr %t2, ptr %l0
  %t3 = load ptr, ptr %l0
  ret ptr %t3
}

define internal i64 @__saw_render_uint(ptr %out, i64 %v) #0 {
entry:
  %tmp = alloca [24 x i8], align 1
  br label %loop
loop:
  %n = phi i64 [ %v, %entry ], [ %q, %loop ]
  %i = phi i64 [ 24, %entry ], [ %i1, %loop ]
  %q = udiv i64 %n, 10
  %r = urem i64 %n, 10
  %d = trunc i64 %r to i8
  %c = add i8 %d, 48
  %i1 = sub i64 %i, 1
  %p = getelementptr i8, ptr %tmp, i64 %i1
  store i8 %c, ptr %p
  %more = icmp ne i64 %q, 0
  br i1 %more, label %loop, label %done
done:
  %len = sub i64 24, %i1
  %src = getelementptr i8, ptr %tmp, i64 %i1
  call void @llvm.memcpy.p0.p0.i64(ptr %out, ptr %src, i64 %len, i1 false)
  ret i64 %len
}

define internal i64 @__saw_render_int(ptr %out, i64 %v) #0 {
entry:
  %neg = icmp slt i64 %v, 0
  br i1 %neg, label %minus, label %plain
minus:
  store i8 45, ptr %out
  %mag = sub i64 0, %v
  %rest = getelementptr i8, ptr %out, i64 1
  %n = call i64 @__saw_render_uint(ptr %rest, i64 %mag)
  %len = add i64 %n, 1
  ret i64 %len
plain:
  %m = call i64 @__saw_render_uint(ptr %out, i64 %v)
  ret i64 %m
}

define internal i64 @__saw_append(ptr %buf, i64 %pos, ptr %src, i64 %len) #0 {
entry:
  %closed = icmp slt i64 %pos, 0
  br i1 %closed, label %keep, label %open
keep:
  ret i64 %pos
open:
  %room = sub i64 508, %pos
  %fits = icmp ule i64 %len, %room
  br i1 %fits, label %whole, label %back
whole:
  %at = getelementptr i8, ptr %buf, i64 %pos
  call void @llvm.memcpy.p0.p0.i64(ptr %at, ptr %src, i64 %len, i1 false)
  %end = add i64 %pos, %len
  ret i64 %end
back:
  %n = phi i64 [ %room, %open ], [ %n1, %step ]
  %none = icmp eq i64 %n, 0
  br i1 %none, label %cut, label %test
test:
  %p = getelementptr i8, ptr %src, i64 %n
  %b = load i8, ptr %p
  %hi = and i8 %b, -64
  %inside = icmp eq i8 %hi, -128
  br i1 %inside, label %step, label %cut
step:
  %n1 = sub i64 %n, 1
  br label %back
cut:
  %at2 = getelementptr i8, ptr %buf, i64 %pos
  call void @llvm.memcpy.p0.p0.i64(ptr %at2, ptr %src, i64 %n, i1 false)
  %stop = add i64 %pos, %n
  %shut = sub i64 -1, %stop
  ret i64 %shut
}

define internal i64 @__saw_finish(ptr %buf, i64 %pos) #0 {
entry:
  %cut = icmp slt i64 %pos, 0
  br i1 %cut, label %mark, label %line
mark:
  %stop = sub i64 -1, %pos
  %m0 = getelementptr i8, ptr %buf, i64 %stop
  store i8 -30, ptr %m0
  %m1 = getelementptr i8, ptr %m0, i64 1
  store i8 -128, ptr %m1
  %m2 = getelementptr i8, ptr %m0, i64 2
  store i8 -90, ptr %m2
  %marked = add i64 %stop, 3
  br label %line
line:
  %end = phi i64 [ %marked, %mark ], [ %pos, %entry ]
  %nl = getelementptr i8, ptr %buf, i64 %end
  store i8 10, ptr %nl
  %total = add i64 %end, 1
  ret i64 %total
}

define internal i64 @__saw_append_int(ptr %buf, i64 %pos, i64 %v) #0 {
entry:
  %tmp = alloca [24 x i8], align 1
  %n = call i64 @__saw_render_int(ptr %tmp, i64 %v)
  %end = call i64 @__saw_append(ptr %buf, i64 %pos, ptr %tmp, i64 %n)
  ret i64 %end
}

define internal i64 @__saw_append_uint(ptr %buf, i64 %pos, i64 %v) #0 {
entry:
  %tmp = alloca [24 x i8], align 1
  %n = call i64 @__saw_render_uint(ptr %tmp, i64 %v)
  %end = call i64 @__saw_append(ptr %buf, i64 %pos, ptr %tmp, i64 %n)
  ret i64 %end
}

@__saw_fail_at = private unnamed_addr constant [9 x i8] c"panic at "
@__saw_fail_colon = private unnamed_addr constant [2 x i8] c": "
@__saw_fail_true = private unnamed_addr constant [4 x i8] c"true"
@__saw_fail_false = private unnamed_addr constant [5 x i8] c"false"
@__saw_fail_overflow.reason = private unnamed_addr constant [16 x i8] c"integer overflow"
@__saw_fail_divide.reason = private unnamed_addr constant [16 x i8] c"division by zero"
@__saw_fail_shift.reason = private unnamed_addr constant [18 x i8] c"shift out of range"
@__saw_fail_unwrap.reason = private unnamed_addr constant [20 x i8] c"force unwrap of None"
@__saw_fail_try.reason = private unnamed_addr constant [11 x i8] c"try! failed"

define internal i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line) #0 {
entry:
  %at = call i64 @__saw_append(ptr %buf, i64 0, ptr @__saw_fail_at, i64 9)
  %named = call i64 @__saw_append(ptr %buf, i64 %at, ptr %file, i64 %file_len)
  %known = icmp sge i64 %line, 0
  br i1 %known, label %number, label %tail
number:
  %colon = call i64 @__saw_append(ptr %buf, i64 %named, ptr @__saw_fail_colon, i64 1)
  %lined = call i64 @__saw_append_uint(ptr %buf, i64 %colon, i64 %line)
  br label %tail
tail:
  %pos = phi i64 [ %named, %entry ], [ %lined, %number ]
  %end = call i64 @__saw_append(ptr %buf, i64 %pos, ptr @__saw_fail_colon, i64 2)
  ret i64 %end
}

define internal void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr %text, i64 %text_len) noinline noreturn #0 {
entry:
  %buf = alloca [512 x i8], align 1
  %head = call i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line)
  %done = call i64 @__saw_append(ptr %buf, i64 %head, ptr %text, i64 %text_len)
  %end = call i64 @__saw_finish(ptr %buf, i64 %done)
  call void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %buf, i64 %end)
  unreachable
}

define internal void @__saw_fail_signed(ptr %file, i64 %file_len, i64 %line, ptr %text, i64 %text_len, i64 %v) noinline noreturn #0 {
entry:
  %buf = alloca [512 x i8], align 1
  %head = call i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line)
  %pos = call i64 @__saw_append(ptr %buf, i64 %head, ptr %text, i64 %text_len)
  %done = call i64 @__saw_append_int(ptr %buf, i64 %pos, i64 %v)
  %end = call i64 @__saw_finish(ptr %buf, i64 %done)
  call void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %buf, i64 %end)
  unreachable
}

define internal void @__saw_fail_unsigned(ptr %file, i64 %file_len, i64 %line, ptr %text, i64 %text_len, i64 %v) noinline noreturn #0 {
entry:
  %buf = alloca [512 x i8], align 1
  %head = call i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line)
  %pos = call i64 @__saw_append(ptr %buf, i64 %head, ptr %text, i64 %text_len)
  %done = call i64 @__saw_append_uint(ptr %buf, i64 %pos, i64 %v)
  %end = call i64 @__saw_finish(ptr %buf, i64 %done)
  call void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %buf, i64 %end)
  unreachable
}

define internal void @__saw_fail_parts(ptr %file, i64 %file_len, i64 %line, ptr %text, i64 %text_len, ptr %parts, i64 %count) noinline noreturn #0 {
entry:
  %buf = alloca [512 x i8], align 1
  %head = call i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line)
  %pos = call i64 @__saw_append(ptr %buf, i64 %head, ptr %text, i64 %text_len)
  br label %loop
loop:
  %i = phi i64 [ 0, %entry ], [ %i1, %next ]
  %at = phi i64 [ %pos, %entry ], [ %after, %next ]
  %more = icmp slt i64 %i, %count
  br i1 %more, label %part, label %last
part:
  %offset = mul i64 %i, 24
  %p = getelementptr i8, ptr %parts, i64 %offset
  %kind = load i64, ptr %p
  %first = getelementptr i8, ptr %p, i64 8
  %second = getelementptr i8, ptr %p, i64 16
  switch i64 %kind, label %run [ i64 1, label %signed i64 2, label %unsigned i64 3, label %bool ]
run:
  %src = load ptr, ptr %first
  %len = load i64, ptr %second
  %ran = call i64 @__saw_append(ptr %buf, i64 %at, ptr %src, i64 %len)
  br label %next
signed:
  %sv = load i64, ptr %first
  %sd = call i64 @__saw_append_int(ptr %buf, i64 %at, i64 %sv)
  br label %next
unsigned:
  %uv = load i64, ptr %first
  %ud = call i64 @__saw_append_uint(ptr %buf, i64 %at, i64 %uv)
  br label %next
bool:
  %byte = load i8, ptr %first
  %yes = icmp ne i8 %byte, 0
  %word = select i1 %yes, ptr @__saw_fail_true, ptr @__saw_fail_false
  %size = select i1 %yes, i64 4, i64 5
  %bd = call i64 @__saw_append(ptr %buf, i64 %at, ptr %word, i64 %size)
  br label %next
next:
  %after = phi i64 [ %ran, %run ], [ %sd, %signed ], [ %ud, %unsigned ], [ %bd, %bool ]
  %i1 = add i64 %i, 1
  br label %loop
last:
  %done = phi i64 [ %at, %loop ]
  %end = call i64 @__saw_finish(ptr %buf, i64 %done)
  call void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %buf, i64 %end)
  unreachable
}

define internal void @__saw_fail_overflow(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_overflow.reason, i64 16)
  unreachable
}

define internal void @__saw_fail_divide(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_divide.reason, i64 16)
  unreachable
}

define internal void @__saw_fail_shift(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_shift.reason, i64 18)
  unreachable
}

define internal void @__saw_fail_unwrap(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_unwrap.reason, i64 20)
  unreachable
}

define internal void @__saw_fail_try(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_try.reason, i64 11)
  unreachable
}

attributes #0 = { "frame-pointer"="non-leaf" }
