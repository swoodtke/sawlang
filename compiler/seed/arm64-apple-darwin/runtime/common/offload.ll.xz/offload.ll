; sawc2 link manifest
; target arm64-apple-darwin
; speed -O2
; runtime none

target triple = "arm64-apple-macosx11.0.0"

@.bytes.0 = private unnamed_addr constant [11 x i8] c"offload.saw"
@.bytes.1 = private unnamed_addr constant [29 x i8] c"cast to UInt64 out of range: "
@"static offload.NANOS_PER_MILLI" = internal global i64 1000000
@"static std.string.LENGTH_SLOT" = internal global i64 -1

declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @malloc(i64)
declare i32 @pipe(ptr)
declare ptr @__saw_offload_thread_ptr()
declare i64 @__saw_rt_thread_spawn(ptr, ptr)
declare void @__saw_rt_thread_join(i64)
declare i32 @close(i32)
declare void @free(ptr)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64)
declare void @__saw_rt_sleep_ns(i64)
declare void @__saw_rt_panic(ptr, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)

define i64 @"__saw_rt_offload_start"(i64 %p1, i64 %p2, i64 %p3) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i64, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca ptr, align 8
  %l5 = alloca i64, align 8
  %l6 = alloca ptr, align 8
  %l7 = alloca ptr, align 8
  %l8 = alloca ptr, align 8
  %l9 = alloca i64, align 8
  %l10 = alloca i64, align 8
  %l11 = alloca i64, align 8
  %l12 = alloca i64, align 8
  %l13 = alloca i64, align 8
  %l14 = alloca ptr, align 8
  %l15 = alloca [8 x i8], align 4
  %l16 = alloca [8 x i8], align 4
  %l17 = alloca ptr, align 8
  %l18 = alloca ptr, align 8
  %l19 = alloca i32, align 4
  %l20 = alloca i64, align 8
  %l21 = alloca i64, align 8
  %l22 = alloca ptr, align 8
  %l23 = alloca ptr, align 8
  %l24 = alloca i64, align 8
  %l25 = alloca i64, align 8
  %l26 = alloca i64, align 8
  store i64 %p1, ptr %l1
  store i64 %p2, ptr %l2
  store i64 %p3, ptr %l3
  br label %bb0
bb0:
  store i64 48, ptr %l5
  br label %bb1
bb1:
  %t0 = load i64, ptr %l5
  %t1 = call ptr @malloc(i64 %t0)
  store ptr %t1, ptr %l6
  br label %bb2
bb2:
  %t2 = load ptr, ptr %l6
  store ptr %t2, ptr %l4
  %t3 = load ptr, ptr %l4
  store ptr %t3, ptr %l8
  %t4 = load ptr, ptr %l8
  store ptr %t4, ptr %l7
  store i64 0, ptr %l9
  %t5 = load ptr, ptr %l7
  %t6 = load i64, ptr %l9
  %t7 = mul i64 %t6, 48
  %t8 = getelementptr i8, ptr %t5, i64 %t7
  %t9 = load i64, ptr %l1
  store i64 %t9, ptr %t8
  store i64 0, ptr %l10
  %t10 = load i64, ptr %l2
  %t11 = load i64, ptr %l3
  %t12 = call i64 @"saw offload.copy_arg_slots(argp: Int, argc: Int)"(i64 %t10, i64 %t11)
  store i64 %t12, ptr %l11
  br label %bb3
bb3:
  %t13 = load ptr, ptr %l7
  %t14 = load i64, ptr %l10
  %t15 = mul i64 %t14, 48
  %t16 = getelementptr i8, ptr %t13, i64 %t15
  %t17 = getelementptr i8, ptr %t16, i64 8
  %t18 = load i64, ptr %l11
  store i64 %t18, ptr %t17
  store i64 0, ptr %l12
  %t19 = load ptr, ptr %l7
  %t20 = load i64, ptr %l12
  %t21 = mul i64 %t20, 48
  %t22 = getelementptr i8, ptr %t19, i64 %t21
  %t23 = getelementptr i8, ptr %t22, i64 16
  store i64 0, ptr %t23
  store i64 0, ptr %l13
  %t24 = load ptr, ptr %l7
  %t25 = load i64, ptr %l13
  %t26 = mul i64 %t25, 48
  %t27 = getelementptr i8, ptr %t24, i64 %t26
  %t28 = getelementptr i8, ptr %t27, i64 24
  store ptr %t28, ptr %l14
  %t29 = load ptr, ptr %l14
  call void @"saw Atomic.store(v: Int) args Int"(ptr %t29, i64 0)
  br label %bb4
bb4:
  store i32 0, ptr %l16
  %t30 = getelementptr i8, ptr %l16, i64 4
  store i32 0, ptr %t30
  call void @llvm.memcpy.p0.p0.i64(ptr %l15, ptr %l16, i64 8, i1 false)
  store ptr %l15, ptr %l17
  %t31 = load ptr, ptr %l17
  store ptr %t31, ptr %l18
  %t32 = load ptr, ptr %l18
  %t33 = call i32 @pipe(ptr %t32)
  store i32 %t33, ptr %l19
  br label %bb5
bb5:
  store i64 0, ptr %l20
  %t34 = load ptr, ptr %l7
  %t35 = load i64, ptr %l20
  %t36 = mul i64 %t35, 48
  %t37 = getelementptr i8, ptr %t34, i64 %t36
  %t38 = getelementptr i8, ptr %t37, i64 32
  %t39 = load i32, ptr %l15
  store i32 %t39, ptr %t38
  store i64 0, ptr %l21
  %t40 = load ptr, ptr %l7
  %t41 = load i64, ptr %l21
  %t42 = mul i64 %t41, 48
  %t43 = getelementptr i8, ptr %t40, i64 %t42
  %t44 = getelementptr i8, ptr %t43, i64 36
  %t45 = getelementptr i8, ptr %l15, i64 4
  %t46 = load i32, ptr %t45
  store i32 %t46, ptr %t44
  %t47 = call ptr @__saw_offload_thread_ptr()
  store ptr %t47, ptr %l23
  br label %bb6
bb6:
  %t48 = load ptr, ptr %l23
  store ptr %t48, ptr %l22
  store i64 0, ptr %l24
  %t49 = load ptr, ptr %l22
  %t50 = load ptr, ptr %l4
  %t51 = call i64 @__saw_rt_thread_spawn(ptr %t49, ptr %t50)
  store i64 %t51, ptr %l25
  br label %bb7
bb7:
  %t52 = load ptr, ptr %l7
  %t53 = load i64, ptr %l24
  %t54 = mul i64 %t53, 48
  %t55 = getelementptr i8, ptr %t52, i64 %t54
  %t56 = getelementptr i8, ptr %t55, i64 40
  %t57 = load i64, ptr %l25
  store i64 %t57, ptr %t56
  %t58 = load ptr, ptr %l4
  %t59 = ptrtoint ptr %t58 to i64
  store i64 %t59, ptr %l26
  %t60 = load i64, ptr %l26
  store i64 %t60, ptr %l0
  %t61 = load i64, ptr %l0
  ret i64 %t61
}

define i64 @"__saw_rt_offload_done"(i64 %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i64, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca i64, align 8
  %l5 = alloca ptr, align 8
  %l6 = alloca i64, align 8
  store i64 %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load i64, ptr %l1
  %t1 = inttoptr i64 %t0 to ptr
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  store ptr %t2, ptr %l2
  store i64 0, ptr %l4
  %t3 = load ptr, ptr %l2
  %t4 = load i64, ptr %l4
  %t5 = mul i64 %t4, 48
  %t6 = getelementptr i8, ptr %t3, i64 %t5
  %t7 = getelementptr i8, ptr %t6, i64 24
  store ptr %t7, ptr %l5
  %t8 = load ptr, ptr %l5
  %t9 = call i64 @"saw Atomic.load() args Int"(ptr %t8)
  store i64 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i64, ptr %l6
  store i64 %t10, ptr %l0
  %t11 = load i64, ptr %l0
  ret i64 %t11
}

define i64 @"__saw_rt_offload_pipe_fd"(i64 %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i64, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca i64, align 8
  %l5 = alloca i64, align 8
  store i64 %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load i64, ptr %l1
  %t1 = inttoptr i64 %t0 to ptr
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  store ptr %t2, ptr %l2
  store i64 0, ptr %l4
  %t3 = load ptr, ptr %l2
  %t4 = load i64, ptr %l4
  %t5 = mul i64 %t4, 48
  %t6 = getelementptr i8, ptr %t3, i64 %t5
  %t7 = getelementptr i8, ptr %t6, i64 32
  %t8 = load i32, ptr %t7
  %t9 = sext i32 %t8 to i64
  %t10 = trunc i64 %t9 to i32
  %t11 = icmp eq i32 %t10, %t8
  %t12 = sext i32 %t8 to i64
  store i64 %t12, ptr %l5
  %t13 = load i64, ptr %l5
  store i64 %t13, ptr %l0
  %t14 = load i64, ptr %l0
  ret i64 %t14
}

define i64 @"__saw_rt_offload_take"(i64 %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i64, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca ptr, align 8
  %l5 = alloca ptr, align 8
  %l6 = alloca i64, align 8
  %l7 = alloca i64, align 8
  %l8 = alloca i64, align 8
  %l9 = alloca i64, align 8
  %l10 = alloca i32, align 4
  %l11 = alloca i64, align 8
  %l12 = alloca i32, align 4
  %l13 = alloca i64, align 8
  %l14 = alloca i8, align 1
  %l15 = alloca i64, align 8
  %l16 = alloca ptr, align 8
  store i64 %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load i64, ptr %l1
  %t1 = inttoptr i64 %t0 to ptr
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  store ptr %t2, ptr %l2
  %t3 = load i64, ptr %l1
  %t4 = inttoptr i64 %t3 to ptr
  store ptr %t4, ptr %l5
  %t5 = load ptr, ptr %l5
  store ptr %t5, ptr %l4
  store i64 0, ptr %l6
  %t6 = load ptr, ptr %l4
  %t7 = load i64, ptr %l6
  %t8 = mul i64 %t7, 48
  %t9 = getelementptr i8, ptr %t6, i64 %t8
  %t10 = getelementptr i8, ptr %t9, i64 40
  %t11 = load i64, ptr %t10
  call void @__saw_rt_thread_join(i64 %t11)
  br label %bb1
bb1:
  store i64 0, ptr %l8
  %t12 = load ptr, ptr %l4
  %t13 = load i64, ptr %l8
  %t14 = mul i64 %t13, 48
  %t15 = getelementptr i8, ptr %t12, i64 %t14
  %t16 = getelementptr i8, ptr %t15, i64 16
  %t17 = load i64, ptr %t16
  store i64 %t17, ptr %l7
  store i64 0, ptr %l9
  %t18 = load ptr, ptr %l4
  %t19 = load i64, ptr %l9
  %t20 = mul i64 %t19, 48
  %t21 = getelementptr i8, ptr %t18, i64 %t20
  %t22 = getelementptr i8, ptr %t21, i64 32
  %t23 = load i32, ptr %t22
  %t24 = call i32 @close(i32 %t23)
  store i32 %t24, ptr %l10
  br label %bb2
bb2:
  store i64 0, ptr %l11
  %t25 = load ptr, ptr %l4
  %t26 = load i64, ptr %l11
  %t27 = mul i64 %t26, 48
  %t28 = getelementptr i8, ptr %t25, i64 %t27
  %t29 = getelementptr i8, ptr %t28, i64 36
  %t30 = load i32, ptr %t29
  %t31 = call i32 @close(i32 %t30)
  store i32 %t31, ptr %l12
  br label %bb3
bb3:
  store i64 0, ptr %l13
  %t32 = load ptr, ptr %l4
  %t33 = load i64, ptr %l13
  %t34 = mul i64 %t33, 48
  %t35 = getelementptr i8, ptr %t32, i64 %t34
  %t36 = getelementptr i8, ptr %t35, i64 8
  %t37 = load i64, ptr %t36
  %t38 = icmp ne i64 %t37, 0
  %t39 = zext i1 %t38 to i8
  store i8 %t39, ptr %l14
  %t40 = load i8, ptr %l14
  %t41 = icmp ne i8 %t40, 0
  br i1 %t41, label %bb5, label %bb6
bb4:
  %t42 = load ptr, ptr %l2
  call void @free(ptr %t42)
  br label %bb8
bb5:
  store i64 0, ptr %l15
  %t43 = load ptr, ptr %l4
  %t44 = load i64, ptr %l15
  %t45 = mul i64 %t44, 48
  %t46 = getelementptr i8, ptr %t43, i64 %t45
  %t47 = getelementptr i8, ptr %t46, i64 8
  %t48 = load i64, ptr %t47
  %t49 = inttoptr i64 %t48 to ptr
  store ptr %t49, ptr %l16
  %t50 = load ptr, ptr %l16
  call void @free(ptr %t50)
  br label %bb7
bb6:
  br label %bb4
bb7:
  br label %bb4
bb8:
  %t51 = load i64, ptr %l7
  store i64 %t51, ptr %l0
  %t52 = load i64, ptr %l0
  ret i64 %t52
}

define i64 @"__saw_rt_blocking_sleep"(i64 %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i64, align 8
  %l2 = alloca i8, align 1
  %l3 = alloca i64, align 8
  %l4 = alloca i64, align 8
  store i64 %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load i64, ptr %l1
  %t1 = icmp sgt i64 %t0, 0
  %t2 = zext i1 %t1 to i8
  store i8 %t2, ptr %l2
  %t3 = load i8, ptr %l2
  %t4 = icmp ne i8 %t3, 0
  br i1 %t4, label %bb2, label %bb3
bb1:
  %t5 = load i64, ptr %l1
  store i64 %t5, ptr %l0
  %t6 = load i64, ptr %l0
  ret i64 %t6
bb2:
  %t7 = load i64, ptr %l1
  %t8 = icmp eq i64 %t7, %t7
  %t9 = icmp sge i64 %t7, 0
  %t10 = and i1 %t8, %t9
  %t11 = xor i1 %t10, 1
  br i1 %t11, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 11, i64 134, ptr @.bytes.1, i64 29, i64 %t7)
  unreachable
casted.1:
  store i64 %t7, ptr %l3
  %t12 = load i64, ptr %l3
  %t13 = load i64, ptr @"static offload.NANOS_PER_MILLI"
  %t14 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %t12, i64 %t13)
  %t15 = extractvalue { i64, i1 } %t14, 0
  %t16 = extractvalue { i64, i1 } %t14, 1
  br i1 %t16, label %check.2, label %checked.3
check.2:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 11, i64 134)
  unreachable
checked.3:
  store i64 %t15, ptr %l4
  %t17 = load i64, ptr %l4
  call void @__saw_rt_sleep_ns(i64 %t17)
  br label %bb4
bb3:
  br label %bb1
bb4:
  br label %bb1
}

define internal void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %p1, i64 %p2) #0 {
entry:
  %l0 = alloca [0 x i8], align 1
  %l1 = alloca ptr, align 8
  %l2 = alloca i64, align 8
  store ptr %p1, ptr %l1
  store i64 %p2, ptr %l2
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = load i64, ptr %l2
  call void @__saw_rt_panic(ptr %t0, i64 %t1)
  unreachable
}

define internal void @"saw std.string.string_literal(bytes: UnsafePointer<Int8>)"(ptr %ret, ptr %p1) #0 {
entry:
  %l0 = alloca [8 x i8], align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca [8 x i8], align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l2
  call void @llvm.memcpy.p0.p0.i64(ptr %l0, ptr %l2, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %ret, ptr %l0, i64 8, i1 false)
  ret void
}

define internal ptr @"saw std.string.string_bytes(text: &String)"(ptr noalias %p1) #0 {
entry:
  %l0 = alloca ptr, align 8
  %l1 = alloca ptr, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = load ptr, ptr %t0
  store ptr %t1, ptr %l0
  %t2 = load ptr, ptr %l0
  ret ptr %t2
}

define internal i64 @"saw std.string.string_length(text: &String)"(ptr noalias %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l2
  %t1 = load ptr, ptr %l2
  %t2 = call i64 @"saw std.string.String.len()"(ptr %t1)
  store i64 %t2, ptr %l3
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3
  store i64 %t3, ptr %l0
  %t4 = load i64, ptr %l0
  ret i64 %t4
}

define internal i64 @"saw offload.copy_arg_slots(argp: Int, argc: Int)"(i64 %p1, i64 %p2) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i64, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca i8, align 1
  %l4 = alloca ptr, align 8
  %l5 = alloca ptr, align 8
  %l6 = alloca ptr, align 8
  %l7 = alloca i64, align 8
  %l8 = alloca i64, align 8
  %l9 = alloca i64, align 8
  %l10 = alloca ptr, align 8
  %l11 = alloca ptr, align 8
  %l12 = alloca i64, align 8
  %l13 = alloca i8, align 1
  %l14 = alloca i64, align 8
  %l15 = alloca i64, align 8
  %l16 = alloca i64, align 8
  %l17 = alloca i64, align 8
  store i64 %p1, ptr %l1
  store i64 %p2, ptr %l2
  br label %bb0
bb0:
  %t0 = load i64, ptr %l2
  %t1 = icmp sle i64 %t0, 0
  %t2 = zext i1 %t1 to i8
  store i8 %t2, ptr %l3
  %t3 = load i8, ptr %l3
  %t4 = icmp ne i8 %t3, 0
  br i1 %t4, label %bb2, label %bb3
bb1:
  %t5 = load i64, ptr %l1
  %t6 = inttoptr i64 %t5 to ptr
  store ptr %t6, ptr %l5
  %t7 = load ptr, ptr %l5
  store ptr %t7, ptr %l4
  %t8 = load i64, ptr %l2
  store i64 %t8, ptr %l7
  store i64 8, ptr %l8
  br label %bb4
bb2:
  store i64 0, ptr %l0
  %t9 = load i64, ptr %l0
  ret i64 %t9
bb3:
  br label %bb1
bb4:
  %t10 = load i64, ptr %l7
  %t11 = load i64, ptr %l8
  %t12 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %t10, i64 %t11)
  %t13 = extractvalue { i64, i1 } %t12, 0
  %t14 = extractvalue { i64, i1 } %t12, 1
  br i1 %t14, label %check.0, label %checked.1
check.0:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 11, i64 70)
  unreachable
checked.1:
  store i64 %t13, ptr %l9
  %t15 = load i64, ptr %l9
  %t16 = call ptr @malloc(i64 %t15)
  store ptr %t16, ptr %l10
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l10
  store ptr %t17, ptr %l11
  %t18 = load ptr, ptr %l11
  store ptr %t18, ptr %l6
  store i64 0, ptr %l12
  br label %bb6
bb6:
  %t19 = load i64, ptr %l12
  %t20 = load i64, ptr %l2
  %t21 = icmp slt i64 %t19, %t20
  %t22 = zext i1 %t21 to i8
  store i8 %t22, ptr %l13
  %t23 = load i8, ptr %l13
  %t24 = icmp ne i8 %t23, 0
  br i1 %t24, label %bb8, label %bb7
bb7:
  %t25 = load ptr, ptr %l6
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l17
  %t27 = load i64, ptr %l17
  store i64 %t27, ptr %l0
  %t28 = load i64, ptr %l0
  ret i64 %t28
bb8:
  %t29 = load i64, ptr %l12
  store i64 %t29, ptr %l14
  %t30 = load i64, ptr %l12
  store i64 %t30, ptr %l15
  %t31 = load ptr, ptr %l6
  %t32 = load i64, ptr %l14
  %t33 = mul i64 %t32, 8
  %t34 = getelementptr i8, ptr %t31, i64 %t33
  %t35 = load ptr, ptr %l4
  %t36 = load i64, ptr %l15
  %t37 = mul i64 %t36, 8
  %t38 = getelementptr i8, ptr %t35, i64 %t37
  %t39 = load i64, ptr %t38
  store i64 %t39, ptr %t34
  %t40 = load i64, ptr %l12
  %t41 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %t40, i64 1)
  %t42 = extractvalue { i64, i1 } %t41, 0
  %t43 = extractvalue { i64, i1 } %t41, 1
  br i1 %t43, label %check.2, label %checked.3
check.2:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 11, i64 74)
  unreachable
checked.3:
  store i64 %t42, ptr %l16
  %t44 = load i64, ptr %l16
  store i64 %t44, ptr %l12
  br label %bb6
}

define internal void @"saw Atomic.store(v: Int) args Int"(ptr %p1, i64 %p2) #0 {
entry:
  %l0 = alloca [0 x i8], align 1
  %l1 = alloca ptr, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca ptr, align 8
  store ptr %p1, ptr %l1
  store i64 %p2, ptr %l2
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l3
  %t1 = load ptr, ptr %l3
  %t2 = load i64, ptr %l2
  call void @"saw atomic_store_word(a: &Atomic<T>, v: Int) inst Int"(ptr %t1, i64 %t2)
  br label %bb1
bb1:
  ret void
}

define internal i64 @"saw Atomic.load() args Int"(ptr %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l2
  %t1 = load ptr, ptr %l2
  %t2 = call i64 @"saw atomic_load_word(a: &Atomic<T>) inst Int"(ptr %t1)
  store i64 %t2, ptr %l3
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3
  store i64 %t3, ptr %l0
  %t4 = load i64, ptr %l0
  ret i64 %t4
}

define internal i64 @"saw std.string.String.len()"(ptr noalias %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = load ptr, ptr %t0
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  store ptr %t2, ptr %l2
  %t3 = load i64, ptr @"static std.string.LENGTH_SLOT"
  store i64 %t3, ptr %l4
  %t4 = load ptr, ptr %l2
  %t5 = load i64, ptr %l4
  %t6 = mul i64 %t5, 8
  %t7 = getelementptr i8, ptr %t4, i64 %t6
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l0
  %t9 = load i64, ptr %l0
  ret i64 %t9
}

define internal void @"saw atomic_store_word(a: &Atomic<T>, v: Int) inst Int"(ptr %p1, i64 %p2) #0 {
entry:
  %l0 = alloca [0 x i8], align 1
  %l1 = alloca ptr, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca ptr, align 8
  %l5 = alloca ptr, align 8
  store ptr %p1, ptr %l1
  store i64 %p2, ptr %l2
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l3
  %t1 = load ptr, ptr %l3
  %t2 = call ptr @"saw UnsafeMutableInterior.ptr() args Int"(ptr %t1)
  store ptr %t2, ptr %l4
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l4
  store ptr %t3, ptr %l5
  %t4 = load ptr, ptr %l5
  %t5 = load i64, ptr %l2
  store atomic i64 %t5, ptr %t4 seq_cst, align 8
  br label %bb2
bb2:
  ret void
}

define internal i64 @"saw atomic_load_word(a: &Atomic<T>) inst Int"(ptr %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca ptr, align 8
  %l5 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l2
  %t1 = load ptr, ptr %l2
  %t2 = call ptr @"saw UnsafeMutableInterior.ptr() args Int"(ptr %t1)
  store ptr %t2, ptr %l3
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l3
  store ptr %t3, ptr %l4
  %t4 = load ptr, ptr %l4
  %t5 = load atomic i64, ptr %t4 seq_cst, align 8
  store i64 %t5, ptr %l5
  br label %bb2
bb2:
  %t6 = load i64, ptr %l5
  store i64 %t6, ptr %l0
  %t7 = load i64, ptr %l0
  ret i64 %t7
}

define internal ptr @"saw UnsafeMutableInterior.ptr() args Int"(ptr %p1) #0 {
entry:
  %l0 = alloca ptr, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca ptr, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l2
  %t1 = load ptr, ptr %l2
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  store ptr %t2, ptr %l0
  %t3 = load ptr, ptr %l0
  ret ptr %t3
}

define internal i64 @__saw_render_uint(ptr %out, i64 %v) #0 {
entry:
  %tmp = alloca [24 x i8], align 1
  br label %loop
loop:
  %n = phi i64 [ %v, %entry ], [ %q, %loop ]
  %i = phi i64 [ 24, %entry ], [ %i1, %loop ]
  %q = udiv i64 %n, 10
  %r = urem i64 %n, 10
  %d = trunc i64 %r to i8
  %c = add i8 %d, 48
  %i1 = sub i64 %i, 1
  %p = getelementptr i8, ptr %tmp, i64 %i1
  store i8 %c, ptr %p
  %more = icmp ne i64 %q, 0
  br i1 %more, label %loop, label %done
done:
  %len = sub i64 24, %i1
  %src = getelementptr i8, ptr %tmp, i64 %i1
  call void @llvm.memcpy.p0.p0.i64(ptr %out, ptr %src, i64 %len, i1 false)
  ret i64 %len
}

define internal i64 @__saw_render_int(ptr %out, i64 %v) #0 {
entry:
  %neg = icmp slt i64 %v, 0
  br i1 %neg, label %minus, label %plain
minus:
  store i8 45, ptr %out
  %mag = sub i64 0, %v
  %rest = getelementptr i8, ptr %out, i64 1
  %n = call i64 @__saw_render_uint(ptr %rest, i64 %mag)
  %len = add i64 %n, 1
  ret i64 %len
plain:
  %m = call i64 @__saw_render_uint(ptr %out, i64 %v)
  ret i64 %m
}

define internal i64 @__saw_append(ptr %buf, i64 %pos, ptr %src, i64 %len) #0 {
entry:
  %closed = icmp slt i64 %pos, 0
  br i1 %closed, label %keep, label %open
keep:
  ret i64 %pos
open:
  %room = sub i64 508, %pos
  %fits = icmp ule i64 %len, %room
  br i1 %fits, label %whole, label %back
whole:
  %at = getelementptr i8, ptr %buf, i64 %pos
  call void @llvm.memcpy.p0.p0.i64(ptr %at, ptr %src, i64 %len, i1 false)
  %end = add i64 %pos, %len
  ret i64 %end
back:
  %n = phi i64 [ %room, %open ], [ %n1, %step ]
  %none = icmp eq i64 %n, 0
  br i1 %none, label %cut, label %test
test:
  %p = getelementptr i8, ptr %src, i64 %n
  %b = load i8, ptr %p
  %hi = and i8 %b, -64
  %inside = icmp eq i8 %hi, -128
  br i1 %inside, label %step, label %cut
step:
  %n1 = sub i64 %n, 1
  br label %back
cut:
  %at2 = getelementptr i8, ptr %buf, i64 %pos
  call void @llvm.memcpy.p0.p0.i64(ptr %at2, ptr %src, i64 %n, i1 false)
  %stop = add i64 %pos, %n
  %shut = sub i64 -1, %stop
  ret i64 %shut
}

define internal i64 @__saw_finish(ptr %buf, i64 %pos) #0 {
entry:
  %cut = icmp slt i64 %pos, 0
  br i1 %cut, label %mark, label %line
mark:
  %stop = sub i64 -1, %pos
  %m0 = getelementptr i8, ptr %buf, i64 %stop
  store i8 -30, ptr %m0
  %m1 = getelementptr i8, ptr %m0, i64 1
  store i8 -128, ptr %m1
  %m2 = getelementptr i8, ptr %m0, i64 2
  store i8 -90, ptr %m2
  %marked = add i64 %stop, 3
  br label %line
line:
  %end = phi i64 [ %marked, %mark ], [ %pos, %entry ]
  %nl = getelementptr i8, ptr %buf, i64 %end
  store i8 10, ptr %nl
  %total = add i64 %end, 1
  ret i64 %total
}

define internal i64 @__saw_append_int(ptr %buf, i64 %pos, i64 %v) #0 {
entry:
  %tmp = alloca [24 x i8], align 1
  %n = call i64 @__saw_render_int(ptr %tmp, i64 %v)
  %end = call i64 @__saw_append(ptr %buf, i64 %pos, ptr %tmp, i64 %n)
  ret i64 %end
}

define internal i64 @__saw_append_uint(ptr %buf, i64 %pos, i64 %v) #0 {
entry:
  %tmp = alloca [24 x i8], align 1
  %n = call i64 @__saw_render_uint(ptr %tmp, i64 %v)
  %end = call i64 @__saw_append(ptr %buf, i64 %pos, ptr %tmp, i64 %n)
  ret i64 %end
}

@__saw_fail_at = private unnamed_addr constant [9 x i8] c"panic at "
@__saw_fail_colon = private unnamed_addr constant [2 x i8] c": "
@__saw_fail_true = private unnamed_addr constant [4 x i8] c"true"
@__saw_fail_false = private unnamed_addr constant [5 x i8] c"false"
@__saw_fail_overflow.reason = private unnamed_addr constant [16 x i8] c"integer overflow"
@__saw_fail_divide.reason = private unnamed_addr constant [16 x i8] c"division by zero"
@__saw_fail_shift.reason = private unnamed_addr constant [18 x i8] c"shift out of range"
@__saw_fail_unwrap.reason = private unnamed_addr constant [20 x i8] c"force unwrap of None"
@__saw_fail_try.reason = private unnamed_addr constant [11 x i8] c"try! failed"

define internal i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line) #0 {
entry:
  %at = call i64 @__saw_append(ptr %buf, i64 0, ptr @__saw_fail_at, i64 9)
  %named = call i64 @__saw_append(ptr %buf, i64 %at, ptr %file, i64 %file_len)
  %known = icmp sge i64 %line, 0
  br i1 %known, label %number, label %tail
number:
  %colon = call i64 @__saw_append(ptr %buf, i64 %named, ptr @__saw_fail_colon, i64 1)
  %lined = call i64 @__saw_append_uint(ptr %buf, i64 %colon, i64 %line)
  br label %tail
tail:
  %pos = phi i64 [ %named, %entry ], [ %lined, %number ]
  %end = call i64 @__saw_append(ptr %buf, i64 %pos, ptr @__saw_fail_colon, i64 2)
  ret i64 %end
}

define internal void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr %text, i64 %text_len) noinline noreturn #0 {
entry:
  %buf = alloca [512 x i8], align 1
  %head = call i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line)
  %done = call i64 @__saw_append(ptr %buf, i64 %head, ptr %text, i64 %text_len)
  %end = call i64 @__saw_finish(ptr %buf, i64 %done)
  call void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %buf, i64 %end)
  unreachable
}

define internal void @__saw_fail_signed(ptr %file, i64 %file_len, i64 %line, ptr %text, i64 %text_len, i64 %v) noinline noreturn #0 {
entry:
  %buf = alloca [512 x i8], align 1
  %head = call i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line)
  %pos = call i64 @__saw_append(ptr %buf, i64 %head, ptr %text, i64 %text_len)
  %done = call i64 @__saw_append_int(ptr %buf, i64 %pos, i64 %v)
  %end = call i64 @__saw_finish(ptr %buf, i64 %done)
  call void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %buf, i64 %end)
  unreachable
}

define internal void @__saw_fail_unsigned(ptr %file, i64 %file_len, i64 %line, ptr %text, i64 %text_len, i64 %v) noinline noreturn #0 {
entry:
  %buf = alloca [512 x i8], align 1
  %head = call i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line)
  %pos = call i64 @__saw_append(ptr %buf, i64 %head, ptr %text, i64 %text_len)
  %done = call i64 @__saw_append_uint(ptr %buf, i64 %pos, i64 %v)
  %end = call i64 @__saw_finish(ptr %buf, i64 %done)
  call void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %buf, i64 %end)
  unreachable
}

define internal void @__saw_fail_parts(ptr %file, i64 %file_len, i64 %line, ptr %text, i64 %text_len, ptr %parts, i64 %count) noinline noreturn #0 {
entry:
  %buf = alloca [512 x i8], align 1
  %head = call i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line)
  %pos = call i64 @__saw_append(ptr %buf, i64 %head, ptr %text, i64 %text_len)
  br label %loop
loop:
  %i = phi i64 [ 0, %entry ], [ %i1, %next ]
  %at = phi i64 [ %pos, %entry ], [ %after, %next ]
  %more = icmp slt i64 %i, %count
  br i1 %more, label %part, label %last
part:
  %offset = mul i64 %i, 24
  %p = getelementptr i8, ptr %parts, i64 %offset
  %kind = load i64, ptr %p
  %first = getelementptr i8, ptr %p, i64 8
  %second = getelementptr i8, ptr %p, i64 16
  switch i64 %kind, label %run [ i64 1, label %signed i64 2, label %unsigned i64 3, label %bool ]
run:
  %src = load ptr, ptr %first
  %len = load i64, ptr %second
  %ran = call i64 @__saw_append(ptr %buf, i64 %at, ptr %src, i64 %len)
  br label %next
signed:
  %sv = load i64, ptr %first
  %sd = call i64 @__saw_append_int(ptr %buf, i64 %at, i64 %sv)
  br label %next
unsigned:
  %uv = load i64, ptr %first
  %ud = call i64 @__saw_append_uint(ptr %buf, i64 %at, i64 %uv)
  br label %next
bool:
  %byte = load i8, ptr %first
  %yes = icmp ne i8 %byte, 0
  %word = select i1 %yes, ptr @__saw_fail_true, ptr @__saw_fail_false
  %size = select i1 %yes, i64 4, i64 5
  %bd = call i64 @__saw_append(ptr %buf, i64 %at, ptr %word, i64 %size)
  br label %next
next:
  %after = phi i64 [ %ran, %run ], [ %sd, %signed ], [ %ud, %unsigned ], [ %bd, %bool ]
  %i1 = add i64 %i, 1
  br label %loop
last:
  %done = phi i64 [ %at, %loop ]
  %end = call i64 @__saw_finish(ptr %buf, i64 %done)
  call void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %buf, i64 %end)
  unreachable
}

define internal void @__saw_fail_overflow(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_overflow.reason, i64 16)
  unreachable
}

define internal void @__saw_fail_divide(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_divide.reason, i64 16)
  unreachable
}

define internal void @__saw_fail_shift(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_shift.reason, i64 18)
  unreachable
}

define internal void @__saw_fail_unwrap(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_unwrap.reason, i64 20)
  unreachable
}

define internal void @__saw_fail_try(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_try.reason, i64 11)
  unreachable
}

attributes #0 = { "frame-pointer"="non-leaf" }
