; sawc2 link manifest
; target arm64-apple-darwin
; speed -O2
; runtime none

target triple = "arm64-apple-macosx11.0.0"

@.bytes.0 = private unnamed_addr constant [9 x i8] c"sleep.saw"
@.bytes.1 = private unnamed_addr constant [29 x i8] c"cast to UInt64 out of range: "
@"static sleep.CHUNK_NANOS" = internal global i64 1000000000
@"static sleep.NANOS_PER_MICRO" = internal global i64 1000
@.bytes.2 = private unnamed_addr constant [29 x i8] c"cast to UInt32 out of range: "
@"static std.string.LENGTH_SLOT" = internal global i64 -1

declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare i64 @__saw_rt_clock_monotonic_nanos()
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.usub.with.overflow.i64(i64, i64)
declare i32 @usleep(i32)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare void @__saw_rt_panic(ptr, i64)

define void @"__saw_rt_sleep_ns"(i64 %p1) #0 {
entry:
  %l0 = alloca [0 x i8], align 1
  %l1 = alloca i64, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca i64, align 8
  %l5 = alloca i8, align 1
  %l6 = alloca i64, align 8
  %l7 = alloca i8, align 1
  %l8 = alloca i64, align 8
  %l9 = alloca i64, align 8
  %l10 = alloca i64, align 8
  %l11 = alloca i64, align 8
  %l12 = alloca i64, align 8
  %l13 = alloca i64, align 8
  %l14 = alloca i32, align 4
  %l15 = alloca i32, align 4
  %l16 = alloca i64, align 8
  %l17 = alloca i64, align 8
  %l18 = alloca i64, align 8
  %l19 = alloca i64, align 8
  %l20 = alloca i64, align 8
  %l21 = alloca i64, align 8
  %l22 = alloca i8, align 1
  %l23 = alloca i64, align 8
  %l24 = alloca i8, align 1
  %l25 = alloca i64, align 8
  store i64 %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load i64, ptr %l1
  store i64 %t0, ptr %l2
  br label %bb1
bb1:
  %t1 = load i64, ptr %l2
  store i64 %t1, ptr %l3
  %t2 = icmp eq i64 0, 0
  %t3 = icmp sge i64 0, 0
  %t4 = and i1 %t2, %t3
  %t5 = xor i1 %t4, 1
  br i1 %t5, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 9, i64 41, ptr @.bytes.1, i64 29, i64 0)
  unreachable
casted.1:
  store i64 0, ptr %l4
  %t6 = load i64, ptr %l3
  %t7 = load i64, ptr %l4
  %t8 = icmp ugt i64 %t6, %t7
  %t9 = zext i1 %t8 to i8
  store i8 %t9, ptr %l5
  %t10 = load i8, ptr %l5
  %t11 = icmp ne i8 %t10, 0
  br i1 %t11, label %bb3, label %bb2
bb2:
  ret void
bb3:
  %t12 = load i64, ptr @"static sleep.CHUNK_NANOS"
  store i64 %t12, ptr %l6
  %t13 = load i64, ptr %l2
  %t14 = load i64, ptr %l6
  %t15 = icmp ult i64 %t13, %t14
  %t16 = zext i1 %t15 to i8
  store i8 %t16, ptr %l7
  %t17 = load i8, ptr %l7
  %t18 = icmp ne i8 %t17, 0
  br i1 %t18, label %bb5, label %bb6
bb4:
  %t19 = call i64 @__saw_rt_clock_monotonic_nanos()
  store i64 %t19, ptr %l9
  br label %bb7
bb5:
  %t20 = load i64, ptr %l2
  store i64 %t20, ptr %l6
  br label %bb4
bb6:
  br label %bb4
bb7:
  %t21 = load i64, ptr %l9
  store i64 %t21, ptr %l8
  %t22 = load i64, ptr %l6
  %t23 = load i64, ptr @"static sleep.NANOS_PER_MICRO"
  %t24 = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %t22, i64 %t23)
  %t25 = extractvalue { i64, i1 } %t24, 0
  %t26 = extractvalue { i64, i1 } %t24, 1
  br i1 %t26, label %check.2, label %checked.3
check.2:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 9, i64 47)
  unreachable
checked.3:
  store i64 %t25, ptr %l10
  %t27 = icmp eq i64 1, 1
  %t28 = icmp sge i64 1, 0
  %t29 = and i1 %t27, %t28
  %t30 = xor i1 %t29, 1
  br i1 %t30, label %cast.4, label %casted.5
cast.4:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 9, i64 47, ptr @.bytes.1, i64 29, i64 1)
  unreachable
casted.5:
  store i64 1, ptr %l11
  %t31 = load i64, ptr %l10
  %t32 = load i64, ptr %l11
  %t33 = call { i64, i1 } @llvm.usub.with.overflow.i64(i64 %t31, i64 %t32)
  %t34 = extractvalue { i64, i1 } %t33, 0
  %t35 = extractvalue { i64, i1 } %t33, 1
  br i1 %t35, label %check.6, label %checked.7
check.6:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 9, i64 47)
  unreachable
checked.7:
  store i64 %t34, ptr %l12
  %t36 = load i64, ptr %l12
  %t37 = load i64, ptr @"static sleep.NANOS_PER_MICRO"
  %t38 = icmp eq i64 %t37, 0
  br i1 %t38, label %check.8, label %checked.9
check.8:
  call void @__saw_fail_divide(ptr @.bytes.0, i64 9, i64 47)
  unreachable
checked.9:
  %t39 = udiv i64 %t36, %t37
  store i64 %t39, ptr %l13
  %t40 = load i64, ptr %l13
  %t41 = trunc i64 %t40 to i32
  %t42 = zext i32 %t41 to i64
  %t43 = icmp eq i64 %t42, %t40
  %t44 = trunc i64 %t40 to i32
  %t45 = xor i1 %t43, 1
  br i1 %t45, label %cast.10, label %casted.11
cast.10:
  call void @__saw_fail_unsigned(ptr @.bytes.0, i64 9, i64 47, ptr @.bytes.2, i64 29, i64 %t40)
  unreachable
casted.11:
  store i32 %t44, ptr %l14
  %t46 = load i32, ptr %l14
  %t47 = call i32 @usleep(i32 %t46)
  store i32 %t47, ptr %l15
  br label %bb8
bb8:
  %t48 = call i64 @__saw_rt_clock_monotonic_nanos()
  store i64 %t48, ptr %l17
  br label %bb9
bb9:
  %t49 = load i64, ptr %l17
  %t50 = load i64, ptr %l8
  %t51 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %t49, i64 %t50)
  %t52 = extractvalue { i64, i1 } %t51, 0
  %t53 = extractvalue { i64, i1 } %t51, 1
  br i1 %t53, label %check.12, label %checked.13
check.12:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 9, i64 48)
  unreachable
checked.13:
  store i64 %t52, ptr %l18
  %t54 = load i64, ptr %l18
  store i64 %t54, ptr %l16
  %t55 = load i64, ptr %l6
  store i64 %t55, ptr %l19
  %t56 = load i64, ptr %l16
  store i64 %t56, ptr %l20
  %t57 = icmp eq i64 0, 0
  store i64 0, ptr %l21
  %t58 = load i64, ptr %l20
  %t59 = load i64, ptr %l21
  %t60 = icmp sgt i64 %t58, %t59
  %t61 = zext i1 %t60 to i8
  store i8 %t61, ptr %l22
  %t62 = load i8, ptr %l22
  %t63 = icmp ne i8 %t62, 0
  br i1 %t63, label %bb11, label %bb12
bb10:
  %t64 = load i64, ptr %l19
  %t65 = load i64, ptr %l2
  %t66 = icmp uge i64 %t64, %t65
  %t67 = zext i1 %t66 to i8
  store i8 %t67, ptr %l24
  %t68 = load i8, ptr %l24
  %t69 = icmp ne i8 %t68, 0
  br i1 %t69, label %bb14, label %bb15
bb11:
  %t70 = load i64, ptr %l16
  %t71 = icmp eq i64 %t70, %t70
  %t72 = icmp sge i64 %t70, 0
  %t73 = and i1 %t71, %t72
  %t74 = xor i1 %t73, 1
  br i1 %t74, label %cast.14, label %casted.15
cast.14:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 9, i64 54, ptr @.bytes.1, i64 29, i64 %t70)
  unreachable
casted.15:
  store i64 %t70, ptr %l23
  %t75 = load i64, ptr %l23
  store i64 %t75, ptr %l19
  br label %bb10
bb12:
  br label %bb10
bb13:
  %t76 = load i64, ptr %l2
  %t77 = load i64, ptr %l19
  %t78 = call { i64, i1 } @llvm.usub.with.overflow.i64(i64 %t76, i64 %t77)
  %t79 = extractvalue { i64, i1 } %t78, 0
  %t80 = extractvalue { i64, i1 } %t78, 1
  br i1 %t80, label %check.16, label %checked.17
check.16:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 9, i64 59)
  unreachable
checked.17:
  store i64 %t79, ptr %l25
  %t81 = load i64, ptr %l25
  store i64 %t81, ptr %l2
  br label %bb1
bb14:
  ret void
bb15:
  br label %bb13
}

define internal void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %p1, i64 %p2) #0 {
entry:
  %l0 = alloca [0 x i8], align 1
  %l1 = alloca ptr, align 8
  %l2 = alloca i64, align 8
  store ptr %p1, ptr %l1
  store i64 %p2, ptr %l2
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = load i64, ptr %l2
  call void @__saw_rt_panic(ptr %t0, i64 %t1)
  unreachable
}

define internal void @"saw std.string.string_literal(bytes: UnsafePointer<Int8>)"(ptr %ret, ptr %p1) #0 {
entry:
  %l0 = alloca [8 x i8], align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca [8 x i8], align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l2
  call void @llvm.memcpy.p0.p0.i64(ptr %l0, ptr %l2, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %ret, ptr %l0, i64 8, i1 false)
  ret void
}

define internal ptr @"saw std.string.string_bytes(text: &String)"(ptr noalias %p1) #0 {
entry:
  %l0 = alloca ptr, align 8
  %l1 = alloca ptr, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = load ptr, ptr %t0
  store ptr %t1, ptr %l0
  %t2 = load ptr, ptr %l0
  ret ptr %t2
}

define internal i64 @"saw std.string.string_length(text: &String)"(ptr noalias %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l2
  %t1 = load ptr, ptr %l2
  %t2 = call i64 @"saw std.string.String.len()"(ptr %t1)
  store i64 %t2, ptr %l3
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3
  store i64 %t3, ptr %l0
  %t4 = load i64, ptr %l0
  ret i64 %t4
}

define internal i64 @"saw std.string.String.len()"(ptr noalias %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = load ptr, ptr %t0
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  store ptr %t2, ptr %l2
  %t3 = load i64, ptr @"static std.string.LENGTH_SLOT"
  store i64 %t3, ptr %l4
  %t4 = load ptr, ptr %l2
  %t5 = load i64, ptr %l4
  %t6 = mul i64 %t5, 8
  %t7 = getelementptr i8, ptr %t4, i64 %t6
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l0
  %t9 = load i64, ptr %l0
  ret i64 %t9
}

define internal i64 @__saw_render_uint(ptr %out, i64 %v) #0 {
entry:
  %tmp = alloca [24 x i8], align 1
  br label %loop
loop:
  %n = phi i64 [ %v, %entry ], [ %q, %loop ]
  %i = phi i64 [ 24, %entry ], [ %i1, %loop ]
  %q = udiv i64 %n, 10
  %r = urem i64 %n, 10
  %d = trunc i64 %r to i8
  %c = add i8 %d, 48
  %i1 = sub i64 %i, 1
  %p = getelementptr i8, ptr %tmp, i64 %i1
  store i8 %c, ptr %p
  %more = icmp ne i64 %q, 0
  br i1 %more, label %loop, label %done
done:
  %len = sub i64 24, %i1
  %src = getelementptr i8, ptr %tmp, i64 %i1
  call void @llvm.memcpy.p0.p0.i64(ptr %out, ptr %src, i64 %len, i1 false)
  ret i64 %len
}

define internal i64 @__saw_render_int(ptr %out, i64 %v) #0 {
entry:
  %neg = icmp slt i64 %v, 0
  br i1 %neg, label %minus, label %plain
minus:
  store i8 45, ptr %out
  %mag = sub i64 0, %v
  %rest = getelementptr i8, ptr %out, i64 1
  %n = call i64 @__saw_render_uint(ptr %rest, i64 %mag)
  %len = add i64 %n, 1
  ret i64 %len
plain:
  %m = call i64 @__saw_render_uint(ptr %out, i64 %v)
  ret i64 %m
}

define internal i64 @__saw_append(ptr %buf, i64 %pos, ptr %src, i64 %len) #0 {
entry:
  %closed = icmp slt i64 %pos, 0
  br i1 %closed, label %keep, label %open
keep:
  ret i64 %pos
open:
  %room = sub i64 508, %pos
  %fits = icmp ule i64 %len, %room
  br i1 %fits, label %whole, label %back
whole:
  %at = getelementptr i8, ptr %buf, i64 %pos
  call void @llvm.memcpy.p0.p0.i64(ptr %at, ptr %src, i64 %len, i1 false)
  %end = add i64 %pos, %len
  ret i64 %end
back:
  %n = phi i64 [ %room, %open ], [ %n1, %step ]
  %none = icmp eq i64 %n, 0
  br i1 %none, label %cut, label %test
test:
  %p = getelementptr i8, ptr %src, i64 %n
  %b = load i8, ptr %p
  %hi = and i8 %b, -64
  %inside = icmp eq i8 %hi, -128
  br i1 %inside, label %step, label %cut
step:
  %n1 = sub i64 %n, 1
  br label %back
cut:
  %at2 = getelementptr i8, ptr %buf, i64 %pos
  call void @llvm.memcpy.p0.p0.i64(ptr %at2, ptr %src, i64 %n, i1 false)
  %stop = add i64 %pos, %n
  %shut = sub i64 -1, %stop
  ret i64 %shut
}

define internal i64 @__saw_finish(ptr %buf, i64 %pos) #0 {
entry:
  %cut = icmp slt i64 %pos, 0
  br i1 %cut, label %mark, label %line
mark:
  %stop = sub i64 -1, %pos
  %m0 = getelementptr i8, ptr %buf, i64 %stop
  store i8 -30, ptr %m0
  %m1 = getelementptr i8, ptr %m0, i64 1
  store i8 -128, ptr %m1
  %m2 = getelementptr i8, ptr %m0, i64 2
  store i8 -90, ptr %m2
  %marked = add i64 %stop, 3
  br label %line
line:
  %end = phi i64 [ %marked, %mark ], [ %pos, %entry ]
  %nl = getelementptr i8, ptr %buf, i64 %end
  store i8 10, ptr %nl
  %total = add i64 %end, 1
  ret i64 %total
}

define internal i64 @__saw_append_int(ptr %buf, i64 %pos, i64 %v) #0 {
entry:
  %tmp = alloca [24 x i8], align 1
  %n = call i64 @__saw_render_int(ptr %tmp, i64 %v)
  %end = call i64 @__saw_append(ptr %buf, i64 %pos, ptr %tmp, i64 %n)
  ret i64 %end
}

define internal i64 @__saw_append_uint(ptr %buf, i64 %pos, i64 %v) #0 {
entry:
  %tmp = alloca [24 x i8], align 1
  %n = call i64 @__saw_render_uint(ptr %tmp, i64 %v)
  %end = call i64 @__saw_append(ptr %buf, i64 %pos, ptr %tmp, i64 %n)
  ret i64 %end
}

@__saw_fail_at = private unnamed_addr constant [9 x i8] c"panic at "
@__saw_fail_colon = private unnamed_addr constant [2 x i8] c": "
@__saw_fail_true = private unnamed_addr constant [4 x i8] c"true"
@__saw_fail_false = private unnamed_addr constant [5 x i8] c"false"
@__saw_fail_overflow.reason = private unnamed_addr constant [16 x i8] c"integer overflow"
@__saw_fail_divide.reason = private unnamed_addr constant [16 x i8] c"division by zero"
@__saw_fail_shift.reason = private unnamed_addr constant [18 x i8] c"shift out of range"
@__saw_fail_unwrap.reason = private unnamed_addr constant [20 x i8] c"force unwrap of None"
@__saw_fail_try.reason = private unnamed_addr constant [11 x i8] c"try! failed"

define internal i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line) #0 {
entry:
  %at = call i64 @__saw_append(ptr %buf, i64 0, ptr @__saw_fail_at, i64 9)
  %named = call i64 @__saw_append(ptr %buf, i64 %at, ptr %file, i64 %file_len)
  %known = icmp sge i64 %line, 0
  br i1 %known, label %number, label %tail
number:
  %colon = call i64 @__saw_append(ptr %buf, i64 %named, ptr @__saw_fail_colon, i64 1)
  %lined = call i64 @__saw_append_uint(ptr %buf, i64 %colon, i64 %line)
  br label %tail
tail:
  %pos = phi i64 [ %named, %entry ], [ %lined, %number ]
  %end = call i64 @__saw_append(ptr %buf, i64 %pos, ptr @__saw_fail_colon, i64 2)
  ret i64 %end
}

define internal void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr %text, i64 %text_len) noinline noreturn #0 {
entry:
  %buf = alloca [512 x i8], align 1
  %head = call i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line)
  %done = call i64 @__saw_append(ptr %buf, i64 %head, ptr %text, i64 %text_len)
  %end = call i64 @__saw_finish(ptr %buf, i64 %done)
  call void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %buf, i64 %end)
  unreachable
}

define internal void @__saw_fail_signed(ptr %file, i64 %file_len, i64 %line, ptr %text, i64 %text_len, i64 %v) noinline noreturn #0 {
entry:
  %buf = alloca [512 x i8], align 1
  %head = call i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line)
  %pos = call i64 @__saw_append(ptr %buf, i64 %head, ptr %text, i64 %text_len)
  %done = call i64 @__saw_append_int(ptr %buf, i64 %pos, i64 %v)
  %end = call i64 @__saw_finish(ptr %buf, i64 %done)
  call void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %buf, i64 %end)
  unreachable
}

define internal void @__saw_fail_unsigned(ptr %file, i64 %file_len, i64 %line, ptr %text, i64 %text_len, i64 %v) noinline noreturn #0 {
entry:
  %buf = alloca [512 x i8], align 1
  %head = call i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line)
  %pos = call i64 @__saw_append(ptr %buf, i64 %head, ptr %text, i64 %text_len)
  %done = call i64 @__saw_append_uint(ptr %buf, i64 %pos, i64 %v)
  %end = call i64 @__saw_finish(ptr %buf, i64 %done)
  call void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %buf, i64 %end)
  unreachable
}

define internal void @__saw_fail_parts(ptr %file, i64 %file_len, i64 %line, ptr %text, i64 %text_len, ptr %parts, i64 %count) noinline noreturn #0 {
entry:
  %buf = alloca [512 x i8], align 1
  %head = call i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line)
  %pos = call i64 @__saw_append(ptr %buf, i64 %head, ptr %text, i64 %text_len)
  br label %loop
loop:
  %i = phi i64 [ 0, %entry ], [ %i1, %next ]
  %at = phi i64 [ %pos, %entry ], [ %after, %next ]
  %more = icmp slt i64 %i, %count
  br i1 %more, label %part, label %last
part:
  %offset = mul i64 %i, 24
  %p = getelementptr i8, ptr %parts, i64 %offset
  %kind = load i64, ptr %p
  %first = getelementptr i8, ptr %p, i64 8
  %second = getelementptr i8, ptr %p, i64 16
  switch i64 %kind, label %run [ i64 1, label %signed i64 2, label %unsigned i64 3, label %bool ]
run:
  %src = load ptr, ptr %first
  %len = load i64, ptr %second
  %ran = call i64 @__saw_append(ptr %buf, i64 %at, ptr %src, i64 %len)
  br label %next
signed:
  %sv = load i64, ptr %first
  %sd = call i64 @__saw_append_int(ptr %buf, i64 %at, i64 %sv)
  br label %next
unsigned:
  %uv = load i64, ptr %first
  %ud = call i64 @__saw_append_uint(ptr %buf, i64 %at, i64 %uv)
  br label %next
bool:
  %byte = load i8, ptr %first
  %yes = icmp ne i8 %byte, 0
  %word = select i1 %yes, ptr @__saw_fail_true, ptr @__saw_fail_false
  %size = select i1 %yes, i64 4, i64 5
  %bd = call i64 @__saw_append(ptr %buf, i64 %at, ptr %word, i64 %size)
  br label %next
next:
  %after = phi i64 [ %ran, %run ], [ %sd, %signed ], [ %ud, %unsigned ], [ %bd, %bool ]
  %i1 = add i64 %i, 1
  br label %loop
last:
  %done = phi i64 [ %at, %loop ]
  %end = call i64 @__saw_finish(ptr %buf, i64 %done)
  call void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %buf, i64 %end)
  unreachable
}

define internal void @__saw_fail_overflow(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_overflow.reason, i64 16)
  unreachable
}

define internal void @__saw_fail_divide(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_divide.reason, i64 16)
  unreachable
}

define internal void @__saw_fail_shift(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_shift.reason, i64 18)
  unreachable
}

define internal void @__saw_fail_unwrap(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_unwrap.reason, i64 20)
  unreachable
}

define internal void @__saw_fail_try(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_try.reason, i64 11)
  unreachable
}

attributes #0 = { "frame-pointer"="non-leaf" }
