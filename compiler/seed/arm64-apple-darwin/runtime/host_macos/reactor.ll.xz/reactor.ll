; sawc2 link manifest
; target arm64-apple-darwin
; speed -O2
; runtime none

target triple = "arm64-apple-macosx11.0.0"

@"static reactor.WAKE_IDENT" = internal global i64 1
@"static reactor.EVFILT_USER" = internal global i16 -10
@"static reactor.EV_ADD_CLEAR" = internal global i16 33
@.bytes.0 = private unnamed_addr constant [11 x i8] c"reactor.saw"
@.bytes.1 = private unnamed_addr constant [29 x i8] c"cast to UInt32 out of range: "
@"static reactor.EV_ADD_ONESHOT" = internal global i16 17
@.bytes.2 = private unnamed_addr constant [28 x i8] c"cast to Int32 out of range: "
@"static reactor.EV_DELETE" = internal global i16 2
@"static reactor.POLL_EVENTS" = internal global i64 64
@.bytes.3 = private unnamed_addr constant [29 x i8] c"cast to UInt16 out of range: "
@"static reactor.NOTE_TRIGGER" = internal global i32 16777216
@"static std.string.LENGTH_SLOT" = internal global i64 -1

declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare i32 @kqueue()
declare ptr @calloc(i64, i64)
declare i32 @kevent(i32, ptr, i32, ptr, i32, ptr)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare ptr @malloc(i64)
declare void @free(ptr)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare i32 @close(i32)
declare void @__saw_rt_panic(ptr, i64)

define i64 @"__saw_rt_reactor_create"() #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i32, align 4
  %l2 = alloca i32, align 4
  %l3 = alloca ptr, align 8
  %l4 = alloca i64, align 8
  %l5 = alloca ptr, align 8
  %l6 = alloca ptr, align 8
  %l7 = alloca ptr, align 8
  %l8 = alloca i64, align 8
  %l9 = alloca i64, align 8
  %l10 = alloca [32 x i8], align 8
  %l11 = alloca i64, align 8
  %l12 = alloca i16, align 2
  %l13 = alloca i16, align 2
  %l14 = alloca i32, align 4
  %l15 = alloca [32 x i8], align 8
  %l16 = alloca ptr, align 8
  %l17 = alloca ptr, align 8
  %l18 = alloca i32, align 4
  %l19 = alloca ptr, align 8
  %l20 = alloca ptr, align 8
  %l21 = alloca i32, align 4
  %l22 = alloca i64, align 8
  br label %bb0
bb0:
  %t0 = call i32 @kqueue()
  store i32 %t0, ptr %l2
  br label %bb1
bb1:
  %t1 = load i32, ptr %l2
  store i32 %t1, ptr %l1
  store i64 16, ptr %l4
  br label %bb2
bb2:
  %t2 = load i64, ptr %l4
  %t3 = call ptr @calloc(i64 1, i64 %t2)
  store ptr %t3, ptr %l5
  br label %bb3
bb3:
  %t4 = load ptr, ptr %l5
  store ptr %t4, ptr %l3
  %t5 = load ptr, ptr %l3
  store ptr %t5, ptr %l7
  %t6 = load ptr, ptr %l7
  store ptr %t6, ptr %l6
  store i64 0, ptr %l8
  %t7 = load i32, ptr %l1
  %t8 = sext i32 %t7 to i64
  %t9 = trunc i64 %t8 to i32
  %t10 = icmp eq i32 %t9, %t7
  %t11 = sext i32 %t7 to i64
  store i64 %t11, ptr %l9
  %t12 = load ptr, ptr %l6
  %t13 = load i64, ptr %l8
  %t14 = mul i64 %t13, 16
  %t15 = getelementptr i8, ptr %t12, i64 %t14
  %t16 = load i64, ptr %l9
  store i64 %t16, ptr %t15
  %t17 = load i64, ptr @"static reactor.WAKE_IDENT"
  store i64 %t17, ptr %l11
  %t18 = load i16, ptr @"static reactor.EVFILT_USER"
  store i16 %t18, ptr %l12
  %t19 = load i16, ptr @"static reactor.EV_ADD_CLEAR"
  store i16 %t19, ptr %l13
  %t20 = trunc i64 0 to i32
  %t21 = zext i32 %t20 to i64
  %t22 = icmp eq i64 %t21, 0
  %t23 = icmp sge i64 0, 0
  %t24 = and i1 %t22, %t23
  %t25 = trunc i64 0 to i32
  %t26 = xor i1 %t24, 1
  br i1 %t26, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 11, i64 91, ptr @.bytes.1, i64 29, i64 0)
  unreachable
casted.1:
  store i32 %t25, ptr %l14
  %t27 = load i64, ptr %l11
  store i64 %t27, ptr %l15
  %t28 = getelementptr i8, ptr %l15, i64 8
  %t29 = load i16, ptr %l12
  store i16 %t29, ptr %t28
  %t30 = getelementptr i8, ptr %l15, i64 10
  %t31 = load i16, ptr %l13
  store i16 %t31, ptr %t30
  %t32 = getelementptr i8, ptr %l15, i64 12
  %t33 = load i32, ptr %l14
  store i32 %t33, ptr %t32
  %t34 = getelementptr i8, ptr %l15, i64 16
  store i64 0, ptr %t34
  %t35 = getelementptr i8, ptr %l15, i64 24
  store i64 0, ptr %t35
  call void @llvm.memcpy.p0.p0.i64(ptr %l10, ptr %l15, i64 32, i1 false)
  %t36 = inttoptr i64 0 to ptr
  store ptr %t36, ptr %l17
  %t37 = load ptr, ptr %l17
  store ptr %t37, ptr %l16
  %t38 = load i32, ptr %l1
  %t39 = icmp eq i32 %t38, %t38
  store i32 %t38, ptr %l18
  store ptr %l10, ptr %l19
  %t40 = load ptr, ptr %l19
  store ptr %t40, ptr %l20
  %t41 = load i32, ptr %l18
  %t42 = load ptr, ptr %l20
  %t43 = load ptr, ptr %l16
  %t44 = load ptr, ptr %l16
  %t45 = call i32 @kevent(i32 %t41, ptr %t42, i32 1, ptr %t43, i32 0, ptr %t44)
  store i32 %t45, ptr %l21
  br label %bb4
bb4:
  %t46 = load ptr, ptr %l3
  %t47 = ptrtoint ptr %t46 to i64
  store i64 %t47, ptr %l22
  %t48 = load i64, ptr %l22
  store i64 %t48, ptr %l0
  %t49 = load i64, ptr %l0
  ret i64 %t49
}

define void @"__saw_rt_reactor_register"(i64 %p1, i64 %p2, i64 %p3, i64 %p4) #0 {
entry:
  %l0 = alloca [0 x i8], align 1
  %l1 = alloca i64, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca i64, align 8
  %l5 = alloca ptr, align 8
  %l6 = alloca ptr, align 8
  %l7 = alloca i64, align 8
  %l8 = alloca i64, align 8
  %l9 = alloca i16, align 2
  %l10 = alloca i8, align 1
  %l11 = alloca i16, align 2
  %l12 = alloca i16, align 2
  %l13 = alloca [32 x i8], align 8
  %l14 = alloca i64, align 8
  %l15 = alloca i16, align 2
  %l16 = alloca i16, align 2
  %l17 = alloca i32, align 4
  %l18 = alloca [32 x i8], align 8
  %l19 = alloca ptr, align 8
  %l20 = alloca ptr, align 8
  %l21 = alloca i32, align 4
  %l22 = alloca ptr, align 8
  %l23 = alloca ptr, align 8
  %l24 = alloca i32, align 4
  store i64 %p1, ptr %l1
  store i64 %p2, ptr %l2
  store i64 %p3, ptr %l3
  store i64 %p4, ptr %l4
  br label %bb0
bb0:
  %t0 = load i64, ptr %l1
  %t1 = inttoptr i64 %t0 to ptr
  store ptr %t1, ptr %l6
  %t2 = load ptr, ptr %l6
  store ptr %t2, ptr %l5
  store i64 0, ptr %l8
  %t3 = load ptr, ptr %l5
  %t4 = load i64, ptr %l8
  %t5 = mul i64 %t4, 16
  %t6 = getelementptr i8, ptr %t3, i64 %t5
  %t7 = load i64, ptr %t6
  store i64 %t7, ptr %l7
  %t8 = load i64, ptr %l3
  %t9 = icmp ne i64 %t8, 0
  %t10 = zext i1 %t9 to i8
  store i8 %t10, ptr %l10
  %t11 = load i8, ptr %l10
  %t12 = icmp ne i8 %t11, 0
  br i1 %t12, label %bb2, label %bb3
bb1:
  %t13 = load i64, ptr %l2
  store i64 %t13, ptr %l14
  %t14 = load i16, ptr %l9
  store i16 %t14, ptr %l15
  %t15 = load i16, ptr @"static reactor.EV_ADD_ONESHOT"
  store i16 %t15, ptr %l16
  %t16 = trunc i64 0 to i32
  %t17 = zext i32 %t16 to i64
  %t18 = icmp eq i64 %t17, 0
  %t19 = icmp sge i64 0, 0
  %t20 = and i1 %t18, %t19
  %t21 = trunc i64 0 to i32
  %t22 = xor i1 %t20, 1
  br i1 %t22, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 11, i64 106, ptr @.bytes.1, i64 29, i64 0)
  unreachable
casted.1:
  store i32 %t21, ptr %l17
  %t23 = load i64, ptr %l14
  store i64 %t23, ptr %l18
  %t24 = getelementptr i8, ptr %l18, i64 8
  %t25 = load i16, ptr %l15
  store i16 %t25, ptr %t24
  %t26 = getelementptr i8, ptr %l18, i64 10
  %t27 = load i16, ptr %l16
  store i16 %t27, ptr %t26
  %t28 = getelementptr i8, ptr %l18, i64 12
  %t29 = load i32, ptr %l17
  store i32 %t29, ptr %t28
  %t30 = getelementptr i8, ptr %l18, i64 16
  store i64 0, ptr %t30
  %t31 = getelementptr i8, ptr %l18, i64 24
  %t32 = load i64, ptr %l4
  store i64 %t32, ptr %t31
  call void @llvm.memcpy.p0.p0.i64(ptr %l13, ptr %l18, i64 32, i1 false)
  %t33 = inttoptr i64 0 to ptr
  store ptr %t33, ptr %l20
  %t34 = load ptr, ptr %l20
  store ptr %t34, ptr %l19
  %t35 = load i64, ptr %l7
  %t36 = trunc i64 %t35 to i32
  %t37 = sext i32 %t36 to i64
  %t38 = icmp eq i64 %t37, %t35
  %t39 = trunc i64 %t35 to i32
  %t40 = xor i1 %t38, 1
  br i1 %t40, label %cast.2, label %casted.3
cast.2:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 11, i64 108, ptr @.bytes.2, i64 28, i64 %t35)
  unreachable
casted.3:
  store i32 %t39, ptr %l21
  store ptr %l13, ptr %l22
  %t41 = load ptr, ptr %l22
  store ptr %t41, ptr %l23
  %t42 = load i32, ptr %l21
  %t43 = load ptr, ptr %l23
  %t44 = load ptr, ptr %l19
  %t45 = load ptr, ptr %l19
  %t46 = call i32 @kevent(i32 %t42, ptr %t43, i32 1, ptr %t44, i32 0, ptr %t45)
  store i32 %t46, ptr %l24
  br label %bb4
bb2:
  store i16 -2, ptr %l11
  %t47 = load i16, ptr %l11
  store i16 %t47, ptr %l9
  br label %bb1
bb3:
  store i16 -1, ptr %l12
  %t48 = load i16, ptr %l12
  store i16 %t48, ptr %l9
  br label %bb1
bb4:
  ret void
}

define void @"__saw_rt_reactor_unregister"(i64 %p1, i64 %p2, i64 %p3) #0 {
entry:
  %l0 = alloca [0 x i8], align 1
  %l1 = alloca i64, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca i64, align 8
  %l4 = alloca ptr, align 8
  %l5 = alloca ptr, align 8
  %l6 = alloca i64, align 8
  %l7 = alloca i64, align 8
  %l8 = alloca i16, align 2
  %l9 = alloca i8, align 1
  %l10 = alloca i16, align 2
  %l11 = alloca i16, align 2
  %l12 = alloca [32 x i8], align 8
  %l13 = alloca i64, align 8
  %l14 = alloca i16, align 2
  %l15 = alloca i16, align 2
  %l16 = alloca i32, align 4
  %l17 = alloca [32 x i8], align 8
  %l18 = alloca ptr, align 8
  %l19 = alloca ptr, align 8
  %l20 = alloca i32, align 4
  %l21 = alloca ptr, align 8
  %l22 = alloca ptr, align 8
  %l23 = alloca i32, align 4
  store i64 %p1, ptr %l1
  store i64 %p2, ptr %l2
  store i64 %p3, ptr %l3
  br label %bb0
bb0:
  %t0 = load i64, ptr %l1
  %t1 = inttoptr i64 %t0 to ptr
  store ptr %t1, ptr %l5
  %t2 = load ptr, ptr %l5
  store ptr %t2, ptr %l4
  store i64 0, ptr %l7
  %t3 = load ptr, ptr %l4
  %t4 = load i64, ptr %l7
  %t5 = mul i64 %t4, 16
  %t6 = getelementptr i8, ptr %t3, i64 %t5
  %t7 = load i64, ptr %t6
  store i64 %t7, ptr %l6
  %t8 = load i64, ptr %l3
  %t9 = icmp ne i64 %t8, 0
  %t10 = zext i1 %t9 to i8
  store i8 %t10, ptr %l9
  %t11 = load i8, ptr %l9
  %t12 = icmp ne i8 %t11, 0
  br i1 %t12, label %bb2, label %bb3
bb1:
  %t13 = load i64, ptr %l2
  store i64 %t13, ptr %l13
  %t14 = load i16, ptr %l8
  store i16 %t14, ptr %l14
  %t15 = load i16, ptr @"static reactor.EV_DELETE"
  store i16 %t15, ptr %l15
  %t16 = trunc i64 0 to i32
  %t17 = zext i32 %t16 to i64
  %t18 = icmp eq i64 %t17, 0
  %t19 = icmp sge i64 0, 0
  %t20 = and i1 %t18, %t19
  %t21 = trunc i64 0 to i32
  %t22 = xor i1 %t20, 1
  br i1 %t22, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 11, i64 129, ptr @.bytes.1, i64 29, i64 0)
  unreachable
casted.1:
  store i32 %t21, ptr %l16
  %t23 = load i64, ptr %l13
  store i64 %t23, ptr %l17
  %t24 = getelementptr i8, ptr %l17, i64 8
  %t25 = load i16, ptr %l14
  store i16 %t25, ptr %t24
  %t26 = getelementptr i8, ptr %l17, i64 10
  %t27 = load i16, ptr %l15
  store i16 %t27, ptr %t26
  %t28 = getelementptr i8, ptr %l17, i64 12
  %t29 = load i32, ptr %l16
  store i32 %t29, ptr %t28
  %t30 = getelementptr i8, ptr %l17, i64 16
  store i64 0, ptr %t30
  %t31 = getelementptr i8, ptr %l17, i64 24
  store i64 0, ptr %t31
  call void @llvm.memcpy.p0.p0.i64(ptr %l12, ptr %l17, i64 32, i1 false)
  %t32 = inttoptr i64 0 to ptr
  store ptr %t32, ptr %l19
  %t33 = load ptr, ptr %l19
  store ptr %t33, ptr %l18
  %t34 = load i64, ptr %l6
  %t35 = trunc i64 %t34 to i32
  %t36 = sext i32 %t35 to i64
  %t37 = icmp eq i64 %t36, %t34
  %t38 = trunc i64 %t34 to i32
  %t39 = xor i1 %t37, 1
  br i1 %t39, label %cast.2, label %casted.3
cast.2:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 11, i64 131, ptr @.bytes.2, i64 28, i64 %t34)
  unreachable
casted.3:
  store i32 %t38, ptr %l20
  store ptr %l12, ptr %l21
  %t40 = load ptr, ptr %l21
  store ptr %t40, ptr %l22
  %t41 = load i32, ptr %l20
  %t42 = load ptr, ptr %l22
  %t43 = load ptr, ptr %l18
  %t44 = load ptr, ptr %l18
  %t45 = call i32 @kevent(i32 %t41, ptr %t42, i32 1, ptr %t43, i32 0, ptr %t44)
  store i32 %t45, ptr %l23
  br label %bb4
bb2:
  store i16 -2, ptr %l10
  %t46 = load i16, ptr %l10
  store i16 %t46, ptr %l8
  br label %bb1
bb3:
  store i16 -1, ptr %l11
  %t47 = load i16, ptr %l11
  store i16 %t47, ptr %l8
  br label %bb1
bb4:
  ret void
}

define i64 @"__saw_rt_reactor_poll"(i64 %p1, i64 %p2) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca i64, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca ptr, align 8
  %l5 = alloca i64, align 8
  %l6 = alloca i64, align 8
  %l7 = alloca ptr, align 8
  %l8 = alloca i64, align 8
  %l9 = alloca i64, align 8
  %l10 = alloca i64, align 8
  %l11 = alloca ptr, align 8
  %l12 = alloca [16 x i8], align 8
  %l13 = alloca i64, align 8
  %l14 = alloca i64, align 8
  %l15 = alloca i64, align 8
  %l16 = alloca [16 x i8], align 8
  %l17 = alloca ptr, align 8
  %l18 = alloca i8, align 1
  %l19 = alloca ptr, align 8
  %l20 = alloca ptr, align 8
  %l21 = alloca ptr, align 8
  %l22 = alloca i64, align 8
  %l23 = alloca ptr, align 8
  %l24 = alloca i64, align 8
  %l25 = alloca i32, align 4
  %l26 = alloca i32, align 4
  %l27 = alloca ptr, align 8
  %l28 = alloca ptr, align 8
  %l29 = alloca i32, align 4
  %l30 = alloca i32, align 4
  %l31 = alloca i64, align 8
  %l32 = alloca i64, align 8
  %l33 = alloca ptr, align 8
  %l34 = alloca i64, align 8
  %l35 = alloca ptr, align 8
  %l36 = alloca ptr, align 8
  %l37 = alloca i8, align 1
  %l38 = alloca i64, align 8
  %l39 = alloca i64, align 8
  %l40 = alloca i64, align 8
  %l41 = alloca i8, align 1
  %l42 = alloca i64, align 8
  %l43 = alloca i8, align 1
  %l44 = alloca i64, align 8
  %l45 = alloca i64, align 8
  %l46 = alloca i8, align 1
  %l47 = alloca ptr, align 8
  %l48 = alloca ptr, align 8
  %l49 = alloca i64, align 8
  %l50 = alloca i64, align 8
  %l51 = alloca i64, align 8
  %l52 = alloca ptr, align 8
  %l53 = alloca i64, align 8
  %l54 = alloca i8, align 1
  %l55 = alloca i64, align 8
  store i64 %p1, ptr %l1
  store i64 %p2, ptr %l2
  br label %bb0
bb0:
  %t0 = load i64, ptr %l1
  %t1 = inttoptr i64 %t0 to ptr
  store ptr %t1, ptr %l4
  %t2 = load ptr, ptr %l4
  store ptr %t2, ptr %l3
  store i64 0, ptr %l6
  %t3 = load ptr, ptr %l3
  %t4 = load i64, ptr %l6
  %t5 = mul i64 %t4, 16
  %t6 = getelementptr i8, ptr %t3, i64 %t5
  %t7 = load i64, ptr %t6
  store i64 %t7, ptr %l5
  %t8 = load i64, ptr @"static reactor.POLL_EVENTS"
  store i64 %t8, ptr %l8
  store i64 32, ptr %l9
  br label %bb1
bb1:
  %t9 = load i64, ptr %l8
  %t10 = load i64, ptr %l9
  %t11 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %t9, i64 %t10)
  %t12 = extractvalue { i64, i1 } %t11, 0
  %t13 = extractvalue { i64, i1 } %t11, 1
  br i1 %t13, label %check.0, label %checked.1
check.0:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 11, i64 150)
  unreachable
checked.1:
  store i64 %t12, ptr %l10
  %t14 = load i64, ptr %l10
  %t15 = call ptr @malloc(i64 %t14)
  store ptr %t15, ptr %l11
  br label %bb2
bb2:
  %t16 = load ptr, ptr %l11
  store ptr %t16, ptr %l7
  %t17 = load i64, ptr %l2
  %t18 = icmp eq i64 1000, 0
  br i1 %t18, label %check.2, label %checked.3
check.2:
  call void @__saw_fail_divide(ptr @.bytes.0, i64 11, i64 151)
  unreachable
checked.3:
  %t19 = icmp eq i64 %t17, -9223372036854775808
  %t20 = icmp eq i64 1000, -1
  %t21 = and i1 %t19, %t20
  br i1 %t21, label %check.4, label %checked.5
check.4:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 11, i64 151)
  unreachable
checked.5:
  %t22 = sdiv i64 %t17, 1000
  store i64 %t22, ptr %l13
  %t23 = load i64, ptr %l2
  %t24 = icmp eq i64 1000, 0
  br i1 %t24, label %check.6, label %checked.7
check.6:
  call void @__saw_fail_divide(ptr @.bytes.0, i64 11, i64 151)
  unreachable
checked.7:
  %t25 = icmp eq i64 %t23, -9223372036854775808
  %t26 = icmp eq i64 1000, -1
  %t27 = and i1 %t25, %t26
  br i1 %t27, label %check.8, label %checked.9
check.8:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 11, i64 151)
  unreachable
checked.9:
  %t28 = srem i64 %t23, 1000
  store i64 %t28, ptr %l14
  %t29 = load i64, ptr %l14
  %t30 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %t29, i64 1000000)
  %t31 = extractvalue { i64, i1 } %t30, 0
  %t32 = extractvalue { i64, i1 } %t30, 1
  br i1 %t32, label %check.10, label %checked.11
check.10:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 11, i64 151)
  unreachable
checked.11:
  store i64 %t31, ptr %l15
  %t33 = load i64, ptr %l13
  store i64 %t33, ptr %l16
  %t34 = getelementptr i8, ptr %l16, i64 8
  %t35 = load i64, ptr %l15
  store i64 %t35, ptr %t34
  call void @llvm.memcpy.p0.p0.i64(ptr %l12, ptr %l16, i64 16, i1 false)
  %t36 = load i64, ptr %l2
  %t37 = icmp slt i64 %t36, 0
  %t38 = zext i1 %t37 to i8
  store i8 %t38, ptr %l18
  %t39 = load i8, ptr %l18
  %t40 = icmp ne i8 %t39, 0
  br i1 %t40, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l22
  %t41 = load ptr, ptr %l3
  %t42 = load i64, ptr %l22
  %t43 = mul i64 %t42, 16
  %t44 = getelementptr i8, ptr %t41, i64 %t43
  %t45 = getelementptr i8, ptr %t44, i64 8
  store ptr %t45, ptr %l23
  %t46 = load ptr, ptr %l23
  %t47 = call i64 @"saw Atomic.fetch_add(v: Int) args Int"(ptr %t46, i64 1)
  store i64 %t47, ptr %l24
  br label %bb6
bb4:
  %t48 = inttoptr i64 0 to ptr
  store ptr %t48, ptr %l19
  %t49 = load ptr, ptr %l19
  store ptr %t49, ptr %l17
  br label %bb3
bb5:
  store ptr %l12, ptr %l20
  %t50 = load ptr, ptr %l20
  store ptr %t50, ptr %l21
  %t51 = load ptr, ptr %l21
  store ptr %t51, ptr %l17
  br label %bb3
bb6:
  %t52 = load i64, ptr %l5
  %t53 = trunc i64 %t52 to i32
  %t54 = sext i32 %t53 to i64
  %t55 = icmp eq i64 %t54, %t52
  %t56 = trunc i64 %t52 to i32
  %t57 = xor i1 %t55, 1
  br i1 %t57, label %cast.12, label %casted.13
cast.12:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 11, i64 157, ptr @.bytes.2, i64 28, i64 %t52)
  unreachable
casted.13:
  store i32 %t56, ptr %l26
  %t58 = inttoptr i64 0 to ptr
  store ptr %t58, ptr %l27
  %t59 = load ptr, ptr %l7
  store ptr %t59, ptr %l28
  %t60 = load i64, ptr @"static reactor.POLL_EVENTS"
  %t61 = trunc i64 %t60 to i32
  %t62 = sext i32 %t61 to i64
  %t63 = icmp eq i64 %t62, %t60
  %t64 = trunc i64 %t60 to i32
  %t65 = xor i1 %t63, 1
  br i1 %t65, label %cast.14, label %casted.15
cast.14:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 11, i64 157, ptr @.bytes.2, i64 28, i64 %t60)
  unreachable
casted.15:
  store i32 %t64, ptr %l29
  %t66 = load i32, ptr %l26
  %t67 = load ptr, ptr %l27
  %t68 = load ptr, ptr %l28
  %t69 = load i32, ptr %l29
  %t70 = load ptr, ptr %l17
  %t71 = call i32 @kevent(i32 %t66, ptr %t67, i32 0, ptr %t68, i32 %t69, ptr %t70)
  store i32 %t71, ptr %l30
  br label %bb7
bb7:
  %t72 = load i32, ptr %l30
  store i32 %t72, ptr %l25
  store i64 0, ptr %l31
  store i64 -1, ptr %l32
  %t73 = load ptr, ptr %l3
  %t74 = load i64, ptr %l31
  %t75 = mul i64 %t74, 16
  %t76 = getelementptr i8, ptr %t73, i64 %t75
  %t77 = getelementptr i8, ptr %t76, i64 8
  store ptr %t77, ptr %l33
  %t78 = load ptr, ptr %l33
  %t79 = load i64, ptr %l32
  %t80 = call i64 @"saw Atomic.fetch_add(v: Int) args Int"(ptr %t78, i64 %t79)
  store i64 %t80, ptr %l34
  br label %bb8
bb8:
  %t81 = load ptr, ptr %l7
  store ptr %t81, ptr %l36
  %t82 = load ptr, ptr %l36
  store ptr %t82, ptr %l35
  store i8 0, ptr %l37
  store i64 0, ptr %l38
  br label %bb9
bb9:
  %t83 = load i64, ptr %l38
  store i64 %t83, ptr %l39
  %t84 = load i32, ptr %l25
  %t85 = sext i32 %t84 to i64
  %t86 = trunc i64 %t85 to i32
  %t87 = icmp eq i32 %t86, %t84
  %t88 = sext i32 %t84 to i64
  store i64 %t88, ptr %l40
  %t89 = load i64, ptr %l39
  %t90 = load i64, ptr %l40
  %t91 = icmp slt i64 %t89, %t90
  %t92 = zext i1 %t91 to i8
  store i8 %t92, ptr %l41
  %t93 = load i8, ptr %l41
  %t94 = icmp ne i8 %t93, 0
  br i1 %t94, label %bb11, label %bb10
bb10:
  %t95 = load ptr, ptr %l7
  call void @free(ptr %t95)
  br label %bb19
bb11:
  br label %bb12
bb12:
  %t96 = load i64, ptr %l38
  store i64 %t96, ptr %l42
  %t97 = load ptr, ptr %l35
  %t98 = load i64, ptr %l42
  %t99 = mul i64 %t98, 32
  %t100 = getelementptr i8, ptr %t97, i64 %t99
  %t101 = getelementptr i8, ptr %t100, i64 8
  %t102 = load i16, ptr %t101
  %t103 = load i16, ptr @"static reactor.EVFILT_USER"
  %t104 = icmp eq i16 %t102, %t103
  %t105 = zext i1 %t104 to i8
  store i8 %t105, ptr %l43
  %t106 = load i8, ptr %l43
  %t107 = icmp ne i8 %t106, 0
  br i1 %t107, label %bb14, label %bb15
bb13:
  %t108 = load i64, ptr %l38
  store i64 %t108, ptr %l45
  %t109 = load ptr, ptr %l35
  %t110 = load i64, ptr %l45
  %t111 = mul i64 %t110, 32
  %t112 = getelementptr i8, ptr %t109, i64 %t111
  %t113 = getelementptr i8, ptr %t112, i64 24
  %t114 = load i64, ptr %t113
  store i64 %t114, ptr %l44
  %t115 = load i64, ptr %l44
  %t116 = icmp ne i64 %t115, 0
  %t117 = zext i1 %t116 to i8
  store i8 %t117, ptr %l46
  %t118 = load i8, ptr %l46
  %t119 = icmp ne i8 %t118, 0
  br i1 %t119, label %bb17, label %bb18
bb14:
  store i8 1, ptr %l37
  br label %bb13
bb15:
  br label %bb13
bb16:
  %t120 = load i64, ptr %l38
  %t121 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %t120, i64 1)
  %t122 = extractvalue { i64, i1 } %t121, 0
  %t123 = extractvalue { i64, i1 } %t121, 1
  br i1 %t123, label %check.16, label %checked.17
check.16:
  call void @__saw_fail_overflow(ptr @.bytes.0, i64 11, i64 171)
  unreachable
checked.17:
  store i64 %t122, ptr %l50
  %t124 = load i64, ptr %l50
  store i64 %t124, ptr %l38
  br label %bb9
bb17:
  %t125 = load i64, ptr %l44
  %t126 = inttoptr i64 %t125 to ptr
  store ptr %t126, ptr %l48
  %t127 = load ptr, ptr %l48
  store ptr %t127, ptr %l47
  store i64 0, ptr %l49
  %t128 = load ptr, ptr %l47
  %t129 = load i64, ptr %l49
  %t130 = mul i64 %t129, 8
  %t131 = getelementptr i8, ptr %t128, i64 %t130
  store i64 0, ptr %t131
  br label %bb16
bb18:
  br label %bb16
bb19:
  %t132 = load i8, ptr %l37
  %t133 = icmp ne i8 %t132, 0
  br i1 %t133, label %bb21, label %bb22
bb20:
  %t134 = load i32, ptr %l25
  %t135 = sext i32 %t134 to i64
  %t136 = trunc i64 %t135 to i32
  %t137 = icmp eq i32 %t136, %t134
  %t138 = sext i32 %t134 to i64
  store i64 %t138, ptr %l55
  %t139 = load i64, ptr %l55
  store i64 %t139, ptr %l0
  %t140 = load i64, ptr %l0
  ret i64 %t140
bb21:
  store i64 0, ptr %l51
  %t141 = load ptr, ptr %l3
  %t142 = load i64, ptr %l51
  %t143 = mul i64 %t142, 16
  %t144 = getelementptr i8, ptr %t141, i64 %t143
  %t145 = getelementptr i8, ptr %t144, i64 8
  store ptr %t145, ptr %l52
  %t146 = load ptr, ptr %l52
  %t147 = call i64 @"saw Atomic.load() args Int"(ptr %t146)
  store i64 %t147, ptr %l53
  br label %bb24
bb22:
  br label %bb20
bb23:
  br label %bb20
bb24:
  %t148 = load i64, ptr %l53
  %t149 = icmp sgt i64 %t148, 0
  %t150 = zext i1 %t149 to i8
  store i8 %t150, ptr %l54
  %t151 = load i8, ptr %l54
  %t152 = icmp ne i8 %t151, 0
  br i1 %t152, label %bb25, label %bb26
bb25:
  %t153 = load i64, ptr %l5
  call void @"saw reactor.rt_reactor_trigger(kfd: Int)"(i64 %t153)
  br label %bb27
bb26:
  br label %bb23
bb27:
  br label %bb23
}

define void @"__saw_rt_reactor_wake"(i64 %p1) #0 {
entry:
  %l0 = alloca [0 x i8], align 1
  %l1 = alloca i64, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca i64, align 8
  store i64 %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load i64, ptr %l1
  %t1 = inttoptr i64 %t0 to ptr
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  store ptr %t2, ptr %l2
  store i64 0, ptr %l4
  %t3 = load ptr, ptr %l2
  %t4 = load i64, ptr %l4
  %t5 = mul i64 %t4, 16
  %t6 = getelementptr i8, ptr %t3, i64 %t5
  %t7 = load i64, ptr %t6
  call void @"saw reactor.rt_reactor_trigger(kfd: Int)"(i64 %t7)
  br label %bb1
bb1:
  ret void
}

define void @"__saw_rt_reactor_destroy"(i64 %p1) #0 {
entry:
  %l0 = alloca [0 x i8], align 1
  %l1 = alloca i64, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca i64, align 8
  %l5 = alloca i32, align 4
  %l6 = alloca i32, align 4
  %l7 = alloca ptr, align 8
  store i64 %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load i64, ptr %l1
  %t1 = inttoptr i64 %t0 to ptr
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  store ptr %t2, ptr %l2
  store i64 0, ptr %l4
  %t3 = load ptr, ptr %l2
  %t4 = load i64, ptr %l4
  %t5 = mul i64 %t4, 16
  %t6 = getelementptr i8, ptr %t3, i64 %t5
  %t7 = load i64, ptr %t6
  %t8 = trunc i64 %t7 to i32
  %t9 = sext i32 %t8 to i64
  %t10 = icmp eq i64 %t9, %t7
  %t11 = trunc i64 %t7 to i32
  %t12 = xor i1 %t10, 1
  br i1 %t12, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 11, i64 196, ptr @.bytes.2, i64 28, i64 %t7)
  unreachable
casted.1:
  store i32 %t11, ptr %l5
  %t13 = load i32, ptr %l5
  %t14 = call i32 @close(i32 %t13)
  store i32 %t14, ptr %l6
  br label %bb1
bb1:
  %t15 = load i64, ptr %l1
  %t16 = inttoptr i64 %t15 to ptr
  store ptr %t16, ptr %l7
  %t17 = load ptr, ptr %l7
  call void @free(ptr %t17)
  br label %bb2
bb2:
  ret void
}

define internal void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %p1, i64 %p2) #0 {
entry:
  %l0 = alloca [0 x i8], align 1
  %l1 = alloca ptr, align 8
  %l2 = alloca i64, align 8
  store ptr %p1, ptr %l1
  store i64 %p2, ptr %l2
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = load i64, ptr %l2
  call void @__saw_rt_panic(ptr %t0, i64 %t1)
  unreachable
}

define internal void @"saw std.string.string_literal(bytes: UnsafePointer<Int8>)"(ptr %ret, ptr %p1) #0 {
entry:
  %l0 = alloca [8 x i8], align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca [8 x i8], align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l2
  call void @llvm.memcpy.p0.p0.i64(ptr %l0, ptr %l2, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %ret, ptr %l0, i64 8, i1 false)
  ret void
}

define internal ptr @"saw std.string.string_bytes(text: &String)"(ptr noalias %p1) #0 {
entry:
  %l0 = alloca ptr, align 8
  %l1 = alloca ptr, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = load ptr, ptr %t0
  store ptr %t1, ptr %l0
  %t2 = load ptr, ptr %l0
  ret ptr %t2
}

define internal i64 @"saw std.string.string_length(text: &String)"(ptr noalias %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l2
  %t1 = load ptr, ptr %l2
  %t2 = call i64 @"saw std.string.String.len()"(ptr %t1)
  store i64 %t2, ptr %l3
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3
  store i64 %t3, ptr %l0
  %t4 = load i64, ptr %l0
  ret i64 %t4
}

define internal i64 @"saw Atomic.fetch_add(v: Int) args Int"(ptr %p1, i64 %p2) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca i64, align 8
  store ptr %p1, ptr %l1
  store i64 %p2, ptr %l2
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l3
  %t1 = load ptr, ptr %l3
  %t2 = load i64, ptr %l2
  %t3 = call i64 @"saw atomic_add_word(a: &Atomic<T>, v: Int) inst Int"(ptr %t1, i64 %t2)
  store i64 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i64, ptr %l4
  store i64 %t4, ptr %l0
  %t5 = load i64, ptr %l0
  ret i64 %t5
}

define internal i64 @"saw Atomic.load() args Int"(ptr %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l2
  %t1 = load ptr, ptr %l2
  %t2 = call i64 @"saw atomic_load_word(a: &Atomic<T>) inst Int"(ptr %t1)
  store i64 %t2, ptr %l3
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3
  store i64 %t3, ptr %l0
  %t4 = load i64, ptr %l0
  ret i64 %t4
}

define internal void @"saw reactor.rt_reactor_trigger(kfd: Int)"(i64 %p1) #0 {
entry:
  %l0 = alloca [0 x i8], align 1
  %l1 = alloca i64, align 8
  %l2 = alloca [32 x i8], align 8
  %l3 = alloca i64, align 8
  %l4 = alloca i16, align 2
  %l5 = alloca i16, align 2
  %l6 = alloca [32 x i8], align 8
  %l7 = alloca ptr, align 8
  %l8 = alloca ptr, align 8
  %l9 = alloca i32, align 4
  %l10 = alloca ptr, align 8
  %l11 = alloca ptr, align 8
  %l12 = alloca i32, align 4
  store i64 %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load i64, ptr @"static reactor.WAKE_IDENT"
  store i64 %t0, ptr %l3
  %t1 = load i16, ptr @"static reactor.EVFILT_USER"
  store i16 %t1, ptr %l4
  %t2 = trunc i64 0 to i16
  %t3 = zext i16 %t2 to i64
  %t4 = icmp eq i64 %t3, 0
  %t5 = icmp sge i64 0, 0
  %t6 = and i1 %t4, %t5
  %t7 = trunc i64 0 to i16
  %t8 = xor i1 %t6, 1
  br i1 %t8, label %cast.0, label %casted.1
cast.0:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 11, i64 136, ptr @.bytes.3, i64 29, i64 0)
  unreachable
casted.1:
  store i16 %t7, ptr %l5
  %t9 = load i64, ptr %l3
  store i64 %t9, ptr %l6
  %t10 = getelementptr i8, ptr %l6, i64 8
  %t11 = load i16, ptr %l4
  store i16 %t11, ptr %t10
  %t12 = getelementptr i8, ptr %l6, i64 10
  %t13 = load i16, ptr %l5
  store i16 %t13, ptr %t12
  %t14 = getelementptr i8, ptr %l6, i64 12
  %t15 = load i32, ptr @"static reactor.NOTE_TRIGGER"
  store i32 %t15, ptr %t14
  %t16 = getelementptr i8, ptr %l6, i64 16
  store i64 0, ptr %t16
  %t17 = getelementptr i8, ptr %l6, i64 24
  store i64 0, ptr %t17
  call void @llvm.memcpy.p0.p0.i64(ptr %l2, ptr %l6, i64 32, i1 false)
  %t18 = inttoptr i64 0 to ptr
  store ptr %t18, ptr %l8
  %t19 = load ptr, ptr %l8
  store ptr %t19, ptr %l7
  %t20 = load i64, ptr %l1
  %t21 = trunc i64 %t20 to i32
  %t22 = sext i32 %t21 to i64
  %t23 = icmp eq i64 %t22, %t20
  %t24 = trunc i64 %t20 to i32
  %t25 = xor i1 %t23, 1
  br i1 %t25, label %cast.2, label %casted.3
cast.2:
  call void @__saw_fail_signed(ptr @.bytes.0, i64 11, i64 138, ptr @.bytes.2, i64 28, i64 %t20)
  unreachable
casted.3:
  store i32 %t24, ptr %l9
  store ptr %l2, ptr %l10
  %t26 = load ptr, ptr %l10
  store ptr %t26, ptr %l11
  %t27 = load i32, ptr %l9
  %t28 = load ptr, ptr %l11
  %t29 = load ptr, ptr %l7
  %t30 = load ptr, ptr %l7
  %t31 = call i32 @kevent(i32 %t27, ptr %t28, i32 1, ptr %t29, i32 0, ptr %t30)
  store i32 %t31, ptr %l12
  br label %bb1
bb1:
  ret void
}

define internal i64 @"saw std.string.String.len()"(ptr noalias %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  %t1 = load ptr, ptr %t0
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  store ptr %t2, ptr %l2
  %t3 = load i64, ptr @"static std.string.LENGTH_SLOT"
  store i64 %t3, ptr %l4
  %t4 = load ptr, ptr %l2
  %t5 = load i64, ptr %l4
  %t6 = mul i64 %t5, 8
  %t7 = getelementptr i8, ptr %t4, i64 %t6
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l0
  %t9 = load i64, ptr %l0
  ret i64 %t9
}

define internal i64 @"saw atomic_add_word(a: &Atomic<T>, v: Int) inst Int"(ptr %p1, i64 %p2) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca i64, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca ptr, align 8
  %l5 = alloca ptr, align 8
  %l6 = alloca i64, align 8
  store ptr %p1, ptr %l1
  store i64 %p2, ptr %l2
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l3
  %t1 = load ptr, ptr %l3
  %t2 = call ptr @"saw UnsafeMutableInterior.ptr() args Int"(ptr %t1)
  store ptr %t2, ptr %l4
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l4
  store ptr %t3, ptr %l5
  %t4 = load ptr, ptr %l5
  %t5 = load i64, ptr %l2
  %t6 = atomicrmw add ptr %t4, i64 %t5 seq_cst
  store i64 %t6, ptr %l6
  br label %bb2
bb2:
  %t7 = load i64, ptr %l6
  store i64 %t7, ptr %l0
  %t8 = load i64, ptr %l0
  ret i64 %t8
}

define internal i64 @"saw atomic_load_word(a: &Atomic<T>) inst Int"(ptr %p1) #0 {
entry:
  %l0 = alloca i64, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca ptr, align 8
  %l4 = alloca ptr, align 8
  %l5 = alloca i64, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l2
  %t1 = load ptr, ptr %l2
  %t2 = call ptr @"saw UnsafeMutableInterior.ptr() args Int"(ptr %t1)
  store ptr %t2, ptr %l3
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l3
  store ptr %t3, ptr %l4
  %t4 = load ptr, ptr %l4
  %t5 = load atomic i64, ptr %t4 seq_cst, align 8
  store i64 %t5, ptr %l5
  br label %bb2
bb2:
  %t6 = load i64, ptr %l5
  store i64 %t6, ptr %l0
  %t7 = load i64, ptr %l0
  ret i64 %t7
}

define internal ptr @"saw UnsafeMutableInterior.ptr() args Int"(ptr %p1) #0 {
entry:
  %l0 = alloca ptr, align 8
  %l1 = alloca ptr, align 8
  %l2 = alloca ptr, align 8
  %l3 = alloca ptr, align 8
  store ptr %p1, ptr %l1
  br label %bb0
bb0:
  %t0 = load ptr, ptr %l1
  store ptr %t0, ptr %l2
  %t1 = load ptr, ptr %l2
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  store ptr %t2, ptr %l0
  %t3 = load ptr, ptr %l0
  ret ptr %t3
}

define internal i64 @__saw_render_uint(ptr %out, i64 %v) #0 {
entry:
  %tmp = alloca [24 x i8], align 1
  br label %loop
loop:
  %n = phi i64 [ %v, %entry ], [ %q, %loop ]
  %i = phi i64 [ 24, %entry ], [ %i1, %loop ]
  %q = udiv i64 %n, 10
  %r = urem i64 %n, 10
  %d = trunc i64 %r to i8
  %c = add i8 %d, 48
  %i1 = sub i64 %i, 1
  %p = getelementptr i8, ptr %tmp, i64 %i1
  store i8 %c, ptr %p
  %more = icmp ne i64 %q, 0
  br i1 %more, label %loop, label %done
done:
  %len = sub i64 24, %i1
  %src = getelementptr i8, ptr %tmp, i64 %i1
  call void @llvm.memcpy.p0.p0.i64(ptr %out, ptr %src, i64 %len, i1 false)
  ret i64 %len
}

define internal i64 @__saw_render_int(ptr %out, i64 %v) #0 {
entry:
  %neg = icmp slt i64 %v, 0
  br i1 %neg, label %minus, label %plain
minus:
  store i8 45, ptr %out
  %mag = sub i64 0, %v
  %rest = getelementptr i8, ptr %out, i64 1
  %n = call i64 @__saw_render_uint(ptr %rest, i64 %mag)
  %len = add i64 %n, 1
  ret i64 %len
plain:
  %m = call i64 @__saw_render_uint(ptr %out, i64 %v)
  ret i64 %m
}

define internal i64 @__saw_append(ptr %buf, i64 %pos, ptr %src, i64 %len) #0 {
entry:
  %closed = icmp slt i64 %pos, 0
  br i1 %closed, label %keep, label %open
keep:
  ret i64 %pos
open:
  %room = sub i64 508, %pos
  %fits = icmp ule i64 %len, %room
  br i1 %fits, label %whole, label %back
whole:
  %at = getelementptr i8, ptr %buf, i64 %pos
  call void @llvm.memcpy.p0.p0.i64(ptr %at, ptr %src, i64 %len, i1 false)
  %end = add i64 %pos, %len
  ret i64 %end
back:
  %n = phi i64 [ %room, %open ], [ %n1, %step ]
  %none = icmp eq i64 %n, 0
  br i1 %none, label %cut, label %test
test:
  %p = getelementptr i8, ptr %src, i64 %n
  %b = load i8, ptr %p
  %hi = and i8 %b, -64
  %inside = icmp eq i8 %hi, -128
  br i1 %inside, label %step, label %cut
step:
  %n1 = sub i64 %n, 1
  br label %back
cut:
  %at2 = getelementptr i8, ptr %buf, i64 %pos
  call void @llvm.memcpy.p0.p0.i64(ptr %at2, ptr %src, i64 %n, i1 false)
  %stop = add i64 %pos, %n
  %shut = sub i64 -1, %stop
  ret i64 %shut
}

define internal i64 @__saw_finish(ptr %buf, i64 %pos) #0 {
entry:
  %cut = icmp slt i64 %pos, 0
  br i1 %cut, label %mark, label %line
mark:
  %stop = sub i64 -1, %pos
  %m0 = getelementptr i8, ptr %buf, i64 %stop
  store i8 -30, ptr %m0
  %m1 = getelementptr i8, ptr %m0, i64 1
  store i8 -128, ptr %m1
  %m2 = getelementptr i8, ptr %m0, i64 2
  store i8 -90, ptr %m2
  %marked = add i64 %stop, 3
  br label %line
line:
  %end = phi i64 [ %marked, %mark ], [ %pos, %entry ]
  %nl = getelementptr i8, ptr %buf, i64 %end
  store i8 10, ptr %nl
  %total = add i64 %end, 1
  ret i64 %total
}

define internal i64 @__saw_append_int(ptr %buf, i64 %pos, i64 %v) #0 {
entry:
  %tmp = alloca [24 x i8], align 1
  %n = call i64 @__saw_render_int(ptr %tmp, i64 %v)
  %end = call i64 @__saw_append(ptr %buf, i64 %pos, ptr %tmp, i64 %n)
  ret i64 %end
}

define internal i64 @__saw_append_uint(ptr %buf, i64 %pos, i64 %v) #0 {
entry:
  %tmp = alloca [24 x i8], align 1
  %n = call i64 @__saw_render_uint(ptr %tmp, i64 %v)
  %end = call i64 @__saw_append(ptr %buf, i64 %pos, ptr %tmp, i64 %n)
  ret i64 %end
}

@__saw_fail_at = private unnamed_addr constant [9 x i8] c"panic at "
@__saw_fail_colon = private unnamed_addr constant [2 x i8] c": "
@__saw_fail_true = private unnamed_addr constant [4 x i8] c"true"
@__saw_fail_false = private unnamed_addr constant [5 x i8] c"false"
@__saw_fail_overflow.reason = private unnamed_addr constant [16 x i8] c"integer overflow"
@__saw_fail_divide.reason = private unnamed_addr constant [16 x i8] c"division by zero"
@__saw_fail_shift.reason = private unnamed_addr constant [18 x i8] c"shift out of range"
@__saw_fail_unwrap.reason = private unnamed_addr constant [20 x i8] c"force unwrap of None"
@__saw_fail_try.reason = private unnamed_addr constant [11 x i8] c"try! failed"

define internal i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line) #0 {
entry:
  %at = call i64 @__saw_append(ptr %buf, i64 0, ptr @__saw_fail_at, i64 9)
  %named = call i64 @__saw_append(ptr %buf, i64 %at, ptr %file, i64 %file_len)
  %known = icmp sge i64 %line, 0
  br i1 %known, label %number, label %tail
number:
  %colon = call i64 @__saw_append(ptr %buf, i64 %named, ptr @__saw_fail_colon, i64 1)
  %lined = call i64 @__saw_append_uint(ptr %buf, i64 %colon, i64 %line)
  br label %tail
tail:
  %pos = phi i64 [ %named, %entry ], [ %lined, %number ]
  %end = call i64 @__saw_append(ptr %buf, i64 %pos, ptr @__saw_fail_colon, i64 2)
  ret i64 %end
}

define internal void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr %text, i64 %text_len) noinline noreturn #0 {
entry:
  %buf = alloca [512 x i8], align 1
  %head = call i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line)
  %done = call i64 @__saw_append(ptr %buf, i64 %head, ptr %text, i64 %text_len)
  %end = call i64 @__saw_finish(ptr %buf, i64 %done)
  call void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %buf, i64 %end)
  unreachable
}

define internal void @__saw_fail_signed(ptr %file, i64 %file_len, i64 %line, ptr %text, i64 %text_len, i64 %v) noinline noreturn #0 {
entry:
  %buf = alloca [512 x i8], align 1
  %head = call i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line)
  %pos = call i64 @__saw_append(ptr %buf, i64 %head, ptr %text, i64 %text_len)
  %done = call i64 @__saw_append_int(ptr %buf, i64 %pos, i64 %v)
  %end = call i64 @__saw_finish(ptr %buf, i64 %done)
  call void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %buf, i64 %end)
  unreachable
}

define internal void @__saw_fail_unsigned(ptr %file, i64 %file_len, i64 %line, ptr %text, i64 %text_len, i64 %v) noinline noreturn #0 {
entry:
  %buf = alloca [512 x i8], align 1
  %head = call i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line)
  %pos = call i64 @__saw_append(ptr %buf, i64 %head, ptr %text, i64 %text_len)
  %done = call i64 @__saw_append_uint(ptr %buf, i64 %pos, i64 %v)
  %end = call i64 @__saw_finish(ptr %buf, i64 %done)
  call void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %buf, i64 %end)
  unreachable
}

define internal void @__saw_fail_parts(ptr %file, i64 %file_len, i64 %line, ptr %text, i64 %text_len, ptr %parts, i64 %count) noinline noreturn #0 {
entry:
  %buf = alloca [512 x i8], align 1
  %head = call i64 @__saw_fail_head(ptr %buf, ptr %file, i64 %file_len, i64 %line)
  %pos = call i64 @__saw_append(ptr %buf, i64 %head, ptr %text, i64 %text_len)
  br label %loop
loop:
  %i = phi i64 [ 0, %entry ], [ %i1, %next ]
  %at = phi i64 [ %pos, %entry ], [ %after, %next ]
  %more = icmp slt i64 %i, %count
  br i1 %more, label %part, label %last
part:
  %offset = mul i64 %i, 24
  %p = getelementptr i8, ptr %parts, i64 %offset
  %kind = load i64, ptr %p
  %first = getelementptr i8, ptr %p, i64 8
  %second = getelementptr i8, ptr %p, i64 16
  switch i64 %kind, label %run [ i64 1, label %signed i64 2, label %unsigned i64 3, label %bool ]
run:
  %src = load ptr, ptr %first
  %len = load i64, ptr %second
  %ran = call i64 @__saw_append(ptr %buf, i64 %at, ptr %src, i64 %len)
  br label %next
signed:
  %sv = load i64, ptr %first
  %sd = call i64 @__saw_append_int(ptr %buf, i64 %at, i64 %sv)
  br label %next
unsigned:
  %uv = load i64, ptr %first
  %ud = call i64 @__saw_append_uint(ptr %buf, i64 %at, i64 %uv)
  br label %next
bool:
  %byte = load i8, ptr %first
  %yes = icmp ne i8 %byte, 0
  %word = select i1 %yes, ptr @__saw_fail_true, ptr @__saw_fail_false
  %size = select i1 %yes, i64 4, i64 5
  %bd = call i64 @__saw_append(ptr %buf, i64 %at, ptr %word, i64 %size)
  br label %next
next:
  %after = phi i64 [ %ran, %run ], [ %sd, %signed ], [ %ud, %unsigned ], [ %bd, %bool ]
  %i1 = add i64 %i, 1
  br label %loop
last:
  %done = phi i64 [ %at, %loop ]
  %end = call i64 @__saw_finish(ptr %buf, i64 %done)
  call void @"saw std.panic.panic_sink(message: UnsafePointer<Int8>, length: Int)"(ptr %buf, i64 %end)
  unreachable
}

define internal void @__saw_fail_overflow(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_overflow.reason, i64 16)
  unreachable
}

define internal void @__saw_fail_divide(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_divide.reason, i64 16)
  unreachable
}

define internal void @__saw_fail_shift(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_shift.reason, i64 18)
  unreachable
}

define internal void @__saw_fail_unwrap(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_unwrap.reason, i64 20)
  unreachable
}

define internal void @__saw_fail_try(ptr %file, i64 %file_len, i64 %line) noinline noreturn #0 {
entry:
  call void @__saw_fail(ptr %file, i64 %file_len, i64 %line, ptr @__saw_fail_try.reason, i64 11)
  unreachable
}

attributes #0 = { "frame-pointer"="non-leaf" }
